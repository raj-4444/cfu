#!/bin/sh
jupyter nbconvert --ClearOutputPreprocessor.enabled=True --to notebook notebooks/training_edit.ipynb --output training.ipynb
git add notebooks/training.ipynb