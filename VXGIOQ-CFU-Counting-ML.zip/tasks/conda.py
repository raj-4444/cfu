"""Conda tasks."""

import logging
import os

from invoke import task

logger = logging.getLogger(__name__)
REPO_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


@task
def create(c):
    """Recreate the conda environment."""
    logger.info("Recreating conda environment vxgioq-cfu-counting-ml-env...")
    conda_env_path = os.path.join(REPO_PATH, "./.envs", "vxgioq-cfu-counting-ml-env")
    c.run("conda-merge environment.run.yml environment.dev.yml > environment.yml")
    c.run(f"mamba env create --prefix {conda_env_path} --file environment.yml --force")
    c.run("mamba config --append envs_dirs .envs 2> /dev/null")
    c.run("rm environment.yml")
    logger.info("Installing editable vxgioq_cfu_counting_ml into conda environment...")
    c.run("jupyter nbextension enable --py widgetsnbextension")
    c.run(
        "jupyter labextension install @jupyter-widgets/jupyterlab-manager plotlywidget@4.9.0 jupyter-matplotlib jupyterlab-plotly @jupyterlab/toc @pyviz/jupyterlab_pyviz"
    )


@task
def update(c):
    """Update the conda environment."""
    logger.info("Updating conda environment vxgioq-cfu-counting-ml-env...")
    conda_env_path = os.path.join(REPO_PATH, "./.envs", "vxgioq-cfu-counting-ml-env")
    c.run("conda-merge environment.run.yml environment.dev.yml > environment.yml")
    c.run(f"mamba env update --prefix {conda_env_path} --file environment.yml --prune")
    c.run("rm environment.yml")
    logger.info("Installing editable vxgioq_cfu_counting_ml into conda environment...")
    c.run("jupyter nbextension enable --py widgetsnbextension")
    c.run(
        "jupyter labextension install @jupyter-widgets/jupyterlab-manager plotlywidget@4.9.0 jupyter-matplotlib jupyterlab-plotly @jupyterlab/toc @pyviz/jupyterlab_pyviz"
    )
