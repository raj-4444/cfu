"""Main tasks."""

import logging
import os

from invoke import task

logger = logging.getLogger(__name__)
REPO_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
IP_USHPC = "10.136.176.120"


@task
def lint(c):
    """Lint this package."""
    logger.info("Running pre-commit checks...")
    c.run("pre-commit run --all-files --color always")


@task
def test(c):
    """Test this package."""
    logger.info("Running Pytest...")
    if os.path.basename(os.getcwd()) == "src":
        os.chdir("../")

    c.run(
        "pytest --cov=src tests src/vxgioq_cfu_counting_ml/utils src/vxgioq_cfu_counting_ml/training src/vxgioq_cfu_counting_ml/api"
    )


@task
def notebook(c, ushpc=False):
    """Run Jupyter Notebook."""
    notebooks_path = os.path.join(REPO_PATH, "notebooks")
    os.makedirs(notebooks_path, exist_ok=True)
    with c.cd(notebooks_path):
        if not ushpc:
            c.run("jupyter notebook")
        else:
            c.run(f"jupyter notebook --ip {IP_USHPC} --no-browser")


@task
def lab(c, ushpc=False):
    """Run Jupyter Lab."""
    notebooks_path = os.path.join(REPO_PATH, "notebooks")
    os.makedirs(notebooks_path, exist_ok=True)
    with c.cd(notebooks_path):
        if not ushpc:
            c.run("jupyter lab")
        else:
            c.run(f"jupyter lab --ip {IP_USHPC} --no-browser")


@task
def streamlit(c, app="predictions", ushpc=False):
    """Run Streamlit app."""
    if not ushpc:
        c.run(f"streamlit run src/vxgioq_cfu_counting_ml/demo/{app}.py --server.runOnSave true")
    else:
        c.run(
            f"streamlit run src/vxgioq_cfu_counting_ml/demo/{app}.py --server.runOnSave true --server.address {IP_USHPC}"
        )


@task
def fastapi(c, production=True, ushpc=False):
    """Run FastAPI app."""
    base_command = "uvicorn 'vxgioq_cfu_counting_ml.api.api:app' --app-dir src"

    if not production:
        c.run(f"{base_command} --log-level debug --reload")
    else:
        prod_command = f"{base_command} --log-level info "
        if ushpc:
            c.run(f"{prod_command} --host {IP_USHPC}")
        else:
            c.run(prod_command)


@task
def tensorboard(c, logdir="./notebooks/output", ushpc=False):
    """Run Tensorboard app."""
    if not ushpc:
        c.run(f"tensorboard --logdir={logdir}")
    else:
        c.run(f"tensorboard --logdir={logdir} --host {IP_USHPC} --port 8502")


@task
def docs(c, browser=True, output_dir="site"):
    """Generate this package's docs."""
    if browser:
        c.run("portray in_browser")
    else:
        c.run(f"portray as_html --output_dir {output_dir} --overwrite")
        logger.info("Package documentation available at ./site/index.html")


@task
def bump(c, part, dry_run=False):
    """Bump the major, minor, patch, or post-release part of this package's version."""
    c.run(f"bump2version {'--dry-run --verbose ' + part if dry_run else part}")
