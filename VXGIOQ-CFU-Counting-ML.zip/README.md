# VXGIOQ-CFU-Counting-ML

A Machine Learning API deployed on Kubernetes to make use of

- a mask R-CNN Instance segmentation model to count CFUs in petri dishes with various media
- gradient boosting trees quantile models to estimate the 95% prediction interval of the predicted counts.

<!-- TOC -->

1. [VXGIOQ-CFU-Counting-ML](#vxgioq-cfu-counting-ml)
   1. [Design choices](#design-choices)
      1. [ML Framework](#ml-framework)
      2. [API framework](#api-framework)
      3. [ML Models](#ml-models)
         1. [Instance segmentation](#instance-segmentation)
      4. [95% Prediction interval](#95-prediction-interval)
      5. [Project architecture](#project-architecture)
   2. [Contributing](#contributing)
      1. [1. Development environment setup](#1-development-environment-setup)
      2. [2. Activating the Python environment](#2-activating-the-python-environment)
      3. [3. Unit testing](#3-unit-testing)
      4. [4. CI/CD](#4-cicd)
      5. [5. Docker](#5-docker)
      6. [6. Known issues](#6-known-issues)
         1. [Detectron2/Pytorch](#detectron2pytorch)

<!-- /TOC -->

## Design choices

### ML Framework

We decide to go for [detectron2](https://github.com/facebookresearch/detectron2) and turn away from the [matterport](https://github.com/matterport/Mask_RCNN) implementation of the mask R-CNN algorithm for the following reasons

- Based on tensorflow 1, which starts to date
- Based on tensorflow, which popularity decreases in aid of pytorch
- The original [detectron](https://github.com/facebookresearch/Detectron) library from facebook, which was implemented in Caffe2 and published the original mask R-CNN paper, is now ported to pytorch in detectron2
- Conversely to matterport, detectron2 also allows to choose from various models (see [their models' zoo](https://github.com/facebookresearch/detectron2/blob/master/MODEL_ZOO.md)) of different computer vision families (instance segmentation, object detection, keypoint detection, panoptic segmentation, ...)

A close second option, implemented in modern pytorch as well, is the [mmdetection](https://github.com/open-mmlab/mmdetection) library which also allows to choose from recent state of the art deep learning algorithms in various computer vision families.
Our choice eventually boilled down to our foreseen libraries popularity and maintainability. This in turn gives an edge to Facebook's detectron2 library which seems to provide more guarantee.

[Their colab notebook](https://colab.research.google.com/drive/16jcaJoc6bCFAQ96jDe2HwtXj7BMD_-m5) shows how to load, infer, train from existing and infer.

[The `tools` folder in their repo](https://github.com/facebookresearch/detectron2/tree/master/tools) shows examples of training scripts (e.g. `plain_train_net.py`) to get inspired from.

### API framework

[FastAPI](https://fastapi.tiangolo.com/) has become the defacto standard to develop REST APIs in python the last 2 years for it's ease of use, speed and flexibility.

### ML Models

#### Instance segmentation

We experimented with and continued the training of the following pretrained

- `mask_rcnn_R_50_FPN_3x`
- `mask_rcnn_R_101_FPN_3x`
- `mask_rcnn_X_101_32x8d_FPN_3x`

instance segmentation models from the [detectron2 models' zoo](https://github.com/facebookresearch/detectron2/blob/master/MODEL_ZOO.md).
These mask R-CNN models (convolutional and fully connected head layers for masks and boxes, respectively) all use interchangeable backbones (all of which make use of Feature Pyramid Networks). All these architectures configs have been adapted to this particular project and are available in `/configs/`, along with their base configs for both CPU or GPU usage (note however that we don't advice using CPU for anything else the Resnet50).
The X101 has prooved to perform better than the original mask R-CNN implementations and is on the same level as the more recent Cascade R-CNN. [PointRend](https://github.com/facebookresearch/detectron2/tree/master/projects/PointRend) is a new contender that mostly seeks to improve the quality of the generated masks. In this project, the precision of the mask isn't of utmost importance and, hence, this model won't be investigated unless time permits.

Eventually, it's worth noting that, in this project, the X101 and R101 did not improve upon the more lightweight R50 backbone. Hence, the latter architecture is used by the trained models available for the ML API as it trains and infers more quickly and requires less resources.
This shows the data we work with in the project is not complicated enough or not in sufficient quantities for more powerful architectures to get an edge compared to the R50 backbone.

### 95% Prediction interval

We developped gradient boosting trees quantile regression models (making use of lightGBM) to estimate both the lower (2.5%) and upper (97.5%) bands of the 95% prediction interval of the actual CFU(s) counts.
The scores for each of the instances returned by the instance segmentation model are used as inputs (after being converted to binned continuous distribution functions to provide fixed number of features) to train those quantile models.

### Project architecture

The codebase resides in `src/vxgioq_cfu_counting_ml`. The following subpackages and some of their key modules are depicted below

- `api`
  - `api.py` - ML API definition and instantiation. It fetches (upon instantiation and at periodic intervals) the models KPIs and downloads and loads from Azure blob storage the model which performs best on the chosen KPI. Hence, if a better model get trained and uploaded on Azure, the ML API will automatically fetch it when available without the need to redeploy the API.
  - `data_models.py` - Definition of the input and output formats handled by the ML API.
- `demo` - Streamlit demo apps to support models results during development. Note that this sub-package is not tested as the demos it contains are not long lived and only temporarily relevant to communicate with the stakeholders.
- `training` - Tools related to the CFU specialized detectron2 Instance segmentation models training.
- `utils` - Compilation of modules with utilities that can benefit all the other subpackages.

The codebase is wrapped in a docker image which then gets

- Built
- Linted
- Tested
- Pushed to Azure Container Registry
- Deployed (the ML API service) on Azure Kubernetes Service

from Microsoft hosted agents in Azure devops pipelines.

The training and data/models analysis steps are depicted in [this notebook](notebooks/training.ipynb). One would typically run the training steps on a GPU machine, such as the [jupyterlab running GSK USHPC on-demand GPUs](https://ushpc-ondemand.gsk.com) (which requires to be connected to GSK's VPN and to install your conda environment in your partition). We advice for a `V100` machine, as smaller GPUs (e.g. `P100`) may require reducing batch size, lowering learning rate, ... to avoid training crashes. Note as well that GSK HPC ondemand comes with an old, barebone and non-extendable version of jupyterlab. This in turns prevents proper display of plots in the notebook (these cells/sections are marked with `(optional)`). For plots display, one can run the notebook from his/her local machine after having gone through the steps in the [Contributing](#contributing) section which handles libraries and jupyterlab extensions installation.

## Contributing

### 1. Development environment setup

1. Install [VS Code](https://code.visualstudio.com/) as your editor. Your VS Code's _Workspace Settings_ are managed by this repo in `.vscode/settings.json`.
2. [Generate an SSH key and add the SSH key to Azure Devops if not already done](https://docs.microsoft.com/en-us/azure/devops/repos/git/use-ssh-keys-to-authenticate?view=azure-devops), and make sure your ssh key is on top of the list of keys used by your authentication agent.
3. Open a Terminal and clone this repo with `git clone git@ssh.dev.azure.com:v3/DevOps-Vx/VXGIOQ-CFU-Counting/VXGIOQ-CFU-Counting-ML.git`.
4. In VS Code open the repo folder and open an Integrated Terminal with <kbd>⌃</kbd> + <kbd>\`</kbd> and run `./tasks/init.sh` to:
   1. Install VS Code's [Python](https://marketplace.visualstudio.com/items?itemName=ms-python.python) [extensions](https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance).
   2. Install [conda](https://docs.conda.io/projects/conda/en/latest/) for the current user, if not already installed.
   3. Create the conda environment `vxgioq-cfu-counting-ml-env` (specified by merging `environment.*.yml`).
   4. Install the [pre-commit](https://pre-commit.com) hooks configured in `.pre-commit-config.yaml` and configure git.
5. Run <kbd>⌘</kbd> + <kbd>⇧</kbd> + <kbd>P</kbd> > _Python: Select Interpreter_ and then pick `vxgioq-cfu-counting-ml-env`.
6. The package `vx_protlm_package` is now installed in `dev` mode so any edits are immediately reflected in the enviroment's package installation.
7. To easily export all environment variables related to you project, you can
   1. Create a `./services/environments/.env.secrets` file containing the environment variables as `<key>=<value>` lines
   2. Export those variables with `source ./services/environments/dotenv.sh ./services/environments/.env.secrets`

### 2. Activating the Python environment

These steps are a prerequisite for any task you wish to run in this project:

1. Open any Python file in the project to load VS Code's Python extension, or skip this step if you have one open already.
2. Open a Integrated Terminal with <k/bd>⌃</kbd> + <kbd>~</kbd> and the conda environment `vxgioq-cfu-counting-ml-env` should activate automatically inside it.
3. Now you're ready to run any of tasks listed by `invoke --list`.

### 3. Unit testing

1. [Activate the Python environment](#2-activating-the-python-environment).
2. If you don't see _⚡ Run tests_ in the blue bar, run <kbd>⌘</kbd> + <kbd>⇧</kbd> + <kbd>P</kbd> > _Python: Discover Tests_. Optionally debug the output in _View_ > _Output_ > _Python Test Log_ in case this step fails.
3. Go to any test function in `src/tests/pytest`.
4. Optional: put a breakpoint 🔴 next to the line number where you want to stop.
5. Click on _Run Test_ or _Debug Test_ above the test you want to debug.

### 4. CI/CD

The CI/CD pipeline implemented in `.azure-ci.yml` essentially does the following each time code (which can impact the source code or the containerization code) is pushed to the remote devops repo

1. Build a docker image with the codebase and the dependencies needed to run it
2. Based on the image built in the previous step
   1. Run linting from within a container (in a similar fashion to what you'd run locally with `invoke lint`)
   2. Run testing from within a container (in a similar fashion to what you'd run locally with `invoke test`)
3. If the code is pushed to a major branch (i.e. master or dev), the following happens as well
   1. Tag the docker image with both the git commit and `latest`
   2. Push the tagged docker image to Azure Container Registry
   3. Deploy that image on Azure Kubernetes Service

### 5. Docker

You don't need to use docker to contribute to the code base. Nonetheless, the contributions are getting containerized with docker and shipped to Azure Container Registry and deployed to Kubernetes.

A basic understanding of the following few docker commands might come handy if the containerization steps in the CI/CD pipeline need modifications/fixes

```bash
docker-compose build api  # Build API image
docker-compose up --build api  # Build and run API (in prod mode)
docker-compose run --rm api <entrypoint-command>  # Run api with any of the commands defined in the entrypoint, and remove the container once stopped
docker-compose run --rm --service-ports api dev  # Run the API in dev mode
docker-compose run --rm --service-ports api serve  # Run the API in prod mode
docker-compose run --rm api lint  # Run the linting inside the docker container
docker-compose run --rm api test  # Run the testing inside the docker container
docker-compose run --rm --service-ports api lab  # Run jupyter lab
docker-compose run --rm --service-ports api streamlit <streamlit-python-file-name>  # Run streamlit app
docker exec -it <container-id> bash  # Enter a running container
docker run --rm -p 0.0.0.0:8000:8000 gioqcfu.azurecr.io/gioqcfu/ml/api:latest  # Manually launch the ml api in (prod mode), with docker, without docker-compose
docker run --rm -p 0.0.0.0:8000:8000 gioqcfu.azurecr.io/gioqcfu/ml/api:latest streamlit predictions.py  # Manually launch the streamlit app, with docker, without docker-compose
```

### 6. Known issues

The section lists known issues and potential fixes that were encountered during the project.

#### Detectron2/Pytorch

- `Dataloader worker exited unexpectedly`
  - For mac, setting `cv2.setNumThreads(0)` at the beginning of the script can resolve the issue
  - If in script mode, ensure pytorch data loader (or the detectron Trainer being called) is in a `if __name__ == '__main__'`
  - Decrease batch size
  - Decrease max image resolution
  - Reduce the number of workers: cfg.DATALOADER.NUM_WORKERS = 0
  - If running in docker (should not be the case in this project), setting --shm-size="8g" can ensure enough memory is allocated (8Gb)
- `Results do not correspond to current coco set`
  - Could be that the dataset-function is not returning exactly the same data every time. E.g., setting a unique random image id to each image will produce 2 different datasets if the function is run twice
- FloatingPointError: Loss became infinite or NaN at iteration=... OR  RuntimeError: cannot perform reduction function argmax on a tensor with no elements because the operation does not have an identity
  - This can happen if we include negative dishes (i.e. no CFU, i.e. no annotation) in the training steps and the Batch sampler generates a batch of only negative dishes, hence leading to issues when computing the gradient.
    - The quick fix is to ensure the negative samples never make it to the training batch sampler. This can be achieved by setting: FILTER_EMPTY_ANNOTATIONS = True
    - A more thorough fix would be to implement our own custom batch sampler which would ensure batches always contain at leas one positive dish to avoid numerical instabilities. Since the model performs well on negative examples in inference mode without having seen any during training, such thorough fix would not bring much added value.
  - Could be that the base learning rate is too high (typical if failling after a few steps, e.g. 100) depending on the backend in use.
- RuntimeError: CUDA out of memory: Tried to allocated V MiB (GPU 0: W total capacity; X MiB already allocated; Y GiB free; Z MiB cached)
  - Decreasing the batch size and increasing the number of epochs can sometimes help
  - If CUDA complains it can't allocate a few MiB of memory while a lot of GiB of memory is available, it is likely the allocated HPC machine was booted without having properly cleaned it's resources from a previous usage. Without sudo priviledges on the machine, the best thing to do is to delete the session and request another session. In general, this solves the problem.
  - Another possibility is complex training images (with several hundreds of CFUs) which could potentially lead to RAM exhaustion, or exploding gradients. The training notebook has a cell dedicated to the removal frmo the train set of such identified images.
