#!/usr/bin/env bash

set -e

# Define help message
function show_help() {
    echo """
Usage: docker run <imagename> COMMAND

Commands

jupyter     : Start jupyter lab
streamlit   : Start streamlit
dev         : Run API in dev mode
serve       :Run API in prod mode
bash        : Start a bash shell
lint        : Run linting
test        : Run testing
help        : Show this message
"""
}

function run_dev {
    echo "Running Development Server on 0.0.0.0:8000"
    uvicorn "vxgioq_cfu_counting_ml.api.api:app" \
        --reload \
        --log-level debug \
        --host 0.0.0.0 \
        --port 8000
}

function run_serve {
    echo "Running Production Server on 0.0.0.0:8000"
    uvicorn "vxgioq_cfu_counting_ml.api.api:app" \
        --log-level info \
        --host 0.0.0.0 \
        --workers 1 \
        --timeout-keep-alive 60 \
        --log-level info \
        --header Server:AwesomeServer \
        --port 8000
}

# shellcheck disable=SC2155
function download_best_model {
    echo "Downloading best model..."
    python -c "from vxgioq_cfu_counting_ml.utils.predictor import download_unzip_best_model; download_unzip_best_model()"
}

# shellcheck disable=SC2155
function download_predictions {
    echo "Downloading predictions..."
    python -c "from vxgioq_cfu_counting_ml.training.data_analysis import get_best_model_predictions; get_best_model_predictions()"
}

case "$1" in
    jupyter)
        echo "Trusting jupyter notebooks"
        jupyter trust /app/notebooks/**/*.ipynb || true
        LAB_PORT=9876
        echo "Running Jupyter lab on 0.0.0.0:$LAB_PORT"
        jupyter lab \
            --ip 0.0.0.0 \
            --port $LAB_PORT \
            --no-browser \
            --allow-root
    ;;
    streamlit)
        download_predictions
        STREAMLIT_SERVER_PORT=8000
        echo "Running streamlit on http://0.0.0.0:${STREAMLIT_SERVER_PORT}"
        streamlit run vxgioq_cfu_counting_ml/demo/"$2" \
            --browser.serverPort "${STREAMLIT_SERVER_PORT}" \
            --server.runOnSave true \
            --server.port "${STREAMLIT_SERVER_PORT}"
    ;;
    dev)
        download_best_model
        run_dev
    ;;
    serve)
        download_best_model
        run_serve
    ;;
    bash)
        /bin/bash "${@:2}"
    ;;
    lint)
        cd ../
        git init
        git add -A
        invoke lint
    ;;
    test)
        cd ../
        invoke test
    ;;
    *)
        show_help
    ;;
esac
