"""!!!!!!DEPRECATED!!!!!!!!!!Demo Streamlit predctions app."""
import hashlib
import logging
import os
from datetime import datetime
from typing import List, Tuple

import holoviews as hv
import joblib
import numpy as np
import streamlit as st
from PIL import Image

from vxgioq_cfu_counting_ml.demo import SessionState
from vxgioq_cfu_counting_ml.utils.azure import (
    PATH_PREDICTIONS_ON_DISK,
    download_load_models_kpis,
    download_unzip_clean_predictions,
)
from vxgioq_cfu_counting_ml.utils.convert import json_to_df_model_kpis
from vxgioq_cfu_counting_ml.utils.loader import get_best_model_name
from vxgioq_cfu_counting_ml.utils.types import ModelsKPIs

st.set_option("deprecation.showfileUploaderEncoding", False)
hv.extension("bokeh")

logger = logging.getLogger(__name__)


def _verify_password(password_to_check: str) -> bool:
    """Verify the password."""
    new_key = hashlib.pbkdf2_hmac(
        hash_name="sha256",
        password=password_to_check.encode("utf-8"),
        salt=b"\xc5|P\xcd\xd7\x05Gss\x97o\xfd\r\xf9a\xc3\xb5w\xbeWt\x11o*-a\xda\xc2\xb1g:\x00",  # noqa: E501
        iterations=100000,
        dklen=128,
    )
    key = b"\xa1\x1c\xc9\xbf\x9f\x86z\x95\x80m\x15O\x99\x9f\x16\x00~\xdeS\xe5\xc2\xd3~\n\xaaLN\xa9\x9a\xe68\xbfMb\xb1\x1b-&\xc6\xebc\xcf\xdac\x1d\xda\xb5\x89\xc5\xb2\x0bd\x07k\xc7\x95\x16\xdd\xbd \xad\x83\xe7?\xeb\x9288\x01Gsi7\rW\xfa\xf2W\x05\xec\x9f7\x93S3Q\xc8\xa8\xa4\x83v:\x1a^\x99\x1f3\xe0\xa5'\\0\xc3\x81\xdf\xd4\xd0C\x9ct\x0f\x02\x18f\xdbf\xd0\xedZ5\xdeD\x0b\xe0H:Y\xc4"  # noqa: E501

    return new_key == key


@st.cache()
def _cached_download_load_models_kpis() -> ModelsKPIs:
    return download_load_models_kpis()


MODELS_KPIS = _cached_download_load_models_kpis()
PERIODIC_MODELS_UPDATES = 30  # periodic model updates, in seconds

session_state = SessionState.get(datetime_now=datetime.now())

if (datetime.now() - session_state.datetime_now).seconds > PERIODIC_MODELS_UPDATES:  # type: ignore
    logger.info(
        f"Periodically (More than {PERIODIC_MODELS_UPDATES} seconds since last interaction with the demo) redownloading models kpis..."
    )
    MODELS_KPIS = download_load_models_kpis()
    session_state.datetime_now = datetime.now()  # type: ignore


def _get_images(
    id_start: int, id_stop: int, path: str, image_type: str
) -> Tuple[np.ndarray, List[str]]:
    paths_images = [
        os.path.join(path, f"{image_type}_{str(i).zfill(5)}.jpg") for i in range(id_start, id_stop)
    ]
    images = []
    for path_image in paths_images:
        try:
            images.append(np.array(Image.open(path_image))[:, :, :3])
        except FileNotFoundError:
            pass
    return np.stack(images, axis=0), paths_images


@st.cache(allow_output_mutation=True)
def _load_array(filename: str) -> np.ndarray:
    array = joblib.load(filename=filename)
    if isinstance(array, List):
        return np.array(array)
    else:
        return array


@st.cache(allow_output_mutation=True)
def _load_pi(filename: str) -> Tuple[float, List[Tuple[float, float]]]:
    """Load the (prediction_interval, [(low_pred_1, high_pred_1), ...])."""
    pis: Tuple[float, List[Tuple[float, float]]] = joblib.load(filename=filename)
    return pis


def _display_image_and_prediction(
    image: np.ndarray,
    image_name: str,
    path_original: str,
    prediction: np.ndarray,
    prediction_counts: int,
    pi: float,
    prediction_quantile_low: float,
    prediction_quantile_high: float,
    width: int = 600,
    height: int = 600,
) -> hv.Layout:
    plot = (
        hv.RGB(image).opts(
            width=width,
            height=height,
            title=f"original image: {os.path.basename(image_name)}  (compressed: {os.path.basename(path_original)})",
        )
        + hv.RGB(prediction).opts(
            width=width,
            height=height,
            title=f"Predicted counts: {prediction_counts} ({pi}% PI [{prediction_quantile_low}; {prediction_quantile_high}])",
        )
    ).cols(2)
    return plot


def main() -> None:
    """Run app."""
    password = st.sidebar.text_input("Log in", type="password")
    if _verify_password(password):

        # display models names and KPIs
        # -----------------------------
        show_explainations = st.sidebar.checkbox(label="Show Explainations", value=True)
        if show_explainations:
            st.write(
                """
            # CFU Counting algorithm predictions demo

            This demo displays and compares KPIs and visualizes predictions of various Deep Learning models.

            The sidebar options allow you to choose
            - wether to display the KPIs and which ones (by default, the `Main` KPIs agreed upon with the end-users are displayed). The metrics can be interpreted as follows
              - `MAE` (Mean Absolute Error), e.g.
                - `0.01 MAE 0` means the model predictions on dishes without CFU are on average off by 0.01 CFU
                - `0.2 MAE 1-5` means the model predictions on dishes with 5-10 CFUs are on average off by 0.2 CFU
              - `MAPE` (Mean Absolute Percentage Error), which is better suited for dishes with a high variability in the number of CFUs as predictions errors on dishes with few or many CFUs equaly penalize the overall performance, e.g.
                - `5 MAPE 11+` means the model predictions on dishes with 11 and more CFUs are on average off by 5% of the real number of CFUs
            - the model to display predictions from by name or best performance on various KPIs
            - which images and predictions to display
                - Train: the labelled dishes the model was trained on
                - Test: the labelled dishes unseen by the model during training which the KPIs were evaluated on
                - Unlabelled positive: the unlabelled dishes taken by the scan 4000
            - the image side size, which you can adapt to match the resolution of your screen
            - the number of images and predictions to load and display simultaneously
            - the page number
            """
            )
        show_models_kpis = st.sidebar.checkbox(label="Show models KPIs", value=True)
        models_kpis_types = st.sidebar.multiselect(
            label="Show models KPIs", options=["Main", "MAE", "MAPE", "Other"], default=["Main"]
        )
        if show_models_kpis:
            st.write("## KPIs")
            kpis_main, kpis_mae, kpis_mape, kpis_other = json_to_df_model_kpis(
                models_kpis=MODELS_KPIS
            )
            if "Main" in models_kpis_types:
                st.write("### Main")
                st.table(kpis_main.style.format("{:.2f}"))
            if "MAE" in models_kpis_types:
                st.write("### MAE (Mean Absolute Error) KPIs (in counts)")
                st.table(kpis_mae.style.format("{:.2f}"))
            if "MAPE" in models_kpis_types:
                st.write("### MAPE (Mean Absolute Percentage Error) KPIs (in % counts)")
                st.table(kpis_mape.style.format("{:.1f}"))
            if "Other" in models_kpis_types:
                st.write("### Other KPIs")
                st.table(kpis_other.style.format("{:.1f}"))

        # buttons model selection
        # -----------------------

        select_model_by = st.sidebar.selectbox(
            "Select model by", options=["Best performance on", "Name"], index=0
        )

        if select_model_by == "Best performance on":
            task = st.sidebar.selectbox(
                "Task",
                options=[
                    _task
                    for _task in MODELS_KPIS.models[0].kpis.fields.keys()
                    if not any(substr in _task for substr in ["ratio", "bbox", "segm"])
                ],
                index=0,
            )
            metric = st.sidebar.selectbox(
                "Metric", options=list(MODELS_KPIS.models[0].kpis.dict()[task].keys()), index=1,
            )

            # get best model name
            model_name = get_best_model_name(models_kpis=MODELS_KPIS, task=task, metric=metric)

        else:  # by Name
            model_name = st.sidebar.selectbox(
                "Names",
                options=list(
                    reversed([model.name for model in MODELS_KPIS.models if model.available])
                ),  # show latest models first as they are hopefully the ones one would like to inspect in priority
                index=0,
            )

        # display and download model if needed
        # ------------------------------------
        st.write("# Predictions")
        st.sidebar.markdown("## Model")
        st.sidebar.markdown(model_name)

        # load model name if needed and update the paths
        download_unzip_clean_predictions(predictions_name=model_name, overwrite=False)
        PATH = os.path.join(PATH_PREDICTIONS_ON_DISK, model_name)
        PATH_TRAIN = os.path.join(PATH, "train")
        PATH_TEST = os.path.join(PATH, "test")
        PATH_POSITIVE_UNLABELLED = os.path.join(PATH, "positive_unlabelled")

        # load data
        # ---------
        images_names = {
            "Train": _load_array(os.path.join(PATH_TRAIN, "filenames.lz4")),
            "Test": _load_array(os.path.join(PATH_TEST, "filenames.lz4")),
            "Positive_Unlabelled": _load_array(
                os.path.join(PATH_POSITIVE_UNLABELLED, "filenames.lz4")
            ),
        }
        images_counts = {
            "Train": _load_array(os.path.join(PATH_TRAIN, "counts.lz4")),
            "Test": _load_array(os.path.join(PATH_TEST, "counts.lz4")),
            "Positive_Unlabelled": _load_array(
                os.path.join(PATH_POSITIVE_UNLABELLED, "counts.lz4")
            ),
        }
        images_counts_pi = {
            "Train": _load_pi(os.path.join(PATH_TRAIN, "PIs.lz4")),
            "Test": _load_pi(os.path.join(PATH_TEST, "PIs.lz4")),
            "Positive_Unlabelled": _load_pi(os.path.join(PATH_POSITIVE_UNLABELLED, "PIs.lz4")),
        }

        # buttons data display
        # --------------------
        data_type = st.sidebar.selectbox(
            "Data type", options=["Train", "Test", "Positive_Unlabelled"], index=1
        )
        side = st.sidebar.slider(
            "Image side size", min_value=100, max_value=1000, step=100, value=600
        )
        batch_size = st.sidebar.slider(
            "Nb of images to display on a page", min_value=1, max_value=30, step=1, value=4
        )
        n_original_images = images_names[data_type].shape[0]
        n_batches = n_original_images // batch_size
        n_batches = n_batches - 1 if n_original_images % batch_size == 0 else n_batches

        batch_id = st.sidebar.slider("Page #", min_value=0, max_value=n_batches, step=1,)
        id_start = batch_size * batch_id
        id_stop = (batch_size * batch_id) + batch_size

        # load images of interest
        # -----------------------
        images_original, paths_original = _get_images(
            id_start=id_start,
            id_stop=id_stop,
            path=os.path.join(PATH, data_type.lower()),
            image_type="image",
        )
        images_predicted, _ = _get_images(
            id_start=id_start,
            id_stop=id_stop,
            path=os.path.join(PATH, data_type.lower()),
            image_type="prediction",
        )

        # display image and prediction
        # ----------------------------
        for (
            image,
            image_name,
            path_original,
            prediction,
            prediction_counts,
            prediction_counts_pi,
        ) in zip(
            images_original,
            images_names[data_type][id_start:id_stop],
            paths_original,
            images_predicted,
            images_counts[data_type][id_start:id_stop],
            images_counts_pi[data_type][1][id_start:id_stop],
        ):
            st.bokeh_chart(
                hv.render(
                    _display_image_and_prediction(
                        image=image,
                        image_name=image_name,
                        path_original=path_original,
                        prediction=prediction,
                        prediction_counts=prediction_counts,
                        pi=images_counts_pi[data_type][0],
                        prediction_quantile_low=prediction_counts_pi[0],
                        prediction_quantile_high=prediction_counts_pi[1],
                        width=side,
                        height=side,
                    ),
                    backend="bokeh",
                ),
                use_container_width=False,
            )


if __name__ == "__main__":
    main()
