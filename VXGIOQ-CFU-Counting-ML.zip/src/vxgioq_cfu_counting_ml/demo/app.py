"""!!!!!!DEPRECATED!!!!!!!!!!Demo Streamlit app."""

import hashlib
import logging
import os
from io import BytesIO
from typing import Any, Dict, List

import holoviews as hv
import numpy as np
import streamlit as st
import torch
from detectron2 import model_zoo
from detectron2.config import get_cfg
from detectron2.engine import DefaultPredictor
from PIL import Image

from vxgioq_cfu_counting_ml.utils.azure import (
    PATH_DATA_ON_DISK,
    PATH_MODELS_ON_DISK,
    download_unzip_clean_data,
    download_unzip_clean_model,
)
from vxgioq_cfu_counting_ml.utils.convert import enhance_detectron2_dataset
from vxgioq_cfu_counting_ml.utils.custom_datasets import func_dataset
from vxgioq_cfu_counting_ml.utils.display import display_enhanced_dataset, display_image
from vxgioq_cfu_counting_ml.utils.types import Detectron2DatasetElement, Detectron2DatasetEnhanced

logger = logging.getLogger(__name__)


# settings
# ========
st.set_option("deprecation.showfileUploaderEncoding", False)
hv.extension("bokeh")
width = height = 500
path_models = PATH_MODELS_ON_DISK
model_names = ["model_sprint_1.pth", "model_sprint_2.pth"]

data_name = "dataset_original_gsk_0_80"
path_data = f"{PATH_DATA_ON_DISK}/{data_name}"
path_data_train = f"{path_data}/train"
path_data_test = f"{path_data}/test"


# functions
# =========


@st.cache()
def _download_models() -> None:
    """Download the models once."""
    for model_name in model_names:
        download_unzip_clean_model(model_name=f"{model_name}.zip")


@st.cache()
def _download_data() -> None:
    """Download the data once."""
    download_unzip_clean_data(data_name=f"{data_name}.zip")


def _verify_password(password_to_check: str) -> bool:
    """Verify the password."""
    new_key = hashlib.pbkdf2_hmac(
        hash_name="sha256",
        password=password_to_check.encode("utf-8"),
        salt=b"\xc5|P\xcd\xd7\x05Gss\x97o\xfd\r\xf9a\xc3\xb5w\xbeWt\x11o*-a\xda\xc2\xb1g:\x00",  # noqa: E501
        iterations=100000,
        dklen=128,
    )
    key = b"\xa1\x1c\xc9\xbf\x9f\x86z\x95\x80m\x15O\x99\x9f\x16\x00~\xdeS\xe5\xc2\xd3~\n\xaaLN\xa9\x9a\xe68\xbfMb\xb1\x1b-&\xc6\xebc\xcf\xdac\x1d\xda\xb5\x89\xc5\xb2\x0bd\x07k\xc7\x95\x16\xdd\xbd \xad\x83\xe7?\xeb\x9288\x01Gsi7\rW\xfa\xf2W\x05\xec\x9f7\x93S3Q\xc8\xa8\xa4\x83v:\x1a^\x99\x1f3\xe0\xa5'\\0\xc3\x81\xdf\xd4\xd0C\x9ct\x0f\x02\x18f\xdbf\xd0\xedZ5\xdeD\x0b\xe0H:Y\xc4"  # noqa: E501

    return new_key == key


@st.cache()
def _load_predictor(path_model: str) -> DefaultPredictor:
    """Load predictor."""
    # Load model predictor
    cfg = get_cfg()
    model_cfg = "COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml"
    cfg.merge_from_file(model_zoo.get_config_file(model_cfg))
    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5
    if not torch.cuda.is_available():
        logger.info("CUDA is not available, using CPU.")
        cfg["MODEL"]["DEVICE"] = "cpu"
    else:
        logger.info("CUDA is available, using GPU.")
    cfg.MODEL.RETINANET.NUM_CLASSES = 1
    cfg.MODEL.ROI_HEADS.NUM_CLASSES = 1
    cfg.MODEL.WEIGHTS = path_model
    cfg.TEST.DETECTIONS_PER_IMAGE = 300
    predictor = DefaultPredictor(cfg)
    return predictor


@st.cache()
def _load_data(images_directory: str) -> List[Dict[str, Any]]:
    """Compute and cache the data."""
    return func_dataset(folder=images_directory)


# @st.cache()
# def load_metadata(dataset_catalog_name: str) -> Metadata:
#     """Load metadata."""
#     return MetadataCatalog.get(dataset_catalog_name)


# @st.cache()
# def _register_train_test_datasets() -> List[str]:
#     """Register the train and test datasets and return their names."""
#     dataset_catalog_name_root = func_dataset.__name__[5:]
#     dataset_catalog_names = []
#     for dataset_type in ["train", "test"]:
#         dataset_catalog_name = f"{dataset_catalog_name_root}_{dataset_type}"
#         DatasetCatalog.register(
#             dataset_catalog_name,
#             lambda dataset_type=dataset_type: func_dataset(
#                 images_directory=os.path.join(path_data, dataset_type)
#             ),
#         )
#         MetadataCatalog.get(dataset_catalog_name).set(thing_classes=["CFU"])
#         dataset_catalog_names.append(dataset_catalog_name)

#     return dataset_catalog_names


# def load_image_compute_label(
#     dataset: DatasetsFormat, metadata: Metadata
# ) -> Tuple[np.ndarray, np.ndarray, str, int]:
#     """
#     Load image and compute the corresponding labels.

#     Useful for images comming from a dataset registered with detectron2.
#     """
#     # make slider
#     image_id = st.sidebar.slider(metadata.name, min_value=0, max_value=len(dataset) - 1, step=1)

#     def _load_image_compute_label(
#         image_id: int, dataset: DatasetsFormat
#     ) -> Tuple[np.ndarray, np.ndarray, str, int]:
#         # load original image
#         data = dataset[image_id]
#         image_original = cv2.imread(data["file_name"])
#         labels_count = len(data["annotations"])  # type: ignore

#         # compute labeled image
#         image_labeled = draw_labels(image_original, data)

#         image_path = data["file_name"]
#         if isinstance(image_path, str):
#             return image_original, image_labeled, image_path, labels_count
#         else:
#             raise ValueError("image_path is not a `str`.")

#     return _load_image_compute_label(image_id, dataset)


# def train_test_selection(image_source: str) -> Tuple[np.ndarray, np.ndarray, str, int]:
#     """Train test selection flow."""
#     if image_source == "Train":
#         dataset = dataset_train
#         metadata = metadata_train
#     else:
#         dataset = dataset_test
#         metadata = metadata_test

#     image_original, image_labeled, image_path, labels_count = load_image_compute_label(
#         dataset=dataset, metadata=metadata
#     )
#     return image_original, image_labeled, image_path, labels_count


# def upload_selection() -> Tuple[Optional[np.ndarray], Optional[str]]:
#     """Upload selection flow."""
#     image_upload = st.sidebar.file_uploader(
#         "Upload",
#         type=["png", "jpg", "jpeg"],
#         encoding=None,
#         accept_multiple_files=False,  # cannot really accept multiple files yet
#     )
#     if image_upload is not None:
#         image = np.array(Image.open((image_upload)))[:, :, :3]
#         return image, image_upload
#     else:
#         return None, None


# @st.cache()
# def draw_labels(image: np.ndarray, data_dict: Detectron2DatasetElement) -> np.ndarray:
#     """Draw labels on original image."""
#     return Visualizer(image).draw_dataset_dict(data_dict).get_image()


# def display_images(
#     image_original: np.ndarray,
#     image_labeled: Optional[np.ndarray],
#     image_prediction: np.ndarray,
#     image_path: Optional[str],
#     counts_labels: Optional[int],
#     counts_predictions: int,
# ) -> Layout:
#     """Display original, (labeled), and predicted image."""
#     if image_labeled is not None:
#         return (
#             hv.RGB(image_original, label="Original").opts(
#                 width=width, height=height, xaxis=None, yaxis=None,
#             )
#             + hv.RGB(image_labeled, label=f"Label - {counts_labels} CFU(s)").opts(
#                 width=width, height=height, xaxis=None, yaxis=None
#             )
#             + hv.RGB(image_prediction, label=f"Prediction - {counts_predictions} CFU(s)").opts(
#                 width=width, height=height, xaxis=None, yaxis=None
#             )
#         ).opts(title=f"File: {image_path}")
#     else:
#         return hv.RGB(image_original, label="Original").opts(
#             width=width, height=height, xaxis=None, yaxis=None
#         ) + hv.RGB(image_prediction, label=f"Prediction - {counts_predictions} CFU(s)").opts(
#             width=width, height=height, xaxis=None, yaxis=None
#         )


def _list_models(path_models: str) -> List[str]:
    """List available models."""
    return [model for model in os.listdir(path_models) if model.split(".")[-1] == "pth"]


@st.cache()
def prepare_predictors(path_models: str) -> Dict[str, DefaultPredictor]:
    """Load all predictors/models."""
    models_names = _list_models(path_models)
    return {
        model_name: _load_predictor(os.path.join(path_models, model_name))
        for model_name in models_names
    }


@st.cache()
def _enhance_detectron2_dataset(
    datasets_dicts: List[List[Detectron2DatasetElement]],
    datasets_names: List[str],
    predictors: Dict[str, DefaultPredictor],
) -> Dict[str, Dict[str, Detectron2DatasetEnhanced]]:
    """Compute the model predictions for various datasets and models and enhance the dataset_dicts format."""
    logger.info("Enhancing datasets for all available models...")
    enhanced_predictors_datasets_dicts: Dict[str, Dict[str, Detectron2DatasetEnhanced]] = {}
    for predictor_name, predictor in predictors.items():
        enhanced_predictors_datasets_dicts[predictor_name] = {}
        for dataset_dicts, dataset_name in zip(datasets_dicts, datasets_names):
            enhanced_predictors_datasets_dicts[predictor_name][
                dataset_name
            ] = enhance_detectron2_dataset(dataset=dataset_dicts, predictor=predictor)
    return enhanced_predictors_datasets_dicts


@st.cache()
def _convert_uploaded_image(image_upload: BytesIO) -> np.ndarray:
    """Convert a streamlit uploaded BytesIO image to a numpy array."""
    image = np.array(Image.open((image_upload)))[:, :, :3]
    return image


@st.cache(allow_output_mutation=True)
def _display_image(image_uploaded: np.ndarray, predictor_name: str) -> hv.DynamicMap:
    """Display and cache an image with it's computed prediction."""
    return display_image(image_uploaded, predictor_name)


def main() -> None:
    """Run script."""
    # Initial loading
    # ===============

    # download data if need be
    _download_data()

    # download models if need be
    _download_models()

    # register the train and test datasets
    # dataset_train_name, dataset_test_name = _register_train_test_datasets()

    # prepare the train and test datasets
    dataset_train = _load_data(path_data_train)
    dataset_test = _load_data(path_data_test)
    # metadata_train = load_metadata(dataset_train_name)
    # metadata_test = load_metadata(dataset_test_name)

    # prepare models
    predictors = prepare_predictors(path_models)

    # prepare enhanced datasets
    datasets_predictors_enhanced = _enhance_detectron2_dataset(
        [dataset_train, dataset_test], ["Train", "Test"], predictors
    )
    # st.write(datasets_predictors_enhanced)

    password = st.sidebar.text_input("Log in", type="password")
    if _verify_password(password):

        # Root sidebar
        # ============
        st.sidebar.markdown("## Model")
        predictor_name = st.sidebar.selectbox("Name", list(predictors.keys()))
        predictor = predictors[predictor_name]

        # st.sidebar.markdown("## Dish Image")
        # image_source = st.sidebar.selectbox("Source", ("Train", "Test", "New"))

        image_id_train = st.sidebar.slider(
            "Train",
            min_value=0,
            max_value=len(datasets_predictors_enhanced[model_names[0]]["Train"]) - 1,
            step=1,
        )

        image_id_test = st.sidebar.slider(
            "Test",
            min_value=0,
            max_value=len(datasets_predictors_enhanced[model_names[0]]["Test"]) - 1,
            step=1,
        )

        image_uploaded_stream = st.sidebar.file_uploader(
            "Upload",
            type=["png", "jpg", "jpeg"],
            encoding=None,
            accept_multiple_files=False,  # cannot really accept multiple files yet
        )

        # Main pannel
        # ===========

        # title
        st.markdown("# VXGIOQ CFU Counting")
        st.markdown("## ML demo")

        # # image selection
        # image_original = None
        # image_labeled = None
        # image_path = None
        # labels_count = None
        # if image_source in ["Train", "Test"]:
        #     image_original, image_labeled, image_path, labels_count = train_test_selection(
        #         image_source=image_source
        #     )
        # if image_source == "New":
        #     image_original, image_path = upload_selection()

        # if image_original is None:
        #     st.stop()

        # # compute predictions
        # prediction = predictor(image_original)["instances"].to("cpu")
        # image_prediction = (
        #     Visualizer(image_original).draw_instance_predictions(prediction).get_image()
        # )

        # display images (original, (labeled), predictions)

        st.write("## Train dataset")
        st.bokeh_chart(
            hv.render(
                display_enhanced_dataset(
                    dataset_enhanced=[
                        datasets_predictors_enhanced[predictor_name]["Train"][image_id_train]
                    ],
                    width=600,
                    height=600,
                ),
                backend="bokeh",
            ),
            use_container_width=False,
        )

        st.write("## Test dataset")
        st.bokeh_chart(
            hv.render(
                display_enhanced_dataset(
                    dataset_enhanced=[
                        datasets_predictors_enhanced[predictor_name]["Test"][image_id_test]
                    ],
                    width=600,
                    height=600,
                ),
                backend="bokeh",
            ),
            use_container_width=False,
        )

        st.write("## Upload an image")
        if image_uploaded_stream is not None:
            image_uploaded = _convert_uploaded_image(image_uploaded_stream)
            st.bokeh_chart(
                hv.render(_display_image(image_uploaded, predictor), backend="bokeh",),
                use_container_width=False,
            )

        # st.bokeh_chart(
        #     hv.render(
        #         display_images(
        #             image_original=image_original,
        #             image_labeled=image_labeled,
        #             image_prediction=image_prediction,
        #             image_path=image_path,
        #             counts_labels=labels_count,
        #             counts_predictions=len(prediction),
        #         ),
        #         backend="bokeh",
        #     ),
        #     use_container_width=False,
        # )

        # Set-up model and parameters predictions
        # ---------------------------------------


if __name__ == "__main__":
    main()
