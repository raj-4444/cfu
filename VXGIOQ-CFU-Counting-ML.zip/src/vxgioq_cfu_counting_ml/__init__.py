"""VXGIOQ-CFU-Counting-ML package."""

import logging

from vxgioq_cfu_counting_ml.utils.config import configure_root_logger

__version__ = "0.0.0"

__all__ = ["__version__", "configure_root_logger"]

configure_root_logger(logging.INFO)
