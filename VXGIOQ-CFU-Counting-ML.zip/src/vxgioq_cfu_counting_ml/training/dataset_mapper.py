"""Extensions of the detectron2 `dataset_mapper` module."""

import copy
import logging
from typing import Any, Dict

import numpy as np
import torch
from detectron2.data import detection_utils as utils
from detectron2.data import transforms as T
from detectron2.data.dataset_mapper import DatasetMapper
from detectron2.structures.masks import PolygonMasks

from vxgioq_cfu_counting_ml.utils.types import Detectron2DatasetElement, ModelInputFormat

logger = logging.getLogger(__name__)


class CFUDatasetMapper(DatasetMapper):
    """
    Extend the detectron2 `DatasetMapper`.

    Currently, this extension
    - computes the Instances from the Detectron2Annotations, even when not in training mode.
    """

    def __call__(self, dataset_dict: Dict[str, Any]) -> ModelInputFormat:
        """
        Convert the Detectron2DatasetElement into a detectron2 readable format.

        Parameters
        ----------
        dataset_dict
            Metadata of one image, in Detectron2 Dataset format.

        Returns
        -------
        model_input
            a format that builtin models in detectron2 accept.
        """
        dataset = copy.deepcopy(Detectron2DatasetElement(**dataset_dict))
        model_input: ModelInputFormat = {}

        # Read image to BGR is cfg.FORMAT = BGR (USER: Write your own image loading if it's not from a file)
        image = utils.read_image(dataset.file_name, format=self.image_format)
        utils.check_image_size(dataset_dict, image)

        aug_input = T.StandardAugInput(image)
        #transforms = aug_input.apply_augmentations(self.augmentations)
        #image, _ = aug_input.image, aug_input.sem_seg
        transforms = self.augmentations(aug_input)
        image, _ = aug_input.image, aug_input.sem_seg

        image_shape = image.shape[:2]  # h, w
        # Pytorch's dataloader is efficient on torch.Tensor due to shared-memory,
        # but not efficient on large generic data structures due to the use of pickle & mp.Queue.
        # Therefore it's important to use torch.Tensor.
        model_input["image"] = torch.as_tensor(np.ascontiguousarray(image.transpose(2, 0, 1)))

        dataset_dict = copy.deepcopy(dataset.dict())
        if "annotations" in dataset_dict:
            # USER: Implement additional transformations if you have other types of data
            annos = [
                utils.transform_instance_annotations(
                    obj, transforms, image_shape, keypoint_hflip_indices=self.keypoint_hflip_indices
                )
                for obj in dataset_dict.pop("annotations")
            ]
            instances = utils.annotations_to_instances(
                annos, image_shape, mask_format=self.instance_mask_format
            )
            if len(annos) == 0:
                # Add empty polygon mask to instances in case of images without instances
                instances.gt_masks = PolygonMasks([])

            # After transforms such as cropping are applied, the bounding box may no longer
            # tightly bound the object. As an example, imagine a triangle object
            # [(0,0), (2,0), (0,2)] cropped by a box [(1,0),(2,2)] (XYXY format). The tight
            # bounding box of the cropped triangle should be [(1,0),(2,1)], which is not equal to
            # the intersection of original bounding box and the cropping box.
            if self.recompute_boxes:
                instances.gt_boxes = instances.gt_masks.get_bounding_boxes()
            model_input["instances"] = utils.filter_empty_instances(instances)
            model_input = {**model_input, **dataset_dict}

            # fill in content of
        return model_input
