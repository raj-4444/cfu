"""Analysis tools."""
import logging
import os
import pickle  # noqa: S403
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import joblib
import numpy as np
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.config import get_cfg
from detectron2.config.config import CfgNode
from detectron2.evaluation import verify_results
from detectron2.structures import BoxMode
from detectron2.utils import comm
from detectron2.utils.visualizer import Visualizer
from PIL import Image
from tqdm.auto import tqdm

from vxgioq_cfu_counting_ml.training.organize_data import (
    get_paths_positive_unlabelled_images,
    get_paths_test_images,
    get_paths_train_images,
)
from vxgioq_cfu_counting_ml.training.trainer import CFUTrainer
from vxgioq_cfu_counting_ml.utils.azure import (
    MODEL_CONFIG_NAME,
    MODEL_EVENTS_NAME,
    MODEL_LAST_CHECKPOINT_NAME,
    MODEL_WEIGHTS_NAME,
    PATH_MODELS_ON_DISK,
    PATH_PREDICTIONS_ON_DISK,
    zip_upload_predictions_to_blob,
)
from vxgioq_cfu_counting_ml.utils.conf import delete_folders
from vxgioq_cfu_counting_ml.utils.evaluator import CFUEvaluator
from vxgioq_cfu_counting_ml.utils.loader import find_backbone, load_images
from vxgioq_cfu_counting_ml.utils.metrics import calibration, mae, mse
from vxgioq_cfu_counting_ml.utils.predictor import CFUPredictor
from vxgioq_cfu_counting_ml.utils.types import (
    DatasetEvaluatorResults,
    Detectron2DatasetElement,
    KPIs,
    Model,
    ModelsKPIs,
    Quantile,
    Sharpness,
)

logger = logging.getLogger(__name__)


def compute_kpis(cfg: CfgNode) -> DatasetEvaluatorResults:
    """Compute the KPIs for a given model and config."""
    cfg_ = cfg.clone()  # cfg can be modified by model
    model = CFUTrainer.build_model(cfg_)

    # a checkpointer is needed to load the weights into the model\n",
    checkpointer = DetectionCheckpointer(model)
    checkpointer.load(cfg_.MODEL.WEIGHTS)

    res: DatasetEvaluatorResults = CFUTrainer.test(cfg_, model)
    if cfg.TEST.AUG.ENABLED:
        res.update(CFUTrainer.test_with_TTA(cfg, model))
    if comm.is_main_process():
        verify_results(cfg, res)
    return res


def construct_model_info(cfg: CfgNode) -> Model:
    """Construct the model, i.e. uuid name, datetime, backbone and number of iterations."""
    model: Model = Model(
        name=os.path.basename(cfg.OUTPUT_DIR),
        datetime_finished=datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        backbone=find_backbone(cfg),
        iteration=cfg.SOLVER.MAX_ITER,
        available=True,
        kpis=KPIs(**compute_kpis(cfg)),
    )
    return model


def get_dataset_stats(
    dataset: List[Detectron2DatasetElement],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute the bbox sizes (sqrt(bbox_area)), aspect rations (height / width) and their number and images channels pixels values in a list of detectron2 dataset.

    It's useful to know the expected max number of instances on an image to properly set-up the DETECTIONS_PER_IMAGE.

    It's useful to set-up mask-r-cnn anchor generator. In deed, if the anchors generated are, e.g.
        - way too big, even after refinement, the bboxes will never be able to find or fit small objects.
        - always squarish, even after refinement, the bboxes will never be able to find or fit very elongated rectangles.

    It's also useful to properly normalize the image pixel's values according to the data distribution.

    Returns
    -------
    bbox_per_images
    bbox_sizes
    bbox_aspects
    pixels_blue
    pixels_green
    pixels_red
    """
    bbox_per_images: List[int] = []
    bbox_sizes = []
    bbox_aspects = []
    pixels_blue = []
    pixels_green = []
    pixels_red = []

    min_size: Optional[float] = None
    max_size: Optional[float] = None
    min_size_file: str
    max_size_file: str

    min_aspect: Optional[float] = None
    max_aspect: Optional[float] = None
    min_aspect_file: str
    max_aspect_file: str

    for dataset_element in tqdm(dataset):
        # load image (BGR) and keep track of channels
        image = cv2.imread(dataset_element.file_name)
        raveled_channels = [image[:, :, i].ravel().tolist() for i in range(3)]
        pixels_blue.extend(raveled_channels[0])
        pixels_green.extend(raveled_channels[1])
        pixels_red.extend(raveled_channels[2])

        # count bboxes
        bbox_per_images.append(len(dataset_element.annotations))

        for annotation in dataset_element.annotations:
            # extract bbox info
            if annotation.bbox_mode is BoxMode.XYXY_ABS:
                x_min, y_min, x_max, y_max = annotation.bbox
                width: int = x_max - x_min
                height: int = y_max - y_min
            elif annotation.bbox_mode is BoxMode.XYWH_ABS:
                x_min, y_min, width, height = annotation.bbox

            else:
                raise ValueError(f"Unsupported Boxmode: {annotation.bbox_mode}.")

            # compute bbox area
            bbox_area = width * height
            bbox_size = np.sqrt(bbox_area)
            bbox_sizes.append(bbox_size)

            # compute bbox aspect ratio
            bbox_aspect = width / height
            bbox_aspects.append(bbox_aspect)

            # keep track of images corresponding to min and max bbox sizes
            if not min_size or bbox_size < min_size:
                min_size = bbox_size
                min_size_file = dataset_element.file_name

            if not max_size or bbox_size > max_size:
                max_size = bbox_size
                max_size_file = dataset_element.file_name

            # keep track of images corresponding to min and max bbox aspect ratios
            if not min_aspect or bbox_aspect < min_aspect:
                min_aspect = bbox_aspect
                min_aspect_file = dataset_element.file_name

            if not max_aspect or bbox_aspect > max_aspect:
                max_aspect = bbox_aspect
                max_aspect_file = dataset_element.file_name

    logger.info(f"File with smallest bbox size: {min_size_file}.")
    logger.info(f"File with biggest bbox size: {max_size_file}.")

    logger.info(f"File with smallest bbox apect: {min_aspect_file}.")
    logger.info(f"File with biggest bbox aspect: {max_aspect_file}.")
    return (
        np.array(bbox_per_images),
        np.array(bbox_sizes),
        np.array(bbox_aspects),
        np.array(pixels_blue),
        np.array(pixels_green),
        np.array(pixels_red),
    )


def get_cfu_evaluator_old_kpis(model: Model) -> Dict[str, List[str]]:
    """Get the CFUEvaluator old KPIs from the models KPIs."""
    old_kpis = deepcopy(model.kpis.dict())
    del old_kpis["bbox"]
    del old_kpis["segm"]
    return {task: list(metrics) for task, metrics in old_kpis.items()}


def _log_data_differences(old_data: List[str], new_data: List[str]) -> None:
    """Log the differences between old and new data folders."""
    added_data_folders = set(new_data).difference(set(old_data))
    removed_data_folders = set(old_data).difference(set(new_data))
    if len(added_data_folders) > 0:
        logger.info(f"New data folders where added: {added_data_folders}.")
    if len(removed_data_folders) > 0:
        logger.warning(f"Pre-existing data folders where deleted: {removed_data_folders}.")


def _log_kpis_differences(old_kpis: Dict[str, List[str]], new_kpis: Dict[str, List[str]]) -> None:
    """Log the differences between old and new KPIs, i.e. new and old tasks and metrics."""
    for new_task, new_metrics in new_kpis.items():
        old_tasks = list(old_kpis.keys())
        if new_task not in old_tasks:
            logger.info(
                f"New task: `{new_task}` added with the following new metric(s): `{new_metrics}`."
            )
        else:
            old_metrics = old_kpis[new_task]
            if new_metrics != old_metrics:
                logger.info(
                    f"Task: `{new_task}` has the following new metric(s) that were added to it: `{list(set(new_metrics).difference(set(old_metrics)))}`."
                )
                logger.info(
                    f"Task: `{new_task}` has the following old metric(s) that were removed from it: `{list(set(old_metrics).difference(set(new_metrics)))}`."
                )

    for old_task, old_metrics in old_kpis.items():
        new_tasks = list(new_kpis.keys())
        if old_task not in new_tasks:
            logger.info(
                f"Old task: `{old_task}` removed with the following old metric(s): `{old_metrics}`."
            )


def _compute_quantiles(model: Model, cfg: CfgNode) -> Tuple[Quantile, Quantile, float, Sharpness]:
    """Compute the actual and test expected quantiles."""
    _pis_low = []
    _pis_high = []
    _n_cfus_actual = []
    predictor = CFUPredictor(model.name.split(".zip")[0])
    for dataset_name in cfg.DATASETS.TEST:
        data_loader = CFUTrainer.build_test_loader(cfg, dataset_name)
        for inputs in data_loader:
            image = inputs[0]["image"].numpy().transpose(1, 2, 0)
            _n_cfus_actual.append(len(inputs[0]["instances"]))
            prediction = predictor.predict_quantiles([image])[0]
            pi_low, pi_high = prediction.quantiles_predictions
            _pis_low.append(pi_low.prediction)
            _pis_high.append(pi_high.prediction)

    n_cfus_actual = np.array(_n_cfus_actual)
    pis_low: np.ndarray = np.array(_pis_low)
    pis_high: np.ndarray = np.array(_pis_high)

    quantile_low_actual_test = (n_cfus_actual < pis_low).sum() / len(n_cfus_actual)
    quantile_low = Quantile(
        expected=predictor.models_pi.low.quantile.expected,
        actual_train=None,
        actual_test=quantile_low_actual_test,
    )

    quantile_high_actual_test = (n_cfus_actual < pis_high).sum() / len(n_cfus_actual)
    quantile_high = Quantile(
        expected=predictor.models_pi.high.quantile.expected,
        actual_train=None,
        actual_test=quantile_high_actual_test,
    )
    calib = calibration(
        pi_expected=quantile_high.expected - quantile_low.expected,
        pi_actual=quantile_high_actual_test - quantile_low_actual_test,
    )
    sharpness = Sharpness(mae=mae(pis_high, pis_low), mse=mse(pis_high, pis_low))

    return quantile_low, quantile_high, calib, sharpness


def check_retest_models(
    models_kpis: ModelsKPIs, data_folders: List[str], n_examples: int
) -> ModelsKPIs:
    """Check if new data folders or new CFUEvaluator KPIs were added since last time KPIs where computed on the pre-existing models, recompute KPIs if so and return updated models_kpis."""
    models_kpis = deepcopy(models_kpis)

    # gather old and new data folders
    old_data_folders: List[str] = models_kpis.data.folders
    old_n_examples = models_kpis.data.n_examples

    # gather new CFUEvaluator KPIs
    cfu_kpis = CFUEvaluator().get_tasks_metrics()
    logger.info(
        "Checking if new data folders and/or CFUEvaluator KPIs are available since last models KPIs measurements..."
    )
    if data_folders != old_data_folders:
        logger.info(
            "Mismatch between old and new data folders, need to recompute KPIs for pre-existing models..."
        )
        # check if folders where added and/or deleted
        _log_data_differences(old_data=old_data_folders, new_data=data_folders)

    elif old_n_examples < n_examples:
        logger.info(
            "More examples since last models evaluation, need to recompute KPIs for pre-existing models..."
        )

    # loop on all models and check if a model needs KPIs recomputation based on new data and/or new KPIs
    for i, model in enumerate(models_kpis.models):
        # gather old CFUEvaluator KPIs
        old_cfu_kpis = get_cfu_evaluator_old_kpis(model=model)
        if (
            data_folders == old_data_folders and old_n_examples == n_examples
        ) and cfu_kpis == old_cfu_kpis:
            logger.info(f"Model {model.name} IS up to date data and kpis-wise, nothing to do.")
            continue
        elif (
            data_folders != old_data_folders or old_n_examples != n_examples
        ) and cfu_kpis == old_cfu_kpis:
            logger.info(f"Model {model.name} IS NOT up to date data-wise, recomputing...")
        elif (
            data_folders == old_data_folders and old_n_examples == n_examples
        ) and cfu_kpis != old_cfu_kpis:
            logger.info(f"Model {model.name} IS NOT up to date kpi-wise, recomputing...")
            _log_kpis_differences(old_kpis=old_cfu_kpis, new_kpis=cfu_kpis)
        elif (
            data_folders != old_data_folders or old_n_examples != n_examples
        ) and cfu_kpis != old_cfu_kpis:
            logger.info(f"Model {model.name} IS NOT up to date data and kpi-wise, recomputing...")
            _log_kpis_differences(old_kpis=old_cfu_kpis, new_kpis=cfu_kpis)

        logger.info(f"Computing KPIs for model: {model.name}...")
        # structure model components and set-up config file
        model_folder = os.path.join(PATH_MODELS_ON_DISK, model.name.split(".zip")[0])
        model_weights = os.path.join(model_folder, MODEL_WEIGHTS_NAME)
        model_config = os.path.join(model_folder, MODEL_CONFIG_NAME)
        model_last_checkpoint = os.path.join(model_folder, MODEL_LAST_CHECKPOINT_NAME)
        model_events = os.path.join(model_folder, MODEL_EVENTS_NAME)

        # check the model is not corrupted
        if (
            not os.path.isfile(model_weights)
            or not os.path.isfile(model_config)
            or not os.path.isfile(model_last_checkpoint)
        ):
            model.available = False
            logger.warning(
                f"model_weights: {model_weights} and/or model_config: {model_config} and/or model_last_checkpoint: {model_last_checkpoint} and/or model_events: {model_events} don't exist. ",
                "KPIs cannot be recomputed. The model in models_KPIs.json is marked as unavailable.",
            )

        else:
            cfg = get_cfg()
            cfg.merge_from_file(model_config)
            cfg.MODEL.WEIGHTS = model_weights
            cfg.OUTPUT_DIR = model_folder

            # test with new dataset
            kpis = compute_kpis(cfg)

            # test prediction intervals with new dataset
            quantile_low, quantile_high, calibration, sharpness = _compute_quantiles(
                model=model, cfg=cfg
            )

            # update models
            models_kpis.models[i] = Model(
                name=model.name,
                datetime_finished=model.datetime_finished,
                backbone=model.backbone,
                iteration=model.iteration,
                available=True,
                kpis=KPIs(**kpis),
                quantiles=[quantile_low, quantile_high],
                quantiles_calibration_test=calibration,
                quantiles_sharpness_test=sharpness,
            )
    # update data
    models_kpis.data.folders = data_folders
    models_kpis.data.n_examples = n_examples

    return models_kpis


def predict_images(
    images: np.ndarray, predictor: CFUPredictor
) -> Tuple[np.ndarray, np.ndarray, Tuple[float, List[Tuple[float, float]]]]:
    """Predict images (RGB) drawings and counts."""
    n_images = images.shape[0]
    height, width, channels = images.shape[1:]
    predictions = np.zeros((n_images, height, width, channels), dtype=np.uint8)
    counts = []
    pi_bounds: List[Tuple[float, float]] = []
    for i in tqdm(np.arange(n_images)):
        image_input = images[i, ...]
        prediction = predictor.predict_quantiles([image_input[:, :, ::-1]])[0]
        counts.append(prediction.model_prediction.prediction)

        # generate predicted image
        predictions[i, ...] = (
            Visualizer(image_input).draw_instance_predictions(prediction.instances).get_image()
        )
        pi_interval = (
            prediction.quantiles_predictions[1].quantile
            - prediction.quantiles_predictions[0].quantile
        )
        pi_bounds.append(
            (
                prediction.quantiles_predictions[0].prediction,
                prediction.quantiles_predictions[1].prediction,
            )
        )

    pis = (pi_interval * 100, pi_bounds)
    return predictions, np.array(counts), pis


def save_images_names_predictions_counts(
    images: np.ndarray,
    names: np.ndarray,
    predictions: np.ndarray,
    counts: np.ndarray,
    pis: Tuple[float, List[Tuple[float, float]]],
    location: str,
    quality: int = 70,
) -> None:
    """Save images, names, predictions and counts to location."""
    # check input
    n_images = len(images)
    if not all(n_images == n for n in [len(names), len(predictions), len(counts)]):
        raise ValueError(
            f"Lengths of images: {len(images)}, names: {len(names)}, predictions: {len(predictions)} and counts: {len(counts)} don't have matching length:."
        )

    # create output location if needed
    Path(location).mkdir(parents=True, exist_ok=True)

    # save names, counts and PIs
    joblib.dump(
        names, filename=f"{location}/filenames.lz4", compress=9, protocol=pickle.HIGHEST_PROTOCOL
    )
    joblib.dump(
        counts, filename=f"{location}/counts.lz4", compress=9, protocol=pickle.HIGHEST_PROTOCOL
    )
    joblib.dump(pis, filename=f"{location}/PIs.lz4", compress=9, protocol=pickle.HIGHEST_PROTOCOL)

    # save images and predictions
    for i, (image, prediction) in enumerate(tqdm(zip(images, predictions))):
        Image.fromarray(image).save(f"{location}/image_{str(i).zfill(5)}.jpg", quality=quality)
        Image.fromarray(prediction).save(
            f"{location}/prediction_{str(i).zfill(5)}.jpg", quality=quality
        )


def write_images_names_predictions_counts(
    folder_name: str,
    images: np.ndarray,
    names: np.ndarray,
    predictions: np.ndarray,
    counts: np.ndarray,
    pis: Tuple[float, List[Tuple[float, float]]],
    quality: int = 70,
) -> None:
    """Write images, names, predictions and counts to disk."""
    logger.info(f"Creating folder: {folder_name}...")
    Path(folder_name).mkdir(parents=True, exist_ok=True)

    logger.info("Saving data...")
    save_images_names_predictions_counts(
        images=images,
        names=names,
        predictions=predictions,
        counts=counts,
        pis=pis,
        location=folder_name,
        quality=quality,
    )


def get_data_compute_predictions_save_zip_upload_images_names_predictions_count(
    model_name: str, quality: int = 70, compress: bool = False, overwrite: bool = True
) -> None:
    """Get train, test and positive unlabelled images, compute predictions and PIs and save, zip and upload the images, names, predictions and counts."""
    # Load images
    logger.info("Load images...")
    images_train_original, train_names = load_images(get_paths_train_images())
    images_test_original, test_names = load_images(get_paths_test_images())
    images_positive_unlabelled_original, positive_unlabelled_names = load_images(
        get_paths_positive_unlabelled_images()
    )

    # load predictor
    logger.info("Instantiate predictor...")
    predictor = CFUPredictor(model_name=model_name)

    # Compute predictions
    logger.info("Predict images...")
    images_train_predicted, counts_train, pis_train = predict_images(
        images=images_train_original, predictor=predictor
    )
    images_test_predicted, counts_test, pis_test = predict_images(
        images=images_test_original, predictor=predictor
    )
    (
        images_positive_unlabelled_predicted,
        counts_positive_unlabelled,
        pis_positive_unlabelled,
    ) = predict_images(images=images_positive_unlabelled_original, predictor=predictor)

    # Write images, names, predictions and counts to disk
    logger.info("Write images, names, predictions and counts to disk...")
    model_name = os.path.basename(predictor.cfg.OUTPUT_DIR)
    predictions_folder = os.path.join(PATH_PREDICTIONS_ON_DISK, model_name)
    if os.path.exists(predictions_folder):
        delete_folders([predictions_folder])

    write_images_names_predictions_counts(
        folder_name=os.path.join(predictions_folder, "train"),
        images=images_train_original,
        names=train_names,
        predictions=images_train_predicted,
        counts=counts_train,
        pis=pis_train,
        quality=quality,
    )
    write_images_names_predictions_counts(
        folder_name=os.path.join(predictions_folder, "test"),
        images=images_test_original,
        names=test_names,
        predictions=images_test_predicted,
        counts=counts_test,
        pis=pis_test,
        quality=quality,
    )
    write_images_names_predictions_counts(
        folder_name=os.path.join(predictions_folder, "positive_unlabelled"),
        images=images_positive_unlabelled_original,
        names=positive_unlabelled_names,
        predictions=images_positive_unlabelled_predicted,
        counts=counts_positive_unlabelled,
        pis=pis_positive_unlabelled,
        quality=quality,
    )

    # Zip and upload to blob
    logger.info("Zip and upload predictions to blob...")
    zip_upload_predictions_to_blob(
        predictions=predictions_folder, overwrite=overwrite, compress=compress
    )
