"""Module to copy and organize original data to leave it untouched."""

import json
import logging
import os
import shutil
import tempfile
from itertools import chain
from pathlib import Path
from pickle import HIGHEST_PROTOCOL  # noqa: S403
from typing import Any, List, Optional, Sequence, Tuple, Union

import cv2
import joblib
import numpy as np
import pandas as pd
from detectron2.structures import BoxMode
from pydantic import ValidationError
from skimage.measure import find_contours, label
from sklearn.utils import _safe_indexing
from sklearn.utils.validation import indexable

from vxgioq_cfu_counting_ml.training.matched_data import MATCHES
from vxgioq_cfu_counting_ml.utils.azure import (
    DATASET_DETECTRON2_NAME,
    PATH_DATA_ON_BLOB,
    PATH_DATA_ON_DISK,
    download_unzip_clean_data,
    download_unzip_clean_zip,
)
from vxgioq_cfu_counting_ml.utils.conf import delete_files, delete_folders
from vxgioq_cfu_counting_ml.utils.custom_datasets import _downsample_polygon_edges
from vxgioq_cfu_counting_ml.utils.types import (
    DatasetVIAFormat,
    Detectron2Annotation,
    Detectron2DatasetElement,
    VIACircle,
    VIAEllipse,
    VIAPolygon,
)

logger = logging.getLogger(__name__)


def custom_train_test_split(
    *arrays: Sequence[Any], base_test_sequence: Optional[List[bool]] = None
) -> List[Sequence[Any]]:
    """
    Split train test split for the custom Production CFU project based on base_test_sequence that gets reproduced as many times as needed to seperate all the arrays lists.

    Parameters
    ----------
    arrays
        sequence of indexables with same length / shape[0] Allowed inputs are lists, numpy arrays, scipy-sparse matrices or pandas dataframes.
    base_test_sequence
        The base boolean sequence that will be genereated as many times as needed to generate the train/test split of the arrays.
        Default sequence: 1 Test, 2 Train, 3 Train, (4 Test, 5 Train, 6 Train, ...).

    Returns
    -------
    splitting
        list of length=2 * len(arrays) containing train-test split of inputs.

    Examples
    --------
    >>> array_1 = [1, 2, 3]
    >>> array_2 = [10, 20, 30]
    >>> custom_train_test_split(array_1, array_2)
    [[1, 2], [3], [10, 20], [30]]
    >>> array_1 = [1, 2, 3, 4]
    >>> array_2 = [10, 20, 30, 40]
    >>> custom_train_test_split(array_1, array_2)
    [[1, 2, 4], [3], [10, 20, 40], [30]]
    >>> array_1 = [1, 2, 3, 4, 5]
    >>> array_2 = [10, 20, 30, 40, 50]
    >>> custom_train_test_split(array_1, array_2)
    [[1, 2, 4, 5], [3], [10, 20, 40, 50], [30]]
    >>> array_1 = [1, 2, 3, 4, 5, 6]
    >>> custom_train_test_split(array_1)
    [[1, 2, 4, 5], [3, 6]]
    >>> custom_train_test_split()
    Traceback (most recent call last):
      ...
    ValueError: At least one array required as input
    """
    n_arrays = len(arrays)
    if n_arrays == 0:
        raise ValueError("At least one array required as input")
    ars = indexable(*arrays)

    if not base_test_sequence:
        base_test_sequence = [False, False, True]

    n_repeat = len(ars[0]) // len(base_test_sequence) + 1
    test_mask = np.array((base_test_sequence * n_repeat)[: len(ars[0])])
    train = np.where(~test_mask)[0]
    test = np.where(test_mask)[0]

    return list(
        chain.from_iterable((_safe_indexing(a, train), _safe_indexing(a, test)) for a in ars)
    )


def custom_negative_train_test_split(
    dataset: List[Detectron2DatasetElement], matches: Optional[List[Tuple[str, str, bool]]] = None
) -> Tuple[List[Detectron2DatasetElement], List[Detectron2DatasetElement]]:
    """Split in custom negative train test to have images that can be compared with scan4000 in the test set."""
    if not matches:
        matches = MATCHES
    negative_matches = [match for match in matches if "unlabelled" in match[0] and match[2] is True]
    _test = [
        dataset_el
        for dataset_el in dataset
        if any(
            os.path.basename(dataset_el.file_name) in negative_match
            for negative_match, _, _ in negative_matches
        )
    ]
    _train = [
        dataset_el
        for dataset_el in dataset
        if not any(
            os.path.basename(dataset_el.file_name) in negative_match
            for negative_match, _, _ in negative_matches
        )
        and "unlabelled" in dataset_el.file_name
    ]
    return _train, _test


def sort_files_by_datetime_name(files: List[str], ascending: bool = True) -> List[str]:
    """Sort files by datetime creation and then by name."""
    df = pd.DataFrame(
        data=[(file, os.path.getctime(file)) for file in files], columns=["file", "datetime"]
    )
    files_sorted: List[str] = df.sort_values(["datetime", "file"], ascending=ascending)[
        "file"
    ].to_list()
    return files_sorted


def count_files(folders: Union[str, List[str]], excludes: str = ".lz4") -> int:
    """Count the number of files excluding `excludes` in a list of folders."""
    if isinstance(folders, str):
        fldrs = [folders]
    else:
        fldrs = folders
    total = 0
    for folder in fldrs:
        for _, _, files in os.walk(folder):
            for file in files:
                if excludes not in os.path.basename(file):
                    total += 1
    return total


def _list_dataset_images_masks(path_origin: str) -> Tuple[List[str], List[str]]:
    # loop over the dataset
    paths_images = []
    paths_masks = []
    for path_cdir, _, file_names in os.walk(path_origin):
        # sort file_names as os.walk uses os.listdir which returns filenames in a random order which seed varies depending upon the machine in use
        file_names = sorted(file_names)
        # if we have both an original image (L1) and its mask (L2), extract information
        if any("L1" in file_name for file_name in file_names) and any(
            "L2" in file_name for file_name in file_names
        ):
            # construct original image path
            name_image = [file_name for file_name in file_names if "L1 - " in file_name][0]
            paths_images.append(os.path.join(path_cdir, name_image))

            # construct mask path
            name_mask = [file_name for file_name in file_names if "L2 - " in file_name][0]
            paths_masks.append(os.path.join(path_cdir, name_mask))

    # sort the filenames forfuture deterministic train test split
    sorted_idx = list(pd.Series(paths_images).sort_values().index)
    paths_images = list(pd.Series(paths_images).loc[sorted_idx])
    paths_masks = list(pd.Series(paths_masks).loc[sorted_idx])
    return paths_images, paths_masks


def _list_dataset_unlabelled_images(path_origin: str, include_positives: bool = False) -> List[str]:
    """
    List the dataset unlabelled images.

    If include_positives is set to False, only negative images (i.e. no CFU) are fetched.
    """
    # loop over the dataset
    negative_terms = ["Negative", "Négatif", "Negatif"]
    paths_images = []
    for path_cdir, _, file_names in os.walk(path_origin):
        file_names = sorted(file_names)
        # If we are in a directory containing files and which name contains one of terms used to depict negative dishes
        if len(file_names) > 0:
            if not include_positives:
                if not any(
                    negative_term in path_cdir.split("/")[-1] for negative_term in negative_terms
                ):
                    continue

            # loop on the files
            for image_name in file_names:
                if image_name.split(".")[-1] in ["bmp", "png"]:
                    paths_images.append(os.path.join(path_cdir, image_name))

    return paths_images


def _list_dataset_negative_images(path_origin: str) -> List[str]:
    """List the dataset negative (i.e. no CFU) images."""
    return _list_dataset_unlabelled_images(path_origin=path_origin, include_positives=False)


# =======================================
# Convert to detectron2 compatible format
# =======================================


def via_to_detectron2(data_name: str, overwrite: bool = True) -> None:
    """
    Convert annoted/corrected images from VIA to detectron2 format.

    The VIA dataset, once downloaded from blob and unzipped, is expected to contain [datasets_via.json, ...png, ...png, ...].
    Once converted to detectron2 format
    - the `datasets_via.json` is deleted.
    - a detectron2 dataset `DATASET_DETECTRON2_NAME` is generated containing a list of detectron2 dataset elements.

    Parameters
    ----------
    data_name
        The name of the zipped folder on blob containing the via annotated images.
        The structure of the folder is expected to be: [datasets_via.json, ...png, ...png, ...].
    """
    logger.info("Converting VIA data to detectron2 compatible format...")
    # prepare paths
    path_data = os.path.join(PATH_DATA_ON_DISK, data_name)
    path_datasets_via = os.path.join(path_data, "datasets_via.json")
    path_dataset_detectron2 = os.path.join(path_data, DATASET_DETECTRON2_NAME)

    if os.path.isdir(path_data) and not overwrite:
        logger.info(
            f"Data folder: {path_data} already exists and `overwrite` set to: {overwrite}. Nothing to prepare."
        )
        return None

    # download data (zipped VIA json annotated datasets and images)
    download_unzip_clean_data(data_name=data_name, overwrite=overwrite)

    dataset_detectron2: List[Detectron2DatasetElement] = []
    # load VIA json annotated datasets and loop on each example
    for _dataset_via in json.load(open(path_datasets_via, "r")).values():
        # extract image info
        new_file_name = os.path.join(path_data, os.path.basename(_dataset_via["filename"]))
        height, width, _ = cv2.imread(new_file_name).shape

        # load and check the annotated image format is supported
        try:
            dataset_via = DatasetVIAFormat(**_dataset_via)
        except ValidationError as e:
            logger.error(
                f"Skipping annoted file: {_dataset_via['filename']} because it has unsupported shapes_attributes.\nFull stack:\n{e}"
            )
            delete_files([new_file_name])
            continue

        # loop on each annotation of the image annotations
        annotations: List[Detectron2Annotation] = []
        if (
            len(dataset_via.regions) > 0
        ):  # need at least one instance to fill the annotations object
            for region in dataset_via.regions:

                # generate the mask based on the shape at hand
                # --------------------------------------------
                shape_attributes = region.shape_attributes
                mask = np.zeros((height, width), dtype=np.uint8)
                if isinstance(shape_attributes, (VIACircle, VIAEllipse)):
                    # extract parameters
                    cx = shape_attributes.cx
                    cy = shape_attributes.cy
                    if isinstance(shape_attributes, VIACircle):
                        rx = ry = shape_attributes.r
                        tetha = 0.0
                    else:
                        rx = shape_attributes.rx
                        ry = shape_attributes.ry
                        tetha = (
                            shape_attributes.theta
                        )  # If VIA starts dealing with rotated ellipses, ensure tetha is in degrees, as for cv2
                    # fill the mask
                    startAngle = 0
                    endAngle = 360
                    color = 255
                    thickness = -1
                    mask = cv2.ellipse(
                        mask, (cx, cy), (rx, ry), tetha, startAngle, endAngle, color, thickness
                    )
                elif isinstance(shape_attributes, VIAPolygon):
                    # extract parameters
                    all_points_x = shape_attributes.all_points_x
                    all_points_y = shape_attributes.all_points_y

                    # construct the mask
                    mask = cv2.fillPoly(
                        mask,
                        [np.array([[int(x), int(y)] for x, y in zip(all_points_x, all_points_y)])],
                        (255),
                    )

                # get contour
                contour: np.ndarray = find_contours(
                    mask.astype(np.bool),
                    level=0.0,
                    fully_connected="high",
                    positive_orientation="high",
                )[0]

                # get bbox
                x_min = np.min(contour[:, 1])
                x_max = np.max(contour[:, 1])
                y_min = np.min(contour[:, 0])
                y_max = np.max(contour[:, 0])
                bbox = [x_min, y_min, x_max, y_max]

                # get segmentation
                segmentation = [
                    contour[:, ::-1]  # go from row, colum (y, x) to x, y
                    .reshape(
                        -1
                    )  # go from np.array([[x1, y1], ..., [xn, yn]]) to np.array([x1, y1, ..., xn, yn])
                    .tolist(),  # The polygon components coordinates [x1, y1, x2, y2, ...] of the object (all objects can only be made of one polygon component in that dataset)
                ]

                # fill the annotation
                annotation: Detectron2Annotation = Detectron2Annotation(
                    bbox=bbox,
                    bbox_mode=BoxMode.XYXY_ABS,
                    category_id=0,  # only 1 class to identify for now (no species distinction)
                    segmentation=segmentation,
                )
                annotations.append(annotation)

        else:
            logger.debug(
                f"No instance found on for image: {new_file_name}. Make sure to set "
                "`DATALOADER.FILTER_EMPTY_ANNOTATIONS=False` if you want to include "
                "this (and other empty) example(s) in the training."
            )

        # convert VIA image annotation to detectron2 annotation
        dataset_detectron2_element: Detectron2DatasetElement = Detectron2DatasetElement(
            file_name=new_file_name,
            height=height,
            width=width,
            image_id=os.path.basename(new_file_name),
            annotations=annotations,
        )

        # append
        dataset_detectron2.append(dataset_detectron2_element)

    # write detectron2 format annotated datasets to disk
    joblib.dump(
        dataset_detectron2, filename=path_dataset_detectron2, compress=9, protocol=HIGHEST_PROTOCOL,
    )

    # delete VIA annotated datasets
    delete_files([path_datasets_via])


def gsk_original_to_detectron2(data_name: str = "labelled", overwrite: bool = True) -> None:
    """Convert the GSK original training dataset (image segmented images) to the detectron2 format."""
    # setup paths
    path_data = os.path.join(PATH_DATA_ON_DISK, data_name)
    path_dataset_detectron2 = os.path.join(path_data, DATASET_DETECTRON2_NAME)

    # delete and recreate the data folder if needed
    if os.path.isdir(path_data) and overwrite:
        delete_folders([path_data])
        Path(path_data).mkdir(parents=True, exist_ok=True)

    elif os.path.isdir(path_data) and not overwrite:
        logger.info(
            f"Data folder: {path_data} already exists and `overwrite` set to: {overwrite}. Nothing to prepare."
        )
        return None

    # create a tmpdir context
    dataset_detectron2: List[Detectron2DatasetElement] = []
    with tempfile.TemporaryDirectory() as tmpdirname:
        # download data to tmp dir
        logger.info(f"Downloading data: {data_name}...")
        download_unzip_clean_zip(
            name=data_name if data_name.split(".")[-1] == "zip" else data_name + ".zip",
            path_on_disk=tmpdirname,
            path_on_blob=PATH_DATA_ON_BLOB,
            overwrite=overwrite,
        )

        logger.info("Converting gsk original data to detectron2 compatible format...")
        # get all images and masks paths
        path_images, path_masks = _list_dataset_images_masks(
            path_origin=os.path.join(tmpdirname, data_name)
        )
        # loop on all the examples
        for path_image, path_mask in zip(path_images, path_masks):
            # load image and mask
            image: np.ndarray = cv2.imread(path_image)
            mask: np.ndarray = cv2.imread(path_mask)

            # get image dimensions
            height, width, _ = image.shape

            # Binarize the mask (i.e. go from uint8 W * H * RBG to bool W * H)
            mask = (mask[:, :, 0] == 33) & (mask[:, :, 2] != 255)

            # Make the distinction between the different sub-masks within the mask image (give each submask a different value)
            mask = label(mask, connectivity=1, background=0, return_num=False)

            # loop on each submask identified on the mask and get it's contour, bboxes, ...
            annotations: List[Detectron2Annotation] = []
            if (
                len(np.unique(mask)) > 1
            ):  # need at least one instance to fill the annotations object
                for id_mask in np.delete(np.unique(mask), 0):
                    # get contour
                    contour: np.ndarray = find_contours(
                        mask == id_mask,
                        level=0.0,
                        fully_connected="high",
                        positive_orientation="high",
                    )[0]

                    # get bbox
                    x_min = np.min(contour[:, 1])
                    x_max = np.max(contour[:, 1])
                    y_min = np.min(contour[:, 0])
                    y_max = np.max(contour[:, 0])
                    bbox = [x_min, y_min, x_max, y_max]

                    annotation: Detectron2Annotation = Detectron2Annotation(
                        bbox=bbox,
                        bbox_mode=BoxMode.XYXY_ABS,
                        category_id=0,  # only 1 class to identify for now (no species distinction)
                        segmentation=[
                            _downsample_polygon_edges(polygon=contour, max_edges=101)[
                                :, ::-1
                            ]  # go from row, colum (y, x) to x, y
                            .reshape(
                                -1
                            )  # go from [[x1, y1], ..., [xn, yn]] to [x1, y1, ..., xn, yn]
                            .tolist(),  # The polygon components coordinates (x1, y1, x2, y2, ...) of the object (all objects can only be made of one polygon component in that dataset)
                        ],
                    )
                    annotations.append(annotation)
            else:
                logger.debug(
                    f"No instance found on the mask: {path_mask}. Make sure to set "
                    "`DATALOADER.FILTER_EMPTY_ANNOTATIONS=False` if you want to include "
                    "this (and other empty) example(s) in the training."
                )

            # copy original image to the final data location
            path_image_new = os.path.join(
                path_data, path_image.split("/")[-2] + "_" + os.path.basename(path_image)
            )
            shutil.copy2(src=path_image, dst=path_image_new)

            # store the annotations in the dataset and the datasets
            dataset_detectron2_element: Detectron2DatasetElement = Detectron2DatasetElement(
                file_name=path_image_new,
                height=height,
                width=width,
                image_id=os.path.basename(path_image_new),
                annotations=annotations,
            )
            dataset_detectron2.append(dataset_detectron2_element)

    # save the datasets to the data folder
    joblib.dump(
        value=dataset_detectron2,
        filename=path_dataset_detectron2,
        compress=9,
        protocol=HIGHEST_PROTOCOL,
    )


def negative_to_detectron2(data_name: str, overwrite: bool = True) -> None:
    """Convert negative dataset (no instances on images) to the detectron2 format."""
    # setup paths
    path_data = os.path.join(PATH_DATA_ON_DISK, data_name)
    path_dataset_detectron2 = os.path.join(path_data, DATASET_DETECTRON2_NAME)

    # delete and recreate the data folder if needed
    if os.path.isdir(path_data) and overwrite:
        delete_folders([path_data])
        Path(path_data).mkdir(parents=True, exist_ok=True)

    elif os.path.isdir(path_data) and not overwrite:
        logger.info(
            f"Data folder: {path_data} already exists and `overwrite` set to: {overwrite}. Nothing to prepare."
        )
        return None

    # create a tmpdir context
    dataset_detectron2: List[Detectron2DatasetElement] = []
    with tempfile.TemporaryDirectory() as tmpdirname:
        # download data to tmp dir
        logger.info(f"Downloading data: {data_name}...")
        download_unzip_clean_zip(
            name=data_name if data_name.split(".")[-1] == "zip" else data_name + ".zip",
            path_on_disk=tmpdirname,
            path_on_blob=PATH_DATA_ON_BLOB,
            overwrite=overwrite,
        )

        logger.info("Converting negative data to detectron2 compatible format...")
        # get all images paths
        path_images = _list_dataset_negative_images(path_origin=os.path.join(tmpdirname, data_name))

        # loop on all the examples
        for path_image in path_images:
            # load image
            image: np.ndarray = cv2.imread(path_image)

            # get image dimensions
            height, width, _ = image.shape

            # copy original image to the final data location
            path_image_new = os.path.join(
                path_data, path_image.split("/")[-2] + "_" + os.path.basename(path_image)
            )
            shutil.copy2(src=path_image, dst=path_image_new)

            # store the annotations in the dataset and the datasets
            dataset_detectron2_element: Detectron2DatasetElement = Detectron2DatasetElement(
                file_name=path_image_new,
                height=height,
                width=width,
                image_id=os.path.basename(path_image_new),
                annotations=[],
            )
            dataset_detectron2.append(dataset_detectron2_element)

    # save the datasets to the data folder
    joblib.dump(
        value=dataset_detectron2,
        filename=path_dataset_detectron2,
        compress=9,
        protocol=HIGHEST_PROTOCOL,
    )


# =========================================================
# Split detectron2 compatible data into train and test sets
# =========================================================


def _copy_files_update_datasets(
    dataset_detectron2: Sequence[Detectron2DatasetElement], path_organized: str
) -> Sequence[Detectron2DatasetElement]:
    for dataset_detectron2_element in dataset_detectron2:
        # prepare the original and new filenames
        original_filename: str = dataset_detectron2_element.file_name
        new_filename = os.path.join(
            path_organized,
            os.path.dirname(original_filename).split("/")[-1]
            + "_"
            + os.path.basename(original_filename),
        )

        # copy image file to train/test and rename by pre-pending the folder as a prefix to the image
        shutil.copy2(src=original_filename, dst=new_filename)

        # update the file location in the annoted image object
        dataset_detectron2_element.file_name = new_filename
        dataset_detectron2_element.image_id = os.path.basename(new_filename)

    return dataset_detectron2


def generate_train_test(
    folders: List[str], folders_negative: Optional[List[str]] = None, overwrite: bool = True
) -> str:
    """Generate the training and testing sets folders and return their root path."""
    # setup paths
    path_organized = os.path.join(PATH_DATA_ON_DISK, "organized")
    path_organized_train = os.path.join(path_organized, "train")
    path_organized_test = os.path.join(path_organized, "test")

    # delete pre-existing train and test folders if any and overwrite
    if overwrite and os.path.isdir(path_organized):
        delete_folders([path_organized])
        Path(path_organized_train).mkdir(parents=True, exist_ok=True)
        Path(path_organized_test).mkdir(parents=True, exist_ok=True)

    train: List[Detectron2DatasetElement] = []
    test: List[Detectron2DatasetElement] = []
    # for each folder
    for folder in folders:
        logger.info(f"Processing folder: {folder}...")
        # load DATASET_DETECTRON2_NAME
        dataset_detectron2: List[Detectron2DatasetElement] = joblib.load(
            os.path.join(folder, DATASET_DETECTRON2_NAME)
        )

        # Ensure the files all exist
        for dataset_detectron2_element in dataset_detectron2:
            filename: str = dataset_detectron2_element.file_name
            if not os.path.isfile(filename):
                raise FileExistsError(f"File: {filename} does not exist.")

        # split that list of Detectron2DatasetElement into train and test Detectron2DatasetElements
        _train, _test = custom_train_test_split(dataset_detectron2)

        # loop through all training and testing annoted images, copy file and update filename in dataset
        _train = _copy_files_update_datasets(
            dataset_detectron2=_train, path_organized=path_organized_train
        )
        _test = _copy_files_update_datasets(
            dataset_detectron2=_test, path_organized=path_organized_test
        )

        # extend train and test lists
        train.extend(_train)
        test.extend(_test)

    # for each negative folder, all negative images can go on the test set as they are not used in the training anyway
    if folders_negative:
        for folder in folders_negative:
            logger.info(f"Processing negative folder: {folder}...")
            # load DATASET_DETECTRON2_NAME
            dataset_detectron2 = joblib.load(os.path.join(folder, DATASET_DETECTRON2_NAME))

            # Ensure the files all exist
            for dataset_detectron2_element in dataset_detectron2:
                filename = dataset_detectron2_element.file_name
                if not os.path.isfile(filename):
                    raise FileExistsError(f"File: {filename} does not exist.")

            # train test split with test images being those which can be compared to scan4000
            _train, _test = custom_negative_train_test_split(dataset_detectron2)

            # loop through all training and testing images, copy file and update filename in dataset
            _train = _copy_files_update_datasets(
                dataset_detectron2=_train, path_organized=path_organized_train
            )
            _test = _copy_files_update_datasets(
                dataset_detectron2=_test, path_organized=path_organized_test
            )

            # extend train and test lists
            train.extend(_train)
            test.extend(_test)

    # save those train and test detectron2 formatted annotations into training and testing sets
    logger.info(f"Saving the {DATASET_DETECTRON2_NAME}...")
    joblib.dump(
        value=train,
        filename=os.path.join(path_organized_train, DATASET_DETECTRON2_NAME),
        compress=9,
        protocol=HIGHEST_PROTOCOL,
    )
    joblib.dump(
        value=test,
        filename=os.path.join(path_organized_test, DATASET_DETECTRON2_NAME),
        compress=9,
        protocol=HIGHEST_PROTOCOL,
    )

    return path_organized


def get_paths_positive_unlabelled_images() -> List[str]:
    """Get paths of positive unlabelled images."""
    # Get positive unlabelled images paths
    path_origin = os.path.join(PATH_DATA_ON_DISK, "unlabelled")
    negative_images = _list_dataset_unlabelled_images(path_origin, include_positives=False)
    unlabelled_images = _list_dataset_unlabelled_images(path_origin, include_positives=True)
    paths_positive_unlabelled_images = list(set(unlabelled_images) - set(negative_images))
    paths_positive_unlabelled_images.sort()
    return paths_positive_unlabelled_images


def get_paths_train_images() -> List[str]:
    """Get paths of training images."""
    path_train = os.path.join(PATH_DATA_ON_DISK, "organized", "train")
    paths_train_images = [
        os.path.join(path_train, image_name)
        for image_name in sorted(os.listdir(path_train))
        if image_name.split(".")[-1] != "lz4"
    ]
    return paths_train_images


def get_paths_test_images() -> List[str]:
    """Get paths of testing images."""
    path_test = os.path.join(PATH_DATA_ON_DISK, "organized", "test")
    paths_test_images = [
        os.path.join(path_test, image_name)
        for image_name in sorted(os.listdir(path_test))
        if image_name.split(".")[-1] != "lz4"
    ]
    return paths_test_images
