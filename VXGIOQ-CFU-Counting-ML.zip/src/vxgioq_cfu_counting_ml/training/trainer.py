"""Extensions of the Detectron2 `DefaultTrainer`."""

import logging
import os
from collections import OrderedDict
from typing import Dict, List, Optional, Union

import cv2
from detectron2.config.config import CfgNode
from detectron2.data import (
    MetadataCatalog,
    build_detection_test_loader,
    build_detection_train_loader,
)
from detectron2.data import transforms as T
from detectron2.data.common import AspectRatioGroupedDataset
from detectron2.data.transforms.augmentation import Augmentation
from detectron2.engine import DefaultTrainer
from detectron2.evaluation import COCOEvaluator, DatasetEvaluator, DatasetEvaluators
from detectron2.modeling import GeneralizedRCNN, GeneralizedRCNNWithTTA
from torch.utils.data.dataloader import DataLoader

from vxgioq_cfu_counting_ml.training.dataset_mapper import CFUDatasetMapper
from vxgioq_cfu_counting_ml.utils.conf import delete_folders
from vxgioq_cfu_counting_ml.utils.evaluator import CFUEvaluator

logger = logging.getLogger(__name__)


class CFUTrainer(DefaultTrainer):
    """Extend the Detectron2 DefaultTrainer to better augment and evaluate CFU data."""

    augmentations_train: List[Augmentation] = [
        T.RandomApply(T.RandomBrightness(intensity_min=0.7, intensity_max=1.3), prob=1),
        T.RandomApply(T.RandomContrast(intensity_min=0.7, intensity_max=1.3), prob=1),
        T.RandomApply(T.RandomLighting(scale=1.0), prob=1),
        T.RandomApply(T.RandomSaturation(intensity_min=0.7, intensity_max=1.3), prob=1),
        T.RandomRotation(angle=[0.0, 360.0], sample_style="range", interp=cv2.INTER_CUBIC,),
        T.RandomCrop_CategoryAreaConstraint(crop_type="relative_range", crop_size=(0.5, 0.5)),
        T.ResizeShortestEdge(  # Randomly rescales the image to one of the short_edge_length sizes
            short_edge_length=(1200), max_size=1500, sample_style="choice"
        ),
    ]
    augmentations_test: List[Augmentation] = [
        T.RandomRotation(angle=[0.0, 360.0], sample_style="range", interp=cv2.INTER_CUBIC,)
    ]

    @classmethod
    def build_train_loader(
        cls, cfg: CfgNode, augmentations: Optional[List[Augmentation]] = None
    ) -> Union[AspectRatioGroupedDataset, DataLoader]:  # type: ignore
        """
        Create a training data loader.

        Returns
        -------
        iterable
        """
        return build_detection_train_loader(
            cfg,
            mapper=CFUDatasetMapper(
                cfg,
                is_train=True,
                augmentations=augmentations if augmentations else cls.augmentations_train,
                recompute_boxes=True,  # to tighten the bboxes that got widened after transforms like rotation
            ),
        )

    @classmethod
    def build_test_loader(
        cls, cfg: CfgNode, dataset_name: str, augmentations: Optional[List[Augmentation]] = None
    ) -> DataLoader:  # type: ignore
        """
        Create a test data loader.

        Returns
        -------
        iterable
        """
        return build_detection_test_loader(  # type: ignore
            cfg,
            dataset_name=dataset_name,
            mapper=CFUDatasetMapper(
                cfg,
                is_train=False,
                augmentations=augmentations if augmentations else cls.augmentations_test,
                recompute_boxes=True,  # to tighten the bboxes that got widened after transforms like rotation
            ),
        )

    @classmethod
    def build_evaluator(
        cls, cfg: CfgNode, dataset_name: str, output_folder: Optional[str] = None
    ) -> Union[DatasetEvaluators, DatasetEvaluator]:
        """
        Create evaluator(s) for a given dataset.

        This uses the special metadata "evaluator_type" associated with each builtin dataset.
        For your own dataset, you can simply create an evaluator manually in your
        script and do not have to worry about the hacky if-else logic here.
        """
        if output_folder is None:
            output_folder = os.path.join(cfg.OUTPUT_DIR, "inference")
        # Delete pre-existing evaluation folder to ensure a new one gets created and no old cache is being used
        if os.path.isdir(output_folder):
            logger.info(f"Overwriting existing: {output_folder}.")
            delete_folders([output_folder])

        # remove any dataset json_file metadata if any to ensure such cache gets recreated by the COCOEvaluator.
        # The cache issue is that as soon as the dataset gets extended, benchmarks using the old cache will be meaningless
        _metadata = MetadataCatalog.get(dataset_name)
        if hasattr(_metadata, "json_file"):
            del _metadata.json_file

        evaluator_list = [
            CFUEvaluator(),
            COCOEvaluator(dataset_name, cfg, True, output_folder),
        ]

        if len(evaluator_list) == 0:
            raise NotImplementedError(f"No Evaluator for the dataset {dataset_name}.")

        elif len(evaluator_list) == 1:
            return evaluator_list[0]

        return DatasetEvaluators(evaluator_list)

    @classmethod
    def test_with_TTA(
        cls, cfg: CfgNode, model: GeneralizedRCNN
    ) -> Dict[str, Dict[str, Union[float, int]]]:
        """
        Test with Test Time Augmentation.

        This allows having KPIs measured on more data.
        """
        logger = logging.getLogger("detectron2.trainer")
        # In the end of training, run an evaluation with TTA
        # Only support some R-CNN models.
        logger.info("Running inference with test-time augmentation ...")
        model_wrapped = GeneralizedRCNNWithTTA(cfg, model)
        evaluators = [
            cls.build_evaluator(
                cfg, name, output_folder=os.path.join(cfg.OUTPUT_DIR, "inference_TTA")
            )
            for name in cfg.DATASETS.TEST
        ]
        res = cls.test(cfg, model_wrapped, evaluators)
        results = OrderedDict({k + "_TTA": v for k, v in res.items()})
        return results
