"""Config parameters."""

import logging
import os
import shutil
from os import environ as env
from pathlib import Path
from typing import List, Optional
from uuid import uuid4

import torch
from detectron2.config import CfgNode, get_cfg

from vxgioq_cfu_counting_ml.utils.azure import (
    MODEL_CONFIG_NAME,
    MODEL_EVENTS_NAME,
    MODEL_LAST_CHECKPOINT_NAME,
    MODEL_WEIGHTS_NAME,
    MODELS_QUANTILES_NAME,
    PATH_CONFIGS_ON_DISK,
    PATH_MODELS_ON_DISK,
)
from vxgioq_cfu_counting_ml.utils.types import Backbone, Device

logger = logging.getLogger(__name__)

DATE_FORMAT = "%Y-%m-%dT%H:%M:%S.%f%z"
LOG_FORMAT = "%(levelname)s %(module)s: %(message)s"
COMMIT: str = env.get("COMMIT", "not set")
BRANCH: str = env.get("BRANCH", "not set")
STORAGE_NAME: str = env.get("STORAGE_NAME", "not set")


def to_string() -> str:
    """Format config variables."""
    return f"""
Configuration:
└ COMMIT = {COMMIT}
└ BRANCH = {BRANCH}
└ STORAGE_NAME = {STORAGE_NAME}
"""


def prepare_cfu_detectron2_config_from_detectron2_model_zoo(
    backbone: Backbone, device: Device, iterations: Optional[int] = None
) -> CfgNode:
    """Generate a detectron2 config from pre-existing detectron2 model zoo suited for the CFU project with a unique output folder."""
    # load config
    cfg = get_cfg()

    # Update backbone
    if backbone == Backbone.R50_FPN:
        cfg.merge_from_file(os.path.join(PATH_CONFIGS_ON_DISK, "R50_FPN.yaml"))
    elif backbone == Backbone.R101_FPN:
        cfg.merge_from_file(os.path.join(PATH_CONFIGS_ON_DISK, "R101_FPN.yaml"))
    elif backbone == Backbone.X101_FPN:
        cfg.merge_from_file(os.path.join(PATH_CONFIGS_ON_DISK, "X101_FPN.yaml"))
    else:
        raise ValueError(f"backbone: {backbone} not recognized. Must be one of: {list(Backbone)}.")

    # Update settings for CFU data
    cfg.merge_from_file(os.path.join(PATH_CONFIGS_ON_DISK, "CFU.yaml"))

    # Update settings for device
    if device == Device.CPU:
        cfg.merge_from_file(os.path.join(PATH_CONFIGS_ON_DISK, "CPU.yaml"))
    elif device == Device.GPU:
        cfg.merge_from_file(os.path.join(PATH_CONFIGS_ON_DISK, "GPU.yaml"))
        if not torch.cuda.is_available():
            raise ValueError(f"CUDA is not available but device: {device} was requested. Aborting.")
    else:
        raise ValueError(f"Device: {device} not recognized. Must be one of: {list(Device)}.")

    # Set-up a unique output folder for the model and ensure it gets created if needed
    cfg.OUTPUT_DIR = os.path.join(PATH_MODELS_ON_DISK, str(uuid4()))
    Path(cfg.OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

    # update the number of iterations to run
    if iterations:
        cfg.SOLVER.MAX_ITER = iterations

    return cfg


def prepeare_cfu_detectron_config_from_existing_model(
    existing_model_name: str, iterations: int = 14_000
) -> CfgNode:
    """Generate a detectron2 config suited for the CFU project with a unique output folder based on an existing model name which training should be continued."""
    # set-up model folder
    existing_model_folder = os.path.join(PATH_MODELS_ON_DISK, existing_model_name)

    # ensure pre-existing model exists
    if not any(
        [
            os.path.isdir(existing_model_folder),
            os.path.isdir(os.path.join(existing_model_folder, MODEL_EVENTS_NAME)),
            os.path.isfile(os.path.join(existing_model_folder, MODEL_WEIGHTS_NAME)),
            os.path.isfile(os.path.join(existing_model_folder, MODEL_CONFIG_NAME)),
            os.path.isfile(os.path.join(existing_model_folder, MODEL_LAST_CHECKPOINT_NAME)),
        ]
    ):
        raise ValueError(
            f"existing_model_folder: {existing_model_folder} must exist and at least contain ",
            f"a `{MODEL_WEIGHTS_NAME}`, a `{MODEL_CONFIG_NAME}`, a `{MODEL_LAST_CHECKPOINT_NAME}` and a folder of events `{MODEL_EVENTS_NAME}`.",
        )
    # load config
    cfg = get_cfg()
    cfg.merge_from_file(os.path.join(existing_model_folder, MODEL_CONFIG_NAME))

    # set-up a unique output folder and copy pretrained model to it
    cfg.OUTPUT_DIR = os.path.join(PATH_MODELS_ON_DISK, str(uuid4()))
    logger.info(
        f"Creating and copying pre-trained model artifacts to new model folder: {cfg.OUTPUT_DIR} ..."
    )

    # copy the existing model artifacts to that new model
    shutil.copytree(src=existing_model_folder, dst=cfg.OUTPUT_DIR)

    # upate weights path and iterations
    cfg.MODEL.WEIGHTS = os.path.join(cfg.OUTPUT_DIR, MODEL_WEIGHTS_NAME)
    cfg.SOLVER.MAX_ITER = cfg.SOLVER.MAX_ITER + iterations

    # delete the old DL config and the Quantile models from the newly created folder as they will need to be recomputed
    delete_files(
        files_to_delete=[
            os.path.join(cfg.OUTPUT_DIR, MODEL_CONFIG_NAME),
            os.path.join(cfg.OUTPUT_DIR, MODELS_QUANTILES_NAME),
        ]
    )

    return cfg


def delete_folders(folders_to_delete: List[str]) -> None:
    """Try to delete a list of folders."""
    for folder_to_delete in folders_to_delete:
        logger.info(f"Deleting: {folder_to_delete} if exists...")
        try:
            shutil.rmtree(folder_to_delete)
        except OSError as e:
            if isinstance(e, FileNotFoundError):
                logger.warning(f"Could not find any folder: {folder_to_delete} to delete.")
            else:
                pass


def delete_files(files_to_delete: List[str]) -> None:
    """Try to delete a list of files."""
    for file_to_delete in files_to_delete:
        logger.info(f"Deleting: {file_to_delete} if exists...")
        try:
            os.remove(file_to_delete)
        except OSError as e:
            if isinstance(e, FileNotFoundError):
                logger.warning(f"Could not find any file: {file_to_delete} to delete.")
            else:
                pass


def clean_output_dir_add_cfg(cfg: CfgNode) -> None:
    """Clean the model/output folder, add it's updated config and save it."""
    # Remove unecessary folders and files
    folders_to_delete = [
        os.path.join(cfg.OUTPUT_DIR, "inference"),
        os.path.join(cfg.OUTPUT_DIR, "inference_TTA"),
        os.path.join(cfg.OUTPUT_DIR, "inference"),
    ]

    delete_folders(folders_to_delete=folders_to_delete)
    files_to_delete = [
        os.path.join(cfg.OUTPUT_DIR, "metrics.json"),
        os.path.join(cfg.OUTPUT_DIR, "model_KPIs.json"),
        *[
            os.path.join(cfg.OUTPUT_DIR, filename)
            for filename in os.listdir(cfg.OUTPUT_DIR)
            if ("model_" in filename and ".pth" in filename and "final" not in filename)
        ],
    ]
    delete_files(files_to_delete=files_to_delete)

    # write the config next to the final model and events
    model_config_path = os.path.join(cfg.OUTPUT_DIR, MODEL_CONFIG_NAME)
    logger.info(f"Writing the model config to: {model_config_path}.")
    with open(model_config_path, "w") as f:
        f.write(cfg.dump())

    # move the events to an events sub-folder
    events_path = os.path.join(cfg.OUTPUT_DIR, MODEL_EVENTS_NAME)
    logger.info(f"Moving output events from: {cfg.OUTPUT_DIR} to {events_path}...")
    Path(events_path).mkdir(parents=True, exist_ok=True)
    for event in os.listdir(cfg.OUTPUT_DIR):
        if "events.out.tfevents." in event:
            shutil.move(os.path.join(cfg.OUTPUT_DIR, event), os.path.join(events_path, event))
