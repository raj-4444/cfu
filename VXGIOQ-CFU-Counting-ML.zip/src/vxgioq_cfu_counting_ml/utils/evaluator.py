"""Extensions of the detectron2 `evaluator` module."""
import logging
from collections import OrderedDict
from typing import Dict, List

import numpy as np
from detectron2.evaluation import DatasetEvaluator

from vxgioq_cfu_counting_ml.utils.metrics import mae, mape
from vxgioq_cfu_counting_ml.utils.types import (
    DatasetEvaluatorResults,
    ModelInputsFormat,
    ModelOutputsFormatInference,
)

logger = logging.getLogger(__name__)


class CFUEvaluator(DatasetEvaluator):
    """
    Extend the Detectron2 `DatasetEvaluator` with CFU related metrics.

    Metrics of interest for CFUs in in R&D or in PROD (QC or EM).
    These metrics are typically associated with information about the number of
    counted CFUs for all, positive (at least one CFU) and negative (no CFU) dishes.

    Examples of such metrics:
        - MAPE (Mean Absolute Percentage Error): Only relevant for positive dishes
        - MAAPE (Mean Arctangent Absolute Error): Tries to make MAPE relevant when negative examples are part of the data as well
        - MAE (Mean Absolute Error): Relevant in both positive and negative cases, but difficult to compare with models evaluated on different datasets
          (E.g. a MAE of 1 CFU/image on an evaluation dataset with on average 100 CFUs/image is very good, but the same MAE, on a dataset with on average 0.5 CFU/image is very bad.)
    """

    def __init__(self) -> None:
        """Extend the Detectron2 `DatasetEvaluator` with CFU related metrics."""
        self.image_names: List[str] = []
        self.gt_counts: List[int] = []
        self.scores: List[List[float]] = []
        self.pred_counts: List[int] = []

    def reset(self) -> None:
        """
        Prepare for a new round of evaluation.

        Should be called before starting a round of evaluation.
        """
        # counts, needed to compute count related metrics, i.e. MAPE, MAE, ...
        self.image_names = []
        self.gt_counts = []
        self.scores = []
        self.pred_counts = []

    def process(self, inputs: ModelInputsFormat, outputs: ModelOutputsFormatInference) -> None:
        """
        Process the pair of inputs and outputs.

        Parameters
        ----------
        inputs
            the inputs that's used to call the model.
        outputs
            the return value of `model(inputs)`.
        """
        for input_, output_ in zip(inputs, outputs):
            gt_counts = len(input_["instances"])  # type: ignore
            self.gt_counts.append(gt_counts)
            scores = output_["instances"].scores.to("cpu")
            self.scores.append(scores.tolist())
            self.pred_counts.append(int((scores >= 0.5).sum()))

            self.image_names.append(input_["file_name"])  # type: ignore

    def _generate_metrics(self, name: str, mask: np.ndarray) -> Dict[str, float]:
        """Generate metrics based on some data mask."""
        gt_counts = np.array(self.gt_counts)
        pred_counts = np.array(self.pred_counts)
        return {
            f"MAE {name}": mae(actual=gt_counts[mask], predicted=pred_counts[mask]),
            f"MAPE {name}": mape(actual=gt_counts[mask], predicted=pred_counts[mask]),
        }

    def evaluate(self) -> DatasetEvaluatorResults:
        """
        Evaluate/summarize the performance, after processing all input/output pairs.

        Returns
        -------
        summarized_performance
            OrderedDict to be compatible with the training script, we expect the following format:
                {"task, e.g. main": {"metric name, e.g. MAE (counts) 1-5": 0.14}}
        """
        # compute the masks
        # -----------------
        gt_counts = np.array(self.gt_counts)
        masks: Dict[str, np.ndarray] = {
            **{  # interval mask
                f"{interval[0]}-{interval[1]}": np.logical_and(
                    gt_counts >= interval[0], gt_counts <= interval[1]
                )
                for interval in [
                    (1, 5),
                    (6, 10),
                    (11, 20),
                    (21, 30),
                    (31, 40),
                    (41, 50),
                    (51, 60),
                    (61, 70),
                    (71, 80),
                    (81, 90),
                    (91, 100),
                ]
            },
            **{f"{min_cfu}+": gt_counts >= min_cfu for min_cfu in [11, 51, 101]},  # min mask
            "0+": np.ones(len(gt_counts), dtype=np.bool),
            "1+": gt_counts > 0,
            "0": gt_counts == 0,
        }
        # compute the metrics
        # -------------------
        metrics = {
            metric_name: metric_value
            for name, mask in masks.items()
            for metric_name, metric_value in self._generate_metrics(name=name, mask=mask).items()
        }

        # split the metrics into main KPIs, MAE KPIs and MAPE KPIs
        evaluations = OrderedDict(
            {
                "main": {
                    metric_name: metric_value
                    for metric_name, metric_value in metrics.items()
                    if metric_name in ["MAE 0", "MAE 1-5", "MAE 6-10", "MAPE 11+"]
                },
                "mae": {
                    metric_name.split("MAE ")[1]: metric_value
                    for metric_name, metric_value in metrics.items()
                    if "MAE" in metric_name
                },
                "mape": {
                    metric_name.split("MAPE ")[1]: metric_value * 100
                    for metric_name, metric_value in metrics.items()
                    if "MAPE" in metric_name and "0" != metric_name and "0+" not in metric_name
                },
                "ratio": {
                    f"{mask_name}": (mask.sum() / len(mask)) * 100
                    for mask_name, mask in masks.items()
                },
            }
        )
        # more explicit rename of main KPIs
        evaluations["main"]["MAE (counts) 0"] = evaluations["main"].pop("MAE 0")
        evaluations["main"]["MAE (counts) 1-5"] = evaluations["main"].pop("MAE 1-5")
        evaluations["main"]["MAE (counts) 6-10"] = evaluations["main"].pop("MAE 6-10")
        evaluations["main"]["MAPE (% counts) 11+"] = evaluations["main"].pop("MAPE 11+") * 100

        # return KPIs
        return evaluations

    def get_tasks_metrics(self) -> Dict[str, List[str]]:
        """Return the evaluator tasks, and for each task, it's list of metrics."""
        return {task: list(metrics.keys()) for task, metrics in self.evaluate().items()}
