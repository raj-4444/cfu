"""Metrics module."""

import logging

import numpy as np

logger = logging.getLogger(__name__)


def _shape_check(actual: np.ndarray, predicted: np.ndarray) -> None:
    if actual.shape != predicted.shape:
        raise ValueError(
            "actual and predicted must be of same shape: " f"{actual.shape} != {predicted.shape}."
        )


def mae(actual: np.ndarray, predicted: np.ndarray) -> float:
    """Compute the Mean Absolute Error."""
    _shape_check(actual, predicted)

    actual = actual.ravel()
    predicted = predicted.ravel()

    return float(np.fabs((actual - predicted)).mean())


def mse(actual: np.ndarray, predicted: np.ndarray) -> float:
    """Compute the Mean Absolute Error."""
    _shape_check(actual, predicted)

    actual = actual.ravel().astype(np.float64)
    predicted = predicted.ravel().astype(np.float64)
    return float((np.square(actual - predicted)).mean())


def mape(actual: np.ndarray, predicted: np.ndarray) -> float:
    """Compute the Mean Absolute Percentage Error."""
    _shape_check(actual, predicted)

    actual = actual.ravel()
    predicted = predicted.ravel()

    mask = actual != 0
    return float(np.fabs((actual - predicted) / actual)[mask].mean())


def maape(actual: np.ndarray, predicted: np.ndarray, epsilon: float = 10 ** -10) -> float:
    """
    Compute the Mean Arctangent Absolute Percentage Error.

    Parameters
    ----------
    actual
        Actual values.
    predicted
        Predicted values.
    epsilon
        If facing division by zero, i.e. when actual values are zeros. Sound
        default would for example be mean(actual) * 10**-10,
        as long as mean(actual) != 0.

    Notes
    -----
    The MAAPE is an attempt to solve the MAPE drawbacks,
    i.e. undefinite and very big errors when the actual value
    is zero or close to zero, respectively.

    See: https://www.sciencedirect.com/science/article/pii/S0169207016000121
    """
    _shape_check(actual, predicted)

    actual = actual.ravel()
    predicted = predicted.ravel()
    diff = actual - predicted
    idces_zero = diff == 0.0

    maape_results = np.arctan(np.fabs(diff / (actual + epsilon)))
    maape_results[idces_zero] = 0.0

    return float(maape_results.mean())


def calibration(pi_expected: float, pi_actual: float) -> float:
    """
    Compute the calibration of a prediction interval.

    Calibration as close as possible to 0 is best.
    """
    return 1 - abs(pi_expected / pi_actual)
