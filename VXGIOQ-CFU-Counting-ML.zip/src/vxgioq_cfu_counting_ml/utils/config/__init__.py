"""FastAPI configuration."""

from vxgioq_cfu_counting_ml.utils.config.logging import configure_root_logger

__all__ = ["configure_root_logger"]
