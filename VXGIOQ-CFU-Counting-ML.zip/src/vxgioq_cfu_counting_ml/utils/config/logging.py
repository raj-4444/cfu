"""Logging configuration."""

import logging

import coloredlogs


def configure_root_logger(level: int = logging.DEBUG) -> None:
    """Configure the root logger."""
    # Remove all handlers associated with the root logger object.
    for handler in logging.root.handlers:
        logging.root.removeHandler(handler)
    # Configure 3-party loggers to propagate to the root logger for chosen login
    third_party_logger_names = ["azure", "numba"]
    for logger_name in third_party_logger_names:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.ERROR)

    logging.root.setLevel(level)

    coloredlogs.install()
