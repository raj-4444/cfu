"""Module to display and save images, predictions, masks, ..."""
import logging
import os
from enum import Enum
from io import BytesIO
from itertools import accumulate
from operator import add
from pathlib import Path
from typing import List, Optional

import holoviews as hv
import numpy as np
import pandas as pd
import xarray as xr
from detectron2.config.config import CfgNode
from detectron2.engine.defaults import DefaultPredictor
from PIL import Image
from tqdm.auto import tqdm

from vxgioq_cfu_counting_ml.utils.conf import delete_folders
from vxgioq_cfu_counting_ml.utils.convert import (
    batch_to_dataset_enhanced,
    image_to_dataset_enhanced,
)
from vxgioq_cfu_counting_ml.utils.types import (
    Detectron2DatasetEnhanced,
    ModelInputsFormat,
    ModelQuantile,
)

logger = logging.getLogger(__name__)

hv.extension("bokeh")

# 850 WIDTH and HEIGHT is good for 4K screens, 400 for normal HD screens
WIDTH = 850
HEIGHT = 850

EPS = 1e-10


def display_enhanced_dataset(
    dataset_enhanced: Detectron2DatasetEnhanced, width: int = WIDTH, height: int = HEIGHT
) -> hv.DynamicMap:
    """
    Display original, labeled (if available) and predicted (if available) images.

    The original, labeled and predicted images are displayed, together with the labeled and
    predicted number of CFUs.
    A slider is available to choose the example to visualize.
    """

    def display_example(index: int) -> hv.Layout:
        """Display an example enhanced data dict from a list of enhanced data dicts."""
        image_original = dataset_enhanced[index]["image_original"]
        image_labeled = dataset_enhanced[index].get("image_labeled", None)
        image_preds = dataset_enhanced[index].get("image_predicted", None)
        n_cfus_labeled = (
            dataset_enhanced[index]["n_cfus_labeled"] if image_labeled is not None else None
        )
        n_cfus_predicted = (
            dataset_enhanced[index]["n_cfus_predicted"] if image_preds is not None else None
        )
        pi_interval = (
            dataset_enhanced[index]["pi_interval"] * 100 if image_preds is not None else None
        )
        n_cfus_pi_low = (
            dataset_enhanced[index]["n_cfus_pi_low"] if image_preds is not None else None
        )
        n_cfus_pi_high = (
            dataset_enhanced[index]["n_cfus_pi_high"] if image_preds is not None else None
        )
        file_name = dataset_enhanced[index].get("file_name", "Batch example")
        title = "Display examples"
        subtitle_original = f"Original: {file_name}"
        subtitle_labels = "Labeled | CFUs: {}"
        subtitle_predictions = "Prediction | CFUs: {} | {}% PI: [{}, {}]"
        if image_labeled is not None and image_preds is not None:
            layout = (
                hv.RGB(image_original, label=subtitle_original).opts(width=width, height=height)
                + hv.RGB(image_labeled, label=subtitle_labels.format(n_cfus_labeled)).opts(
                    width=width, height=height
                )
                + hv.RGB(
                    image_preds,
                    label=subtitle_predictions.format(
                        n_cfus_predicted, pi_interval, n_cfus_pi_low, n_cfus_pi_high
                    ),
                ).opts(width=width, height=height)
            ).opts(title=title)
        elif image_labeled is not None and image_preds is None:
            layout = hv.RGB(image_original, label=subtitle_original).opts(
                width=width, height=height
            ) + hv.RGB(image_labeled, label=subtitle_labels.format(n_cfus_labeled)).opts(
                width=width, height=height
            )
        elif image_preds is not None and image_labeled is None:
            layout = hv.RGB(image_original, label=subtitle_original).opts(
                width=width, height=height
            ) + hv.RGB(image_preds, label=subtitle_predictions.format(n_cfus_predicted)).opts(
                width=width, height=height
            )
        else:
            layout = hv.RGB(image_original, label=subtitle_original).opts(
                width=width, height=height
            )

        return layout

    dmap = hv.DynamicMap(display_example, kdims=["index"])
    return dmap.redim.values(index=range(len(dataset_enhanced)))


def display_image(
    image: np.ndarray, predictor: DefaultPredictor, width: int = WIDTH, height: int = HEIGHT,
) -> hv.DynamicMap:
    """Display image and it's prediction (computed on the fly)."""
    # convert image to data dict enhanced
    dataset_enhanced = image_to_dataset_enhanced(image_original=image, predictor=predictor)

    # display data dicts enhanced
    return display_enhanced_dataset(dataset_enhanced=dataset_enhanced, width=width, height=height)


def display_batch(
    batch: ModelInputsFormat,
    cfg: Optional[CfgNode] = None,
    width: int = WIDTH,
    height: int = HEIGHT,
) -> hv.DynamicMap:
    """Display images from a training/test batch."""
    # convert batch to enhanced data dicts
    dataset_enhanced = batch_to_dataset_enhanced(batch=batch, cfg=cfg)

    # display data dicts enhanced
    return display_enhanced_dataset(dataset_enhanced=dataset_enhanced, width=width, height=height)


def display_violin(
    bbox_sizes: np.ndarray, name: Optional[str], width: int = WIDTH, height: int = HEIGHT,
) -> hv.element.stats.Violin:
    """Generate a violin plot based on a numpy array and displays basic distribution info."""
    title = f"μ = {bbox_sizes.mean():.1f} | σ = {bbox_sizes.std():.1f} | min = {bbox_sizes.min():.1f} | max = {bbox_sizes.max():.1f}"
    if name:
        title = f"{name}: " + title
    return hv.Violin(bbox_sizes).opts(width=width, height=height, title=title)


def display_pi(
    X: pd.DataFrame,
    y: pd.Series,
    y_preds_dl: pd.Series,
    model_quantile_low: ModelQuantile,
    model_quantile_high: ModelQuantile,
    alpha: float = 0.7,
    width: int = 1200,
    height: int = 800,
) -> hv.Overlay:
    """Display and compare the DL and PI models predictions."""
    # deep copy the input data as inplace modifs will be applied
    X = X.copy(deep=True)
    y = y.copy(deep=True)
    y_preds_dl = y_preds_dl.copy(deep=True)

    # sort the data ascending according to actual counts for nicer visualization
    idx_sorted = y.argsort()

    X = X.loc[idx_sorted, :]
    X.reset_index(inplace=True, drop=True)

    y = y.loc[idx_sorted]
    y = y.reset_index(drop=True)

    y_preds_dl = y_preds_dl.loc[idx_sorted]
    y_preds_dl = y_preds_dl.reset_index(drop=True)

    # get the DL model predictions
    y_preds_dl.name = "predictions: DL model"

    # compute pi
    y_quantile_low = np.rint(model_quantile_low.predict(X)).astype(np.uint16)
    mask_trunc_low = y_quantile_low > y_preds_dl
    y_quantile_low[mask_trunc_low] = y_preds_dl[mask_trunc_low]

    y_quantile_high = np.rint(model_quantile_high.predict(X)).astype(np.uint16)
    mask_trunc_high = y_quantile_high > y_preds_dl
    y_quantile_high[mask_trunc_high] = y_preds_dl[mask_trunc_high]

    # generate the overlay object
    return (
        hv.Curve(y, label="True count").opts(alpha=alpha, line_width=5)
        * hv.Curve(y_preds_dl, label=y_preds_dl.name).opts(alpha=alpha)
        * hv.Area(
            (y_quantile_low.index, y_quantile_low, y_quantile_high),
            vdims=["y1", "y2"],
            label=f"{int((model_quantile_high.quantile.expected - model_quantile_low.quantile.expected) * 100)}% PI",
        ).opts(alpha=0.5)
    ).opts(legend_position="top_left", width=width, height=height)


class NormalizeOption(Enum):
    """Enum Normalization options for the sample matrix."""

    NO = 1
    EXAMPLES_WISE = 2
    FEATURES_WISE = 3


def display_dataset(
    X: pd.DataFrame,
    y: pd.Series,
    sort: bool = True,
    normalized: NormalizeOption = NormalizeOption.EXAMPLES_WISE,
    width: int = 1000,
    height: int = 1000,
    x_label: str = "Model score",
    y_label: str = "Examples",
    label: str = "DL model CDFs",
    clabel: str = "counts",
    cmap: str = "Plasma",
) -> hv.Image:
    """Display a sample matrix and it's response variable."""
    # normalize data if need be
    X = X.copy()
    y = y.copy()
    data = pd.concat([X, y], axis=1)
    if normalized == NormalizeOption.EXAMPLES_WISE:
        X = np.nan_to_num(X.to_numpy() / data.to_numpy().max(axis=1, keepdims=True))
        y = pd.Series(np.nan_to_num(y.to_numpy() / data.to_numpy().max(axis=1, keepdims=False)))

        normalization_name = "Normalized examples-wise "
    elif normalized == NormalizeOption.FEATURES_WISE:
        X = np.nan_to_num(X.to_numpy() / X.to_numpy().max(axis=0, keepdims=True))
        y = pd.Series(np.nan_to_num(y.to_numpy() / y.to_numpy().max(axis=0, keepdims=False)))
        normalization_name = "Normalized features-wise "
    else:
        X = X.to_numpy()
        normalization_name = ""

    # sort data if need be
    if sort:
        idx_sorted = np.argsort(X.mean(axis=1))
        X = X[idx_sorted, ...]
        y = y[idx_sorted]

    # compute the image
    y = pd.concat([y, y], axis=1)
    return hv.Image(
        xr.DataArray(
            X,
            coords=[np.arange(X.shape[0]), np.arange(X.shape[1])[::-1] / X.shape[1]],
            dims=[y_label, x_label],
        ),
        kdims=[x_label, y_label],
        vdims=[f"{normalization_name}{clabel}"],
        label=f"{normalization_name}{label}",
    ).opts(
        tools=["hover"],
        colorbar=True,
        cmap=cmap,
        clabel=f"{normalization_name}{clabel}",
        width=width,
        height=height,
    ) + hv.Image(
        xr.DataArray(
            y, coords=[np.arange(y.shape[0]), np.arange(y.shape[1])], dims=[y_label, x_label],
        ),
        kdims=[x_label, y_label],
        vdims=[f"{normalization_name}{clabel}"],
        label=f"{normalization_name} Actual counts",
    ).opts(
        tools=["hover"],
        colorbar=True,
        cmap=cmap,
        clabel=f"{normalization_name}{clabel}",
        width=width,
        height=height,
    )


def display_features_importance(
    regs: List[ModelQuantile], nlargest: int = 20, width: int = WIDTH, height: int = HEIGHT
) -> hv.Layout:
    """Display the features importance on lightgbm regressors."""
    # get feature importance
    feats_imp = {
        reg.name: pd.Series(
            reg.model.feature_importances_, index=reg.column_names, name="importance"
        )
        for reg in regs
    }

    # generate plots
    return list(
        accumulate(
            [
                hv.Bars(feat_imp.nlargest(nlargest), label=model_name).opts(
                    width=width, height=height, invert_axes=True
                )
                for model_name, feat_imp in feats_imp.items()
            ],
            add,
        )
    )[-1].opts(shared_axes=False)


def display_matches(index: int, matches: pd.DataFrame, width: int, height: int) -> hv.Layout:
    """Display original, scan4000 and DL matching images."""
    example = matches.iloc[index, :]
    image_original = np.array(Image.open(example["dl image original"]))[:, :, :3]
    image_labeled = np.array(Image.open(example["image labeled"]))[:, :, :3]
    image_scan4000 = np.array(Image.open(example["scan4000 image predicted"]))[:, :, :3]
    image_dl = np.array(Image.open(example["dl image predicted"]))[:, :, :3]

    return (
        hv.RGB(image_original).opts(title=example["dl image original"], width=width, height=height)
        + hv.RGB(image_labeled).opts(
            title=f"True CFUs: {example['true count']}", width=width, height=height
        )
        + hv.RGB(image_scan4000).opts(
            title=f"Scan4000 CFUs: {example['scan4000 count']}", width=width, height=height
        )
        + hv.RGB(image_dl).opts(
            title=f"DL CFUs: {example['dl count']} (95% Prediction Interval: [{int(np.round(example['PI low']))}, {int(np.round(example['PI high']))}])",
            width=width,
            height=height,
        )
    )


def compare_scan4000_and_dl_images(
    matches: pd.DataFrame, width: int = 800, height: int = 800
) -> hv.DynamicMap:
    """Campare original, scan4000 and DL predicted images."""

    def _display_example(index: int) -> hv.Layout:
        return display_matches(index=index, matches=matches, width=width, height=height)

    index = len(matches)
    dmap = hv.DynamicMap(_display_example, kdims=["index"])
    return dmap.redim.values(index=range(index))


def save_examples(
    matches: pd.DataFrame,
    output_folder: str,
    overwrite: bool = True,
    width: int = 800,
    height: int = 800,
    quality: int = 75,
) -> None:
    """Run and save the plots of the examples comparisons."""
    if overwrite and os.path.isdir(output_folder):
        delete_folders([output_folder])
    Path(output_folder).mkdir(parents=True, exist_ok=True)
    n_examples = len(matches)
    for index in tqdm(range(n_examples)):
        # generate the plot
        plot = display_matches(index=index, matches=matches, width=width, height=height)

        # save the png temprarly in a stream
        stream = BytesIO()
        hv.save(obj=plot, filename=stream, fmt="png")
        _ = stream.seek(0)

        # convert the temporary png into compressed jpg
        path_to_save = os.path.join(
            output_folder,
            os.path.basename(matches.iloc[index]["scan4000 image original"]).split(".")[0] + ".jpg",
        )
        Image.open(stream).convert("RGB").save(path_to_save, quality=quality)
