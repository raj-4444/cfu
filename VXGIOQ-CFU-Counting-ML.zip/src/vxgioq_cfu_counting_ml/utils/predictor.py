"""
Module for custom CFU predictor.

isort:skip_file
"""

import logging
from copy import deepcopy
from typing import List, Any
from io import BytesIO
from datetime import datetime, timezone
import base64
import numpy as np
import pandas as pd
from PIL import ImageOps, Image, ImageDraw
import torch
import tensorflow as tf
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.data import MetadataCatalog
import detectron2.data.transforms as T
from detectron2.engine.defaults import DefaultPredictor
from detectron2.modeling import build_model
from detectron2.structures import Boxes
from detectron2.structures.instances import Instances

from vxgioq_cfu_counting_ml.api.data_models import (
    CFUOutput,
    ImageOutput,
    Predictions,
    Region,
    ShapeAttributes,
)
from vxgioq_cfu_counting_ml.utils.custom_datasets import mask_2_polygon
from vxgioq_cfu_counting_ml.utils.azure import download_unzip_clean_model, upload_file_to_blob
from vxgioq_cfu_counting_ml.utils.loader import (
    download_unzip_best_model,
    load_config,
    load_pi_models,
)
from vxgioq_cfu_counting_ml.utils.prediction_intervals import scores_to_compiled_cdfs
from vxgioq_cfu_counting_ml.utils.types import (
    CFUPredictorOutputFormat,
    CFUPredictorPIOutputFormat,
    ModelOutputsFormatInference,
    ModelPrediction,
    ModelQuantilesInterval,
    QuantilePrediction,
)

logger = logging.getLogger(__name__)


class CFUPredictor(DefaultPredictor):
    """
    Create a CFU end-to-end predictor with the given config that runs on single device for several input images.

    Compared to using the model directly, this class does the following additions:

    0. Load the model (DL and PI models) by name and tries to download it if not available.
    1. Load checkpoint from `cfg.MODEL.WEIGHTS`.
    2. Modify the copied config to keep objects at a threshold of 0 instead of the cfg value for the PI model to use all the DL model information spectrum.
    3. Always take BGR image as the input and apply conversion defined by `cfg.INPUT.FORMAT`.
    4. Apply resizing defined by `cfg.INPUT.{MIN,MAX}_SIZE_TEST`.
    5. Take a list of input images and produce a list of outputs to which are added the PI model predictions.

    Attributes
    ----------
    metadata (Metadata): the metadata of the underlying dataset, obtained from
        cfg.DATASETS.TEST.
    """

    def __init__(self, model_name: str) -> None:
        """
        Create a CFU end-to-end predictor.

        Parameters
        ----------
        model_name
            The model name to load (and try to download first if not available).
        """
        # download that model if need be
        download_unzip_clean_model(model_name=model_name)

        # load the cfg and clone it as the model can modify it
        self.cfg = load_config(
            model_name=model_name, score_thresh_test=None, filter_empty_annotations=None
        ).clone()

        self.model_name = model_name

        # save the original score_thresh_test
        self.original_score_thresh_test = deepcopy(
            self.cfg["MODEL"]["ROI_HEADS"]["SCORE_THRESH_TEST"]
        )

        # set the score_thresh_test to zero for PI model
        self.cfg["MODEL"]["ROI_HEADS"]["SCORE_THRESH_TEST"] = 0.0

        # build model
        self.model = build_model(self.cfg)
        self.model.eval()
        if len(self.cfg.DATASETS.TEST):
            self.metadata = MetadataCatalog.get(self.cfg.DATASETS.TEST[0])

        # load checkpoint
        checkpointer = DetectionCheckpointer(self.model)
        checkpointer.load(self.cfg.MODEL.WEIGHTS)

        # setup any test transformations
        self.aug = T.ResizeShortestEdge(
            [self.cfg.INPUT.MIN_SIZE_TEST, self.cfg.INPUT.MIN_SIZE_TEST],
            self.cfg.INPUT.MAX_SIZE_TEST,
        )

        # set-up and assess some input cfg parameters
        self.input_format = self.cfg.INPUT.FORMAT
        assert self.input_format in ["RGB", "BGR"], self.input_format

        # load the predictions intervals models
        logger.info("Loading PI models...")
        self.models_pi: ModelQuantilesInterval = load_pi_models(model_name=self.model_name)

    def _predict(self, original_images: List[np.ndarray]) -> List[CFUPredictorOutputFormat]:
        """
        Predict all instances, up to min score threshold == 0.

        Notes
        -----
        Actually, detectron2 predictions which scores are very close to zero are likely not to get a binary mask computed for them.
        Hence, one should not rely on the masks returned by this function.
        """
        with torch.no_grad():  # type: ignore # https://github.com/sphinx-doc/sphinx/issues/4258
            # apply pre-processing to image
            if self.input_format == "RGB":
                # whether the model expects BGR inputs or RGB
                original_images = [original_image[:, :, ::-1] for original_image in original_images]

            # prepare the images for the model
            inputs = [
                {
                    "image": torch.as_tensor(
                        self.aug.get_transform(original_image)
                        .apply_image(original_image)
                        .astype("float32")
                        .transpose(2, 0, 1)
                    ),
                    "height": original_image.shape[0],
                    "width": original_image.shape[1],
                }
                for original_image in original_images
            ]
            # compute predictions
            predictions: ModelOutputsFormatInference = self.model(inputs)

            # convert predictions (list of dicts) to the more convenient list of pydantic datamodels format
            dl_predictions: List[CFUPredictorOutputFormat] = []
            for prediction in predictions:
                instances = prediction["instances"].to("cpu")
                mask_instances = instances.scores >= self.original_score_thresh_test
                dl_count = int(mask_instances.sum())
                dl_predictions.append(
                    CFUPredictorOutputFormat(
                        instances=instances,
                        model_prediction=ModelPrediction(
                            score_threshold=self.original_score_thresh_test, prediction=dl_count
                        ),
                    )
                )

            return dl_predictions

    def _filter_instances(self, instances: Instances) -> Instances:
        """Filter out instances which scores are below the test threshold."""
        # get the scores mask
        mask_instances = instances.scores >= self.original_score_thresh_test

        # filter out the instances which are below the test threshold
        instances = Instances(
            image_size=instances.image_size,
            scores=instances.scores[mask_instances],
            pred_classes=instances.pred_classes[mask_instances],
            pred_masks=instances.pred_masks[mask_instances, ...],
            pred_boxes=Boxes(tensor=instances.pred_boxes.tensor[mask_instances, ...]),
        )

        return instances

    def __call__(self, original_images: List[np.ndarray]) -> List[CFUPredictorOutputFormat]:
        """
        Compute batch predictions.

        Parameters
        ----------
        original_image (np.ndarray): an image of shape (H, W, C) (in BGR order).

        Returns
        -------
        predictions
            the output of the DL and PI models for many images.
        """
        # get all predictions
        dl_predictions = self._predict(original_images=original_images)

        # filter out the instances which are below the test scores threshold
        for i, dl_prediction in enumerate(dl_predictions):
            dl_predictions[i].instances = self._filter_instances(dl_prediction.instances)

        return dl_predictions

    def predict(self, original_images: List[np.ndarray]) -> List[CFUPredictorOutputFormat]:
        """Alias of def __call__()."""
        return self.__call__(original_images=original_images)

    def predict_quantiles(
        self, original_images: List[np.ndarray]
    ) -> List[CFUPredictorPIOutputFormat]:
        """Compute DL and quantiles batch predictions."""
        # compute all DL predictions (with score threshold 0)
        dl_predictions = self._predict(original_images=original_images)

        # extract the scores
        scores: List[np.ndarray] = [
            dl_prediction.instances.scores.numpy() for dl_prediction in dl_predictions
        ]

        # run PI predictions
        # ------------------
        predictions_per_quantile: List[pd.Series] = []
        quantiles: List[float] = []

        for model_pi in [self.models_pi.low, self.models_pi.high]:
            # compute the PI dataset for the model
            X = scores_to_compiled_cdfs(scores=scores, n_bins=model_pi.n_bins)

            # run PI predictions
            predictions_per_quantile.append(model_pi.predict(X))
            quantiles.append(model_pi.quantile.expected)

        # combine and return results
        dl_pi_predictions: List[CFUPredictorPIOutputFormat] = []
        for i, dl_prediction in enumerate(dl_predictions):
            # extract the instances
            instances = dl_prediction.instances

            # extract the model prediction count
            dl_count = dl_prediction.model_prediction.prediction

            # remove instances which scores are below the test threshold
            instances = self._filter_instances(instances)

            # extract (and truncate if need be) the PIs
            quantiles_predictions: List[QuantilePrediction] = []
            for pred_per_quantile, quantile in zip(predictions_per_quantile, quantiles):
                prediction = float(pred_per_quantile[i])

                # Truncate quantiles so DL predictions always remain inside the PIs
                if quantile < 0.5 and prediction > dl_count:
                    prediction = dl_count
                elif quantile > 0.5 and prediction < dl_count:
                    prediction = dl_count

                quantiles_predictions.append(
                    QuantilePrediction(quantile=quantile, prediction=prediction)
                )

            # generate the output format pi and dl prediction
            dl_pi_predictions.append(
                CFUPredictorPIOutputFormat(
                    instances=instances,
                    model_prediction=ModelPrediction(
                        score_threshold=self.original_score_thresh_test, prediction=dl_count
                    ),
                    quantiles_predictions=quantiles_predictions,
                )
            )

        return dl_pi_predictions


def get_best_cfu_model(task: str = "main", metric: str = "MAE (counts) 6-10") -> CFUPredictor:
    """Fetch all available models benchmarks and download and load in CFUPredictor the one with best results on chosen KPI (Counts all MAE)."""
    # download models kpis, get best model name and download that model
    best_model_name = download_unzip_best_model(task=task, metric=metric)

    # load that best model in a CFUPredictor (handles batch inference and quantile predictions)
    return CFUPredictor(model_name=best_model_name)


def get_best_classification_model(model_name: str) -> None:
    """Fetch the model from the blob storage."""
    download_unzip_clean_model(model_name, overwrite=True)


def get_retrained_segmentation_model(model_name: str) -> Any:
    """Fetch the model from blob storage."""
    download_unzip_clean_model(model_name, overwrite=True)

    return CFUPredictor(model_name=model_name)

def resize_with_padding(img: Any, expected_size: Any) -> Any:
    """Apply resize of images with padding."""
    img.thumbnail((expected_size[0], expected_size[1]))
    delta_width = expected_size[0] - img.size[0]
    delta_height = expected_size[1] - img.size[1]
    pad_width = delta_width // 2
    pad_height = delta_height // 2
    padding = (pad_width, pad_height, delta_width - pad_width, delta_height - pad_height)
    return ImageOps.expand(img, padding)


def resize(img: Any, expected_size: Any) -> Any:
    """Return the image by applying lanczos filter method."""
    return ImageOps.fit(img, expected_size, method=Image.LANCZOS)


def draw_and_crop_bboxes(image_shape: Any, boxes: Any, copy: Any) -> Any:
    """Draw the polygon boxes based on predictions."""
    area  = (int(boxes[0]), int(boxes[1]), int(boxes[2]), int(boxes[3]))
    draw = ImageDraw.Draw(copy)
    draw.ellipse(area, outline ="red")
    colony = image_shape.crop(area)
    colony.save("colony.png")


def predict_colony(predictions_bboxes: Any, image_shape: Any, index: Any) -> Any:
    """
    Peprocess the image colony.

    1. Crops the image using predicted bboxes
    2. resize with padding 
    3. creates a batch of images
    4. create a base64 format of predicted image with highlighted in it.
    """
    img_height, img_width, pred_array = 224, 224, []
    copy = image_shape.copy()
    for idx, boxes in enumerate(predictions_bboxes[index]): 
        draw_and_crop_bboxes(image_shape, boxes, copy)            
        img = Image.open("colony.png")
        w, h = img.size
        if (h < img_height):
            img = resize_with_padding(img, (img_height, img_width))
        else:
            img = resize(img, (img_height, img_width))
        img.save("colony1.png")
        img = tf.keras.utils.load_img("colony1.png", grayscale=False, target_size=(299,299))
        img_array = tf.keras.preprocessing.image.img_to_array(img)
        img_array = tf.expand_dims(img_array, 0) # Create a batch
        pred_array.append(img_array)
    
    # Get the base64 format from highlighted/predicted image
    buffered = BytesIO()
    copy.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue())
    return img_str, pred_array


def get_classification_score(new_model: Any, pil_image: Any, predictions_bboxes: Any) -> Any:
    """Get the prediction scores from the classification model."""
    scores = []
    for index, image_shape in enumerate(pil_image):
        prediction = []
        img_str, pred_array = predict_colony(predictions_bboxes, image_shape, index)
        val = np.concatenate(pred_array)
        for predict_score in new_model.predict(val):
            if predict_score[0] >= 0.5:
                prediction.append(1)
            else:
                prediction.append(0)
        scores.append(prediction)
    return img_str, scores


def write_prediction_JSON(dishes: Any, predictions: Any, heights: Any, widths: Any, scores: Any, model_name: Any) -> Any:
    """Write the prediction JSON outputin the CFU format."""
    predictions_datetime = datetime.now(tz=timezone.utc)
    # write output json
    logger.info("Prepare response...")
    max_edges = 101
    response = CFUOutput(
        images=[
            ImageOutput(
                sample_id=dish["sample_id"],
                image_original_url=dish["image_original_url"],
                image_predicted_url=dish["image_predicted_url"],
                predictions=Predictions(
                    filename=dish["image_predicted_url"],
                    model_name=model_name,
                    size=height * width,
                    regions=[
                        Region(
                            shape_attributes=ShapeAttributes(
                                all_points_x=mask_2_polygon(pred_mask, max_edges=max_edges)[
                                    :, 1
                                ].tolist(),
                                all_points_y=(
                                    mask_2_polygon(pred_mask, max_edges=max_edges)[:, 0]
                                ).tolist(),
                                name="polygon",
                                category_id=score_val,
                            ),
                            region_attributes={},
                        )
                        for pred_mask, score_val in zip(prediction.instances.pred_masks.numpy(), score)
                    ],
                    predictions_cfu_count=prediction.model_prediction.prediction,
                    predictions_cfu_count_quantiles=prediction.quantiles_predictions,
                    predictions_scores=prediction.instances.scores.tolist(),
                    predictions_bboxes=prediction.instances.pred_boxes.tensor.tolist(),
                    predictions_datetime=predictions_datetime,
                ),
            )
            for dish, prediction, height, width, score in zip(dishes, predictions, heights, widths, scores)
        ]
    )
    return response
