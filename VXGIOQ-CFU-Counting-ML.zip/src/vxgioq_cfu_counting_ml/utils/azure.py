"""
Azure tools module.

isort:skip_file
"""

import json
import logging
import os
import base64
import urllib.parse
from functools import lru_cache
from io import BytesIO, StringIO
from pathlib import Path
from typing import List, Tuple, Union, Any
from urllib.parse import quote_plus
from zipfile import ZIP_LZMA, ZipFile, is_zipfile

import numpy as np
import cv2
from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob import BlobServiceClient
from PIL import Image
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database

from vxgioq_cfu_counting_ml.utils.types import ModelsKPIs

logger = logging.getLogger(__name__)

# Azure Cosmos Mongo DB
COSMOS_USER_NAME = os.environ["COSMOS_USER_NAME"]
COSMOS_PASSWORD = os.environ["COSMOS_PASSWORD"]
COSMOS_HOST = os.environ["COSMOS_HOST"]
COSMOS_APP_NAME = os.environ["COSMOS_APP_NAME"]
COSMOS_PORT = "10255"
COSMOS_DATABASE_NAME = "cfu_database"
COSMOS_COLLECTION_NAME = "cfu_counting_collection"
COSMOS_COLLECTION_NAME_PHASE2 = "cfu_counting_collection_phase2"

CONNECTION_URI = f"mongodb://{quote_plus(COSMOS_USER_NAME)}:{quote_plus(COSMOS_PASSWORD)}@{COSMOS_HOST}:{COSMOS_PORT}/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@{COSMOS_APP_NAME}@"

# Azure storage
ACCOUNT_KEY = "?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacupitfx&se=2022-04-30T14:46:22Z&st=2022-01-06T06:46:22Z&spr=https&sig=%2F4dl%2Bn4qhabs%2BK6xSsD8ryRzdJeNrOD17hP1m9tBo3I%3D"
ACCOUNT_URL = f"https://{os.environ['STORAGE_NAME']}.blob.core.windows.net"
PATH_DATA_ON_DISK = "data"
PATH_PREDICTIONS_ON_DISK = "predictions"
PATH_MODELS_ON_DISK = "models"
PATH_CONFIGS_ON_DISK = "configs"
CONTAINER = "machine-learning"
PATH_DATA_DIRNAME_ON_BLOB = "data"
PATH_PREDICTIONS_DIRNAME_ON_BLOB = "predictions"
PATH_MODELS_DIRNAME_ON_BLOB = "models"

if os.getcwd() == "/app":  # docker test case
    pass
elif os.getcwd() == "/app/src":  # docker run case
    PATH_DATA_ON_DISK = os.path.join("..", PATH_DATA_ON_DISK)
    PATH_PREDICTIONS_ON_DISK = os.path.join("..", PATH_PREDICTIONS_ON_DISK)
    PATH_MODELS_ON_DISK = os.path.join("..", PATH_MODELS_ON_DISK)
    PATH_CONFIGS_ON_DISK = os.path.join("..", PATH_CONFIGS_ON_DISK)
elif os.getcwd().split("/")[-1] == "VXGIOQ-CFU-Counting-ML":
    pass
elif os.getcwd().split("/")[-2] == "VXGIOQ-CFU-Counting-ML":  # notebooks case
    PATH_DATA_ON_DISK = os.path.join("..", PATH_DATA_ON_DISK)
    PATH_PREDICTIONS_ON_DISK = os.path.join("..", PATH_PREDICTIONS_ON_DISK)
    PATH_MODELS_ON_DISK = os.path.join("..", PATH_MODELS_ON_DISK)
    PATH_CONFIGS_ON_DISK = os.path.join("..", PATH_CONFIGS_ON_DISK)
elif os.getcwd().split("/")[-3] == "VXGIOQ-CFU-Counting-ML":
    PATH_DATA_ON_DISK = os.path.join("..", "..", PATH_DATA_ON_DISK)
    PATH_PREDICTIONS_ON_DISK = os.path.join("..", "..", PATH_PREDICTIONS_ON_DISK)
    PATH_MODELS_ON_DISK = os.path.join("..", "..", PATH_MODELS_ON_DISK)
    PATH_CONFIGS_ON_DISK = os.path.join("..", "..", PATH_CONFIGS_ON_DISK)
elif os.getcwd().split("/")[-4] == "VXGIOQ-CFU-Counting-ML":
    PATH_DATA_ON_DISK = os.path.join("..", "..", "..", PATH_DATA_ON_DISK)
    PATH_PREDICTIONS_ON_DISK = os.path.join("..", "..", "..", PATH_PREDICTIONS_ON_DISK)
    PATH_MODELS_ON_DISK = os.path.join("..", "..", "..", PATH_MODELS_ON_DISK)
    PATH_CONFIGS_ON_DISK = os.path.join("..", "..", "..", PATH_CONFIGS_ON_DISK)
else:
    raise ValueError(
        "Cannot determine how to set `PATH_DATA_ON_DISK` and `PATH_MODEL_ON_DISK` based "
        "on the current working directory."
    )

PATH_DATA_ON_BLOB = f"{ACCOUNT_URL}/{CONTAINER}/{PATH_DATA_DIRNAME_ON_BLOB}"
PATH_PREDICTIONS_ON_BLOB = f"{ACCOUNT_URL}/{CONTAINER}/{PATH_PREDICTIONS_DIRNAME_ON_BLOB}"
PATH_MODELS_ON_BLOB = f"{ACCOUNT_URL}/{CONTAINER}/{PATH_MODELS_DIRNAME_ON_BLOB}"

DATASET_DETECTRON2_NAME = "dataset_detectron2.lz4"
MODELS_KPIS_NAME = "models_KPIs.json"

MODEL_WEIGHTS_NAME = "model_final.pth"
MODEL_CONFIG_NAME = "config.yaml"
MODELS_QUANTILES_NAME = "models_quantiles.lz4"
DATASETS_QUANTILES_NAME = "datasets_quantiles.lz4"
MODEL_LAST_CHECKPOINT_NAME = "last_checkpoint"
MODEL_EVENTS_NAME = "events"


def parse_az_storage_url(url: str) -> Tuple[str, str, str]:
    """Parse url pointing to a blob into account URL, container name and blob name."""
    parsed_url = urllib.parse.urlparse(url)
    account_url = f"{parsed_url.scheme}://{parsed_url.netloc}/"
    container_name = parsed_url.path.split("/")[1]
    blob_name = "/".join(parsed_url.path.split("/")[2:])
    return account_url, container_name, blob_name


@lru_cache(1)
def get_cosmos_mongo_client() -> MongoClient:
    """Authenticate and create CosmosClient."""
    return MongoClient(CONNECTION_URI)


@lru_cache(1)
def get_cosmos_mongo_db() -> Database:
    """Get Azure cosmos mongo database."""
    client = get_cosmos_mongo_client()
    return client[COSMOS_DATABASE_NAME]


@lru_cache(1)
def get_cosmos_mongo_collection() -> Collection:
    """Get Azure cosmos mongo collection."""
    db = get_cosmos_mongo_db()
    return db[COSMOS_COLLECTION_NAME]


@lru_cache(1)
def get_cosmos_mongo_collection_phase2() -> Collection:
    """Get Azure cosmos mongo collection."""
    db = get_cosmos_mongo_db()
    return db[COSMOS_COLLECTION_NAME_PHASE2]


@lru_cache(1)
def get_blob_service_client() -> BlobServiceClient:
    """Authenticate and create BlobServiceClient."""
    return BlobServiceClient(account_url=ACCOUNT_URL, credential=ACCOUNT_KEY)


def blob_exists(url: str) -> bool:
    """Check if blob at url exists."""
    _, container, blob = parse_az_storage_url(url)
    blob_service_client = get_blob_service_client()
    blob_client = blob_service_client.get_blob_client(container=container, blob=blob)
    try:
        blob_client.get_blob_properties()
        return True
    except ResourceNotFoundError:
        return False


def get_file_from_blob(url: str) -> BytesIO:
    """Read blob contents."""
    _, container_name, blob_name = parse_az_storage_url(url)
    blob_service_client = get_blob_service_client()
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    blob_streamdownloader = blob_client.download_blob()
    stream = BytesIO()
    blob_streamdownloader.readinto(stream)
    stream.seek(0)
    return stream


def _zip_folder(path: str, path_zipped: str, compress: bool = True) -> None:
    """Zip a folder."""
    with ZipFile(path_zipped, "w") as zip_archive:
        for folder, _, files in os.walk(path):
            files = sorted(files)
            for file in files:
                filename = os.path.join(folder, file)
                arcname = os.path.relpath(
                    filename,
                    start=os.path.dirname(path),  # we nest the root folder in the archive as well
                )
                zip_archive.write(
                    filename=filename,
                    arcname=arcname,
                    compress_type=ZIP_LZMA if compress else None,
                )


def _zip_file(path: str, path_zipped: str, compress: bool = True) -> None:
    """Zip a file."""
    with ZipFile(path_zipped, "w") as zip_file:
        zip_file.write(
            filename=path, arcname=path.split("/")[-1], compress_type=ZIP_LZMA if compress else None
        )


def zip_file_folder(path: str, path_zipped: str, compress: bool = True) -> None:
    """
    Zip a file or folder, with or without compression.

    Parameters
    ----------
    path
        Path to file/folder to zip.
    path_zipped
        Path to zip to create.
    compress
        Whether or not to compress the file when zipping it.
    """
    if os.path.isdir(path):
        logger.info(f"Zipping folder: {path} to {path_zipped}.")
        _zip_folder(path=path, path_zipped=path_zipped, compress=compress)
    elif os.path.isfile(path):
        logger.info(f"Zipping file: {path} to {path_zipped}.")
        _zip_file(path=path, path_zipped=path_zipped, compress=compress)
    else:
        raise ValueError(f"Path: {path} is not a directory, nor a file, cannot zip it.")


def unzip_file_folder(path_zipped: str, path: str) -> None:
    """
    Extract a zip file or folder.

    Parameters
    ----------
    path_zipped
        Path to the zipped file/folder.
    path
        Path to extract the zipped file/folder into.
    """
    with ZipFile(path_zipped, "r") as zip_file_folder:
        zip_file_folder.extractall(path=path)


def upload_file_to_blob(file: Union[str, BytesIO, StringIO], url: str, overwrite: bool) -> None:
    """Upload file to Azure blob storage."""
    if not isinstance(file, (str, BytesIO, StringIO)):
        raise TypeError(
            f"File type: {type(file)} is not an instance of "
            f"supported types {[str, BytesIO, StringIO]}."
        )
    # Create blob client
    _, container, blob = parse_az_storage_url(url)
    blob_service_client = get_blob_service_client()
    blob_client = blob_service_client.get_blob_client(container=container, blob=blob)

    # Delete file if already present and overwrite allowed
    if blob_exists(url):
        if overwrite:
            logger.debug("File already exists on blob but overwrite allowed).")
            logger.debug(f"Deleting file: {container}/{blob} ...")
            blob_client.delete_blob()
        else:
            raise FileExistsError("File already exists on blob and overwrite not allowed.")

    # Save file to blob
    logger.debug(f"Saving file to: {container}/{blob} ...")
    if isinstance(file, (BytesIO, StringIO)):
        file.seek(0)
        blob_client.upload_blob(file.read())
    elif isinstance(file, str):
        with open(file, "rb") as data:
            blob_client.upload_blob(data)


def zip_upload_file_folder_to_blob(
    file_folder: str, url: str, overwrite: bool = False, compress: bool = True
) -> None:
    """
    Upload a file or folder to blob storage (and zip it beforehand if not already a zip).

    Parameters
    ----------
    file_folder
        Path to a file or folder.
    overwrite
        If blob with same model_name exists, whether to overwrite. False by default.
    compress
        Whether or not to compress the file when zipping it (if not already zipped).
    """
    is_temp_zip_created = True
    # already zipped
    if is_zipfile(file_folder):
        logger.info(f"{file_folder} is already a zip, skipping zipping...")
        file_zipped = file_folder
        is_temp_zip_created = False

    # to be zipped
    else:
        logger.info(f"{file_folder} not already a zip, zipping it...")
        file_zipped = f"{file_folder}.zip"
        zip_file_folder(path=file_folder, path_zipped=file_zipped, compress=compress)

    # upload zipped file/folder to blob
    logger.info(f"Uploading zipped file: {file_zipped} to blob: {url}.")
    upload_file_to_blob(file=file_zipped, url=url, overwrite=overwrite)

    # delete temporary zip, if any was created
    if is_temp_zip_created:
        logger.info(f"Cleaning temporary zip: {file_zipped}...")
        os.remove(file_zipped)


def zip_upload_model_to_blob(model: str, overwrite: bool = False, compress: bool = True) -> None:
    """
    Upload a model to blob storage (and zip it beforehand if not already a zip).

    Parameters
    ----------
    model
        Path to model or zipped model to upload.
    overwrite
        Whether or not to overwrite if already existing on blob.
    compress
        Whether or not to compress if zipping.
    """
    model = model[:-1] if model.endswith("/") else model
    model_url = f"{PATH_MODELS_ON_BLOB}/{os.path.basename(model)}.zip"
    zip_upload_file_folder_to_blob(
        file_folder=model, url=model_url, overwrite=overwrite, compress=compress
    )


def zip_upload_data_to_blob(data: str, overwrite: bool = False, compress: bool = True) -> None:
    """
    Upload data (a folder or a zip) to blob storage (and zip it beforehand if not already a zip).

    Parameters
    ----------
    data
        Path to data folder or zipped data folder to upload.
    overwrite
        Whether or not to overwrite if already existing on blob.
    compress
        Whether or not to compress if zipping.
    """
    data = data[:-1] if data.endswith("/") else data
    data_url = f"{PATH_DATA_ON_BLOB}/{os.path.basename(data)}.zip"
    zip_upload_file_folder_to_blob(
        file_folder=data, url=data_url, overwrite=overwrite, compress=compress
    )


def zip_upload_predictions_to_blob(
    predictions: str, overwrite: bool = False, compress: bool = True
) -> None:
    """
    Upload predictions (original, predicted, names and counts) (a folder or a zip) to blob storage (and zip it beforehand if not already a zip).

    Parameters
    ----------
    predictions
        Path to predictions folder or zipped predictions folder to upload.
    overwrite
        Whether or not to overwrite if already existing on blob.
    compress
        Whether or not to compress if zipping.
    """
    predictions = predictions[:-1] if predictions.endswith("/") else predictions
    predictions_url = f"{PATH_PREDICTIONS_ON_BLOB}/{os.path.basename(predictions)}.zip"
    zip_upload_file_folder_to_blob(
        file_folder=predictions, url=predictions_url, overwrite=overwrite, compress=compress
    )


def download_image(url: str) -> np.ndarray:
    """
    Load an image from blob.

    Returns the 3 first channels, i.e. does not deal with transparency or hyperspectral images.
    """
    return np.array(Image.open(get_file_from_blob(url)))[:, :, :3]


def download_PIL_image(url: str) -> Any:
    """
    Load an image from blob.

    Returns the array
    """
    return Image.open(get_file_from_blob(url))


def upload_image(image: np.ndarray, url: str, overwrite: bool = True) -> None:
    """
    Upload a numpy array image to blob.

    Parameters
    ----------
    `image`
        The uint8 numpy [H, W, 3] image.\n
    `url`
        The blob url to upload the image to.\n
    `overwrite`
        Whether to overwrite the image on blob if already exists.\n

    Returns
    -------
    `None`
    """
    buffer = BytesIO()
    Image.fromarray(image).save(buffer, "PNG")
    buffer.seek(0)
    upload_file_to_blob(buffer, url=url, overwrite=overwrite)


def download_unzip_clean_zip(
    name: str, path_on_disk: str, path_on_blob: str, overwrite: bool = False
) -> None:
    """
    Check if need to download, unzip and clean the zip file.

    For instance
      - download, extract and clean ``name=model-final.pth.zip``.
      - model-final unzipped already there and overwirte is False. Don't do anything.
      - model-final unzipped not there, but zipped there. Unzip and clean.
    """
    # ensure path to folder exists
    Path(path_on_disk).mkdir(parents=True, exist_ok=True)

    # set-up main paths
    full_path_disk_zipped = f"{path_on_disk}/{name}"
    full_path_disk_unzipped = f"{path_on_disk}/{name.split('.zip')[0]}"
    full_path_blob = f"{path_on_blob}/{name}"

    # check if unzipped model/data (folder or file) already there
    if os.path.exists(full_path_disk_unzipped) and overwrite is False:
        logger.info(
            f"{full_path_disk_unzipped} already exists and overwite is set to False. nothing to prepare."
        )
        return None
    elif os.path.exists(full_path_disk_unzipped) and overwrite is True:
        logger.info(
            f"{full_path_disk_unzipped} already exists but overwite is set to True. Need to prepare."
        )
    else:
        logger.info(f"{full_path_disk_unzipped} does not already exist. Need to prepare.")

    # check if zipped model/data (folder or file) already there
    if os.path.exists(full_path_disk_zipped) and overwrite is False:
        logger.info(
            f"{full_path_disk_zipped} available and overwite is set to False. No need to download..."
        )
    else:
        if not os.path.exists(full_path_disk_zipped):
            # download and write the zipped model/data
            logger.info(f"{full_path_disk_zipped} not available. Downloading {full_path_blob}...")
        else:
            logger.info(
                f"{full_path_disk_zipped} available but overwite is set to True. Downloading {full_path_blob}..."
            )
        stream = get_file_from_blob(full_path_blob)
        with open(full_path_disk_zipped, "wb") as f:
            f.write(stream.read())

    # unzip the model/data
    logger.info(f"Unzipping {full_path_disk_zipped} to {path_on_disk}...")
    unzip_file_folder(path_zipped=full_path_disk_zipped, path=path_on_disk)

    # remove the zip
    logger.info(f"Cleaning {full_path_disk_zipped}...")
    os.remove(full_path_disk_zipped)


def download_unzip_clean_data(data_name: str, overwrite: bool = False) -> None:
    """Check if need to download, unzip and clean the data zipped folder."""
    # Append .zip to data_name to search on blob if not already appended
    data_name = data_name if data_name.split(".")[-1] == "zip" else data_name + ".zip"
    logger.info(f"Downloading data: {data_name}...")
    return download_unzip_clean_zip(
        name=data_name,
        path_on_disk=PATH_DATA_ON_DISK,
        path_on_blob=PATH_DATA_ON_BLOB,
        overwrite=overwrite,
    )


def download_unzip_clean_predictions(predictions_name: str, overwrite: bool = False) -> None:
    """Check if need to download, unzip and clean the data zipped folder."""
    # Append .zip to predictions_name to search on blob if not already appended
    predictions_name = (
        predictions_name if predictions_name.split(".")[-1] == "zip" else predictions_name + ".zip"
    )
    logger.info(f"Downloading predictions_name: {predictions_name}...")
    return download_unzip_clean_zip(
        name=predictions_name,
        path_on_disk=PATH_PREDICTIONS_ON_DISK,
        path_on_blob=PATH_PREDICTIONS_ON_BLOB,
        overwrite=overwrite,
    )


def download_unzip_clean_model(model_name: str, overwrite: bool = False) -> None:
    """Check if need to download, unzip and clean the model zip file."""
    # Append .zip to data_name to search on blob if not already appended
    model_name = model_name if model_name.split(".")[-1] == "zip" else model_name + ".zip"
    logger.info(f"Downloading model: {model_name}...")
    return download_unzip_clean_zip(
        name=model_name,
        path_on_disk=PATH_MODELS_ON_DISK,
        path_on_blob=PATH_MODELS_ON_BLOB,
        overwrite=overwrite,
    )


def remove_prefix(text: str, prefix: str) -> str:
    """Remove prefix from a string is exists."""
    if text.startswith(prefix):
        return text[len(prefix) :]
    return text


def list_files_on_blob(name_starts_with: str, return_urls: bool = False) -> List[str]:
    """
    List the file names starting with `name_starts_with` on Azure blob storage.

    Parameters
    ----------
    name_starts_with
        List the files which name starts with
    return_urls
        Whether to return the file name, or its complete url.
    """
    # create container client
    blob_service_client = get_blob_service_client()
    container_client = blob_service_client.get_container_client(CONTAINER)

    # list blobs
    blob_list = container_client.list_blobs(name_starts_with=name_starts_with)

    # return the blob names
    if return_urls:
        return [f"{ACCOUNT_URL}/{CONTAINER}/{blob.name}" for blob in blob_list]
    else:
        return [remove_prefix(text=blob.name, prefix=name_starts_with) for blob in blob_list]


def list_data_on_blob(return_urls: bool = False) -> List[str]:
    """List data on azure blob storage."""
    return list_files_on_blob(name_starts_with="data/", return_urls=return_urls)


def list_models_on_blob(return_urls: bool = False) -> List[str]:
    """List models on azure blob storage."""
    return list_files_on_blob(name_starts_with="models/", return_urls=return_urls)


def write_zip_upload_models_kpis(models_kpis: ModelsKPIs, overwrite: bool = True) -> None:
    """Write models KPIs to disk as MODELS_KPIS_NAME, zip it and upload it."""
    # write the updated models kpis to disk
    models_kpis_path = os.path.join(PATH_MODELS_ON_DISK, MODELS_KPIS_NAME)
    if overwrite or (not overwrite and not os.path.isfile(models_kpis_path)):
        logger.info(f"Writing models_kpis {models_kpis_path} to disk...")
        with open(models_kpis_path, "w") as f:
            f.write(models_kpis.json())

    # upload the updated models kpis to blob
    zip_upload_model_to_blob(models_kpis_path, overwrite=overwrite)


def download_load_models_kpis(overwrite: bool = True) -> ModelsKPIs:
    """Download models KPIs to disk and load and return it."""
    # download and extract
    models_kpis_path = os.path.join(PATH_MODELS_ON_DISK, MODELS_KPIS_NAME)
    download_unzip_clean_model(model_name=MODELS_KPIS_NAME, overwrite=overwrite)

    # read
    models_kpis: ModelsKPIs = ModelsKPIs(**json.load(open(models_kpis_path, "r")))

    return models_kpis


def delete_object_from_blob(object_name: str) -> None:
    """Delete an object from blob."""
    blob_name = os.path.join(object_name)
    blob_service_client = get_blob_service_client()
    blob_client = blob_service_client.get_blob_client(container=CONTAINER, blob=blob_name)
    try:
        blob_client.delete_blob()
    except ResourceNotFoundError as e:
        logger.info(f"Object: {blob_name} does not exist. Full stack: {e}.")


def get_base64_format(image_base64: str, sample_id: str) -> Any:
    """Read the image in base64 format and store it in blob storage."""
    image = str.encode(image_base64)
    with open("cfu_input_image.png", "wb") as fh:
        fh.write(base64.decodebytes(image))
    image = Image.open(BytesIO(base64.b64decode(image_base64)))
    channel_image = np.array(Image.open(BytesIO(base64.b64decode(image_base64))))[:, :, :3]
    
    image_original_url = f"{ACCOUNT_URL}/sample/Inputimage/{sample_id}.png"
    image_predicted_url = f"{ACCOUNT_URL}/sample/Outputimage/{sample_id}.png"
    
    upload_file_to_blob("cfu_input_image.png", image_original_url, True)

    nparr = np.fromstring(base64.b64decode(image_base64), np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # detect circles in the image
    circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1.5, 500)
    if circles is None:
        return False, image, channel_image, image_original_url, image_predicted_url
    else:
        return True, image, channel_image, image_original_url, image_predicted_url
