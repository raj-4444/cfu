"""Types module used in the project."""

import logging
from enum import Enum
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
import torch
from detectron2.structures.boxes import BoxMode
from detectron2.structures.instances import Instances
from lightgbm.sklearn import LGBMRegressor
from pydantic import BaseModel, Field

logging.getLogger(__name__)

# Detectron2 types
# ================


class Detectron2Annotation(BaseModel):
    """Detectron2Annotation data class."""

    bbox: List[Union[int, float]]
    bbox_mode: BoxMode
    category_id: int
    segmentation: List[List[Union[int, float]]]


class Detectron2DatasetElement(BaseModel):
    """Detectron2DatasetElement data class."""

    file_name: str
    height: int
    width: int
    image_id: str
    annotations: List[Detectron2Annotation]


# Model input and output formats, as depicted in https://detectron2.readthedocs.io/tutorials/models.html#model-input-format
ModelInputFormat = Dict[str, Union[torch.Tensor, int, str, Instances]]
ModelOutputFormatInference = Dict[str, Instances]

ModelInputsFormat = List[ModelInputFormat]
ModelOutputsFormatInference = List[ModelOutputFormatInference]
ModelOutputFormatTrain = Dict[str, torch.Tensor]  # scalar tensors for each loss

# Format of CFUEvaluator results
DatasetEvaluatorResults = Dict[str, Dict[str, float]]


# Custom types
# ============

# when unhencing the Detectron2DatasetElement with loaded original, labeled and predicted images
Detectron2DatasetEnhancedElement = Dict[
    str, Union[str, int, float, List[Detectron2Annotation], Instances, np.ndarray]
]
Detectron2DatasetEnhanced = List[Detectron2DatasetEnhancedElement]


class KPIs(BaseModel):
    """KPIs data class."""

    main: Dict[str, float]
    mae: Dict[str, float]
    mape: Dict[str, float]
    ratio: Dict[str, float]
    bbox: Dict[str, float]
    segm: Dict[str, float]


class Data(BaseModel):
    """Data data class."""

    folders: List[str]
    n_examples: int


class Quantile(BaseModel):
    """Quantile dataclass."""

    expected: float = Field(
        ..., title="Expected quantile.",
    )
    actual_train: Optional[float] = Field(
        None, title="Actual quantile as measured on the training set.",
    )
    actual_test: Optional[float] = Field(
        None, title="Actual quantile as measured on the testing set.",
    )


class ModelQuantile(BaseModel):
    """Quantile Model dataclass."""

    model: LGBMRegressor
    name: str
    log_y: bool
    eps: Optional[float]
    n_bins: int
    column_names: List[str]
    quantile: Quantile

    def predict(self, X: pd.DataFrame) -> pd.Series:
        """Predict the quantile value and handles 0 clipping and logs conversion if needed."""
        if not self.log_y:
            y_preds_quantile = pd.Series(
                self.model.predict(X).clip(min=0), name=f"predictions: {self.name}",
            )
        else:
            y_preds_quantile = pd.Series(
                (np.exp(self.model.predict(X)) + self.eps).clip(min=0),
                name=f"predictions: {self.name}",
            )
        return y_preds_quantile

    class Config:
        """Config of the ModelQuantile dataclass."""

        arbitrary_types_allowed = True


class Sharpness(BaseModel):
    """Sharpness dataclass."""

    mae: float
    mse: float


class ModelQuantilesInterval(BaseModel):
    """Quantiles Interval Model dataclass."""

    low: ModelQuantile
    high: ModelQuantile
    expected_interval: float
    actual_interval_train: float
    actual_interval_test: float
    calibration_train: float
    calibration_test: float
    sharpness_train: Sharpness
    sharpness_test: Sharpness

    class Config:
        """Config of the ModelQuantilesInterval dataclass."""

        arbitrary_types_allowed = True


class QuantilePrediction(BaseModel):
    """Quantile prediction dataclass."""

    quantile: float
    prediction: float


class ModelPrediction(BaseModel):
    """Model prediction dataclass."""

    score_threshold: float
    prediction: int


class CFUPredictorOutputFormat(BaseModel):
    """CFU Predictor output format dataclass."""

    instances: Instances
    model_prediction: ModelPrediction

    class Config:
        """Config of the CFUPredictorPIOutputFormat dataclass."""

        arbitrary_types_allowed = True


class CFUPredictorPIOutputFormat(CFUPredictorOutputFormat):
    """CFU Predictor output format dataclass."""

    quantiles_predictions: List[QuantilePrediction]

    class Config:
        """Config of the CFUPredictorPIOutputFormat dataclass."""

        arbitrary_types_allowed = True


class Model(BaseModel):
    """Model data class."""

    name: str
    datetime_finished: str
    backbone: str
    iteration: int
    available: bool
    kpis: KPIs
    quantiles: Optional[List[Quantile]] = None
    quantiles_calibration_test: Optional[float] = None
    quantiles_sharpness_test: Optional[Sharpness] = None


class ModelsKPIs(BaseModel):
    """Models KPIs dataclass."""

    data: Data
    models: List[Model]


class VIACircle(BaseModel):
    """VIA circle dataclass."""

    cx: int
    cy: int
    name: str
    r: int


class VIAEllipse(BaseModel):
    """VIA ellipse dataclass."""

    cx: int
    cy: int
    name: str
    rx: int
    ry: int
    theta: float


class VIAPolygon(BaseModel):
    """VIA polygon dataclass."""

    all_points_x: List[float]
    all_points_y: List[float]
    name: str


class VIARegion(BaseModel):
    """VIA Regions Format dataclass."""

    region_attributes: Dict[str, Any]
    shape_attributes: Union[VIACircle, VIAEllipse, VIAPolygon]


class DatasetVIAFormat(BaseModel):
    """Dataset VIA Format dataclass."""

    file_attributes: Optional[Dict[str, Any]]
    filename: str
    regions: List[VIARegion]
    size: int


# detectron cfg types
# ===================


class Backbone(Enum):
    """Enum Backbone options for detectron2 config."""

    R50_FPN = 1
    R101_FPN = 2
    X101_FPN = 3


class Device(Enum):
    """Enum Device options for detectron2 config."""

    CPU = 1
    GPU = 2


# Prediction models types
# =======================


class HPSpace(Enum):
    """Enum Hyper Parameters spaces options."""

    NARROW = 1
    WIDE = 2
