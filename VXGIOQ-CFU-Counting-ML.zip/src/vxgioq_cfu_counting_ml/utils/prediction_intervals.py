"""Module gathering utilities to compute the CFU counts prediction intervals."""

import logging
import multiprocessing
import os
from enum import Enum
from itertools import zip_longest
from typing import Any, List, Optional, Tuple

import lightgbm as lgb
import numpy as np
import pandas as pd
from detectron2.data.transforms.augmentation import Augmentation
from detectron2.engine import hooks
from scipy.stats import randint as sp_randint
from scipy.stats import uniform as sp_uniform
from sklearn.model_selection import RandomizedSearchCV
from tqdm.auto import tqdm
from verstack.stratified_continuous_split import scsplit

from vxgioq_cfu_counting_ml.training.trainer import CFUTrainer
from vxgioq_cfu_counting_ml.utils.loader import load_model
from vxgioq_cfu_counting_ml.utils.metrics import mae, mse
from vxgioq_cfu_counting_ml.utils.types import HPSpace

logger = logging.getLogger(__name__)


HP_SPACE_NARROW = {
    "num_leaves": sp_randint(30, 50),
    "min_child_samples": sp_randint(100, 400),
    "min_child_weight": [1e-5, 1e-4],
    "subsample": sp_uniform(loc=0.1, scale=0.5),
    "colsample_bytree": sp_uniform(loc=0.2, scale=0.2),
    "reg_alpha": [0, 1e-5, 1e-1],
    "reg_lambda": [0, 1e-5, 1e-1],
}


# many hyperparameters fine-tuning
HP_SPACE_WIDE = {
    "n_estimators": sp_randint(50, 200),  # 137, 154 (default: 100)
    "num_leaves": sp_randint(10, 70),  # 57, 26 (default: 31)
    "min_child_samples": sp_randint(20, 500),  # 370, 106 (default: 20)
    "min_child_weight": [1e-6, 1e-5, 1e-4, 1e-3],  # 1e-5, 1e-4 (default: 1e-3)
    "min_split_gain": sp_uniform(loc=0.0, scale=0.1),  # 0.001, 0.05 (default: 0.0)
    "subsample": sp_uniform(loc=0.1, scale=0.6),  # 0.4, 0.2  (default: 1)
    "subsample_freq": sp_randint(0, 100),  # 38, 0 (default: 0)
    "subsample_for_bin": [50000, 100000, 200000],  # 100000, 100000 (default: 200000)
    "colsample_bytree": sp_uniform(loc=0.1, scale=0.9),  # 0.2, 0.4 (default: 1)
    "reg_alpha": [0, 1e-5, 1e-3, 1e-1, 1],  # 0, 0.1 (default: 0)
    "reg_lambda": [0, 1e-5, 1e-3, 1e-1, 1],  # 0.1, 1e-5 (default: 0)
}


def pad_arrays(v: List[List[Any]]) -> np.ndarray:
    """Pad lists with `fillvalue` so all lists have the same length and convert to array."""
    return np.array(list(zip_longest(*v, fillvalue=0))).T


class BinningOption(Enum):
    """Enum Binning Options."""

    FIXED = 1
    ADAPTATIVE_QUANTILE = 2


class DistributionFunctionType(Enum):
    """Enum Distribution Functions Type."""

    PDF = 1
    CDF = 2


def scores_to_distributions(
    scores: List[np.ndarray],
    n_bins: int = 10,
    binning_option: BinningOption = BinningOption.FIXED,
    distribution_function_type: DistributionFunctionType = DistributionFunctionType.CDF,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Convert the padded scores [0, 1] of each example of the dataset to counts CDFs (Cumulative Distribution Functions) or PDFs (Probability Density Functions).

    Parameters
    ----------
    scores
        Each element of is an array of scores for a given example.
    n_bins
        The number of bins to pour the scores in.
    binning_option
        Which binning option to use.
    distribution_function_type
        The distribution function to return binned scores into. PDF or CDF.

    Returns
    -------
    (CDFs or PDFs of all examples' scores, Bins thresholds)

    Examples
    --------
    PDF with fixed bins

    >>> n_bins = 3
    >>> scores = [
    ...     np.array([0, 0.1, 0.15, 0.7, 0.99, 0.99, 0.999, 1]),
    ...     np.array([0.01, 0.01, 0.02, 0.03])
    ... ]
    >>> pdf_scores_fixed, _ = scores_to_distributions(
    ...     scores=scores,
    ...     n_bins=n_bins,
    ...     binning_option=BinningOption.FIXED,
    ...     distribution_function_type=DistributionFunctionType.PDF
    ... )
    >>> print(pdf_scores_fixed)
       count b [1.0; .7]  count b (.7; .3]  count b (.3; .0]
    0                  5                 0                 3
    1                  0                 0                 4

    CDF with fixed bins

    >>> cdf_scores_fixed, _ = scores_to_distributions(
    ...     scores=scores,
    ...     n_bins=n_bins,
    ...     binning_option=BinningOption.FIXED,
    ...     distribution_function_type=DistributionFunctionType.CDF
    ... )
    >>> print(cdf_scores_fixed)
       count b >= .7  count b >= .3  count b >= .0
    0              5              5              8
    1              0              0              4

    PDF with adaptative (quantile) bins

    >>> pdf_scores_adapt, _ = scores_to_distributions(
    ...     scores=scores,
    ...     n_bins=n_bins,
    ...     binning_option=BinningOption.ADAPTATIVE_QUANTILE,
    ...     distribution_function_type=DistributionFunctionType.PDF
    ... )
    >>> print(pdf_scores_adapt)
       count q [1.0; .7]  count q (.7; .3]  count q (.3; .0]
    0                  4                 1                 3
    1                  2                 2                 0

    CDF with adaptative (quantile) bins

    >>> cdf_scores_adapt, bins_adapt = scores_to_distributions(
    ...     scores=scores,
    ...     n_bins=n_bins,
    ...     binning_option=BinningOption.ADAPTATIVE_QUANTILE,
    ...     distribution_function_type=DistributionFunctionType.CDF
    ... )
    >>> print(cdf_scores_adapt)
       count q >= .7  count q >= .3  count q >= .0
    0              4              5              8
    1              2              4              4

    >>> print(bins_adapt)
       bin q 1.0  bin q .7  bin q .3  bin q .0
    0       1.00      0.99  0.333333      0.00
    1       0.03      0.02  0.010000      0.01
    """
    # compute bins
    if binning_option == BinningOption.FIXED:
        bins = [np.arange(n_bins + 1) / n_bins for _ in range(len(scores))]
        step = bins[0][1] - bins[0][0]
        pdf_column_names = [
            "count b "
            + "("
            + f"{b+step:.{len(str(n_bins))}f}".lstrip("0")
            + "; "
            + f"{b:.{len(str(n_bins))}f}".lstrip("0")
            + "]"
            for b in bins[0]
        ][::-1][1:]
        pdf_column_names[0] = pdf_column_names[0].replace("(", "[")
        cdf_column_names = [
            "count b >= " + f"{b:.{len(str(n_bins))}f}".lstrip("0") for b in bins[0]
        ][::-1][1:]
        bins_column_names = ["bin b " + f"{b:.{len(str(n_bins))}f}".lstrip("0") for b in bins[0]][
            ::-1
        ]

    else:  # BinningOption.ADAPTATIVE_QUANTILE
        quantiles = np.arange(n_bins + 1) / n_bins
        step = quantiles[1] - quantiles[0]
        bins = [
            np.sort(np.quantile(a=np.sort(score if len(score) > 0 else np.array([0])), q=quantiles))
            for score in scores
        ]
        pdf_column_names = [
            "count q "
            + "("
            + f"{q+step:.{len(str(n_bins))}f}".lstrip("0")
            + "; "
            + f"{q:.{len(str(n_bins))}f}".lstrip("0")
            + "]"
            for q in quantiles
        ][::-1][1:]
        pdf_column_names[0] = pdf_column_names[0].replace("(", "[")
        cdf_column_names = [
            "count q >= " + f"{quantile:.{len(str(n_bins))}f}".lstrip("0") for quantile in quantiles
        ][::-1][1:]
        bins_column_names = [
            "bin q " + f"{quantile:.{len(str(n_bins))}f}".lstrip("0") for quantile in quantiles
        ][::-1]

    # bin scores
    pdfs = pd.DataFrame(
        np.concatenate(
            [
                np.histogram(np.sort(score), bins=b)[0].reshape(1, -1)
                for score, b in zip(scores, bins)
            ],
            axis=0,
        )[..., ::-1],
        columns=cdf_column_names
        if distribution_function_type == DistributionFunctionType.CDF
        else pdf_column_names,
    )

    # convert to cdf if needed
    return (
        pdfs.cumsum(axis=1) if distribution_function_type == DistributionFunctionType.CDF else pdfs,
        pd.DataFrame(np.array(bins)[..., ::-1], columns=bins_column_names),
    )


class DataType(Enum):
    """Enum data types options."""

    TRAIN = 1
    TEST = 2


def generate_pi_scores(
    model_name: str,
    data_type: DataType,
    dataset_name: str = "dataset_test",
    n_examples: int = 2,
    augmentations: Optional[List[Augmentation]] = None,
) -> Tuple[List[np.ndarray], List[int]]:
    """
    Generate predictions scores and actual ground truth counts in a preliminary step to generate dataset for Prediction Interval models.

    Notes
    -----
    Make sure to register the detectron2 dataset you plan on using beforehand.
    If no augmentations are specified, the test augmentations (milder than the train ones) will be used no matter the data_type.
    """
    # load predictor
    predictor, cfg = load_model(
        model_name=model_name, score_thresh_test=0.0, filter_empty_annotations=False,
    )

    # load trainer for data augmentation generator
    trainer = CFUTrainer(cfg)
    trainer.resume_or_load(resume=True)
    if cfg.TEST.AUG.ENABLED:
        trainer.register_hooks(
            [hooks.EvalHook(0, lambda: trainer.test_with_TTA(cfg, trainer.model))]
        )
    if data_type == DataType.TRAIN:
        data_loader = trainer.build_train_loader(
            cfg, augmentations=augmentations if augmentations else CFUTrainer.augmentations_test,
        )
        n_imgs_per_batch: int = data_loader.batch_size  # type: ignore
    else:
        data_loader = trainer.build_test_loader(
            cfg,
            dataset_name=dataset_name,
            augmentations=augmentations if augmentations else CFUTrainer.augmentations_test,
        )
        n_imgs_per_batch = 1

    data_iter = iter(data_loader)

    # Loop on generated batches of augmented images
    scores = []
    counts_gt = []
    image_i = 0
    for _ in tqdm(np.arange((n_examples // n_imgs_per_batch) + 1)):
        # generate a new batch of augmented images
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(data_loader)
            batch = next(data_iter)

        # loop through the generated images and compute their predictions scores
        for dish in batch:
            image_i += 1
            logger.info(f"image_i: {image_i}")
            if image_i > n_examples:
                break
            prediction = predictor(dish["image"].numpy().T)["instances"].to("cpu")
            scores.append(prediction.scores.tolist())
            counts_gt.append(len(dish["instances"]))

    return scores, counts_gt


def scores_to_compiled_cdfs(
    scores: List[np.ndarray], n_bins: int, all_features: bool = False
) -> pd.DataFrame:
    """
    Convert the scores to fixed and adaptative CDFs and binning.

    Parameters
    ----------
    scores
        The DL scores.
    n_bins
        The number of bins to generate the distribution functions.
    all_features
        If True, generates the fixed and adaptative CDFs and the adaptative quantile values,
        otherwise only return the fixed CDFs (which is the only thing needed to build quantile models upon it).

    Returns
    -------
    The CDFs (fixed bins only if all_features is False,
        else also combines the adaptative CDFs and their corresponding quantiles).
    """
    # generate counts CDFs with fixed bins
    cdfs_fixed, _ = scores_to_distributions(
        scores=scores,
        n_bins=n_bins,
        binning_option=BinningOption.FIXED,
        distribution_function_type=DistributionFunctionType.CDF,
    )
    if not all_features:
        return cdfs_fixed

    # generate counts CDFs with quantile (adaptative) bins
    cdfs_adaptative, bins_adaptative = scores_to_distributions(
        scores=scores,
        n_bins=n_bins,
        binning_option=BinningOption.ADAPTATIVE_QUANTILE,
        distribution_function_type=DistributionFunctionType.CDF,
    )

    return pd.concat([cdfs_fixed, cdfs_adaptative, bins_adaptative], axis=1)


def generate_pi_dataset(
    model_name: str,
    data_type: DataType,
    dataset_name: str = "dataset_test",
    n_examples: int = 2,
    n_bins: int = 100,
    augmentations: Optional[List[Augmentation]] = None,
) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Generate a dataset (X, y) for PI (prediction interval) models.

    The design matrix X is made of CDFs and optionally corresponding adaptative quantile bins values
    and the target vector is made of the actual counts.

    Parameters
    ----------
    model_name
        The instance segmentation model to use to generate predictions scores on generated examples.
    data_type
        Whether to generate training or testing examples.
    n_examples
        The number of examples to generate.
    n_bins
        The number of bins used to convert the scores to CDFs.
    augmentations
        The augmentations to use when generating examples.
        If not specified, will use the defautl CFUTrainer test augmentations, both for training and testing data types.

    Returns
    -------
    (X, y)
    """
    # generate pi scores
    scores, counts_gt = generate_pi_scores(
        model_name=model_name,
        data_type=data_type,
        dataset_name=dataset_name,
        n_examples=n_examples,
        augmentations=augmentations,
    )

    return (
        scores_to_compiled_cdfs(scores=scores, n_bins=n_bins, all_features=False),
        pd.Series(data=counts_gt, name="count"),
    )


# PI Training
# ===========


def learning_rate_010_decay_power_099(current_iter: int) -> float:
    """Compute learning rate with base 0.1 and 0.99 decay."""
    base_learning_rate = 0.1
    lr: float = base_learning_rate * float(np.power(0.99, current_iter))
    return lr if lr > 1e-3 else 1e-3


def learning_rate_010_decay_power_0995(current_iter: int) -> float:
    """Compute learning rate with base 0.1 and 0.995 decay."""
    base_learning_rate = 0.1
    lr: float = base_learning_rate * float(np.power(0.995, current_iter))
    return lr if lr > 1e-3 else 1e-3


def learning_rate_005_decay_power_099(current_iter: int) -> float:
    """Compute learning rate with base 0.05 and 0.99 decay."""
    base_learning_rate = 0.05
    lr: float = base_learning_rate * float(np.power(0.99, current_iter))
    return lr if lr > 1e-3 else 1e-3


def train_quantile_regressor(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    quantile: float = 0.5,
    n_hp_points: int = 5,
    hp_space_size: HPSpace = HPSpace.NARROW,
    train_size: float = 0.7,
    cv: int = 3,
    n_cpus: Optional[int] = None,
) -> lgb.LGBMRegressor:
    """
    Train a quantile model with HyperParameters randomized fine-tuning.

    Parameters
    ----------
    quantile
        the quantile to optimze the model on.
    n_hp_points
        the number of HyperParameters points to be tested.
    hp_space_size
        The widness/Narrowness of the HP space to explore.
    train_size
        The ratio of training data when splitting X_train and y_train into train and validation sets.
    cv
        Number of cross-validation folds to split the train data into for HP finetuning.
    n_cpus
        The number of CPUs one wishes to allocate to the training. If not specified, will try to fetch the number of available CPUs - 1.
    """
    # choose the number of processes to spawn for the RandomSearch and the number of threads per process
    if not n_cpus:
        n_cpus = max(
            (
                multiprocessing.cpu_count() - 1
                if not os.environ.get("SLURM_CPUS_ON_NODE")
                else int(os.environ["SLURM_CPUS_ON_NODE"]) - 1
            ),
            1,  # in case only 1 CPU is available, we use that one
        )
    n_procs = max(n_cpus // 2, 1)
    n_threads = n_cpus // n_procs
    logger.info(
        f"Running HP search on {n_procs} processes with each process fitting a Regressor with {n_threads} threads."
    )

    # choose hp space
    if hp_space_size == HPSpace.NARROW:
        logger.info("Using narrow HP space...")
        hp_space = HP_SPACE_NARROW
    else:  # Wide HP space
        logger.info("Using wide HP space...")
        hp_space = HP_SPACE_WIDE

    # split training set into training and validation sets
    logger.info(
        f"Stratified split (train_size: {train_size}) of trainset into train and validation sets for hyper-parameters fine-tuning."
    )
    X_train, X_val, y_train, y_val = scsplit(
        X_train, y_train, stratify=y_train, train_size=train_size
    )

    # set-up the regressor fit parameters
    fit_params = {
        "early_stopping_rounds": 30,
        "eval_metric": "quantile",
        "eval_set": [(X_val, y_val)],
        "eval_names": ["valid"],
        "callbacks": [lgb.reset_parameter(learning_rate=learning_rate_010_decay_power_099)],
        "verbose": 100,
    }

    # set-up regressor
    reg = lgb.LGBMRegressor(
        objective="quantile",
        alpha=quantile,
        max_depth=-1,
        random_state=314,
        silent=True,
        metric=["quantile", "mae"],
        n_jobs=n_threads,
        n_estimators=5000,
    )

    # set-up randomized HP search
    rs = RandomizedSearchCV(
        estimator=reg,
        param_distributions=hp_space,
        n_iter=n_hp_points,
        cv=cv,
        refit=True,
        random_state=314,
        verbose=True,
        n_jobs=n_procs,
    )

    # train with HP fine-tuning
    rs.fit(X_train, y_train, **fit_params)
    logger.info(f"Best score reached: {rs.best_score_} with params: {rs.best_params_} ")

    logger.info("Valid+-Std     Train  :   Parameters")
    for i in np.argsort(rs.cv_results_["mean_test_score"])[-3:]:
        logger.info(
            "{1:.3f}+-{2:.3f}   :  {0}".format(
                rs.cv_results_["params"][i],
                rs.cv_results_["mean_test_score"][i],
                rs.cv_results_["std_test_score"][i],
            )
        )

    # retrain on full data with best model's parameters
    reg_final = lgb.LGBMRegressor(**rs.best_estimator_.get_params())

    # train the final model with slower learning rate decayer
    fit_params["callbacks"] = [
        lgb.reset_parameter(learning_rate=learning_rate_010_decay_power_0995)
    ]
    reg_final.fit(
        pd.concat([X_train, X_val], axis=0), pd.concat([y_train, y_val], axis=0), **fit_params,
    )

    return reg_final


def verify_quantiles_predictions(
    y: pd.Series,
    y_preds_low: pd.Series,
    y_preds_high: pd.Series,
    quantile_low: float,
    quantile_high: float,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Verify quantiles predictions (Compute Calibration and shaprness metrics).

    Examples
    --------
    >>> y = pd.Series([1, 2, 3])
    >>> y_preds_low = pd.Series([0, 1, 4])
    >>> y_preds_high = pd.Series([2, 3, 2])
    >>> quantile_low = 0.3
    >>> quantile_high = 0.7
    >>> calibration, sharpness = verify_quantiles_predictions(
    ...     y=y,
    ...     y_preds_low=y_preds_low,
    ...     y_preds_high=y_preds_high,
    ...     quantile_low=quantile_low,
    ...     quantile_high=quantile_high
    ... )
    >>> print(calibration)
                              expected  actual
    0.3 quantile                     1       1
    0.7 quantile                     2       2
    40 % prediction interval         1       1
    >>> print(sharpness)
         sharpness
    MAE        2.0
    MSE        4.0
    """
    if len(y) != len(y_preds_low) or len(y) != len(y_preds_high):
        raise ValueError("Lengths of y, y_preds_low and y_preds_high must match.")
    n_exples = len(y)
    expected_low = int(np.rint(quantile_low * n_exples))
    expected_high = int(np.rint(quantile_high * n_exples))
    expected_interval = int(np.rint(quantile_high * n_exples - quantile_low * n_exples))

    actual_low = int((y.to_numpy() < np.rint(y_preds_low.to_numpy()).astype(np.uint16)).sum())
    actual_high = int((y.to_numpy() < np.rint(y_preds_high.to_numpy()).astype(np.uint16)).sum())
    actual_interval = actual_high - actual_low
    return (
        pd.DataFrame(
            data={
                "expected": [expected_low, expected_high, expected_interval],
                "actual": [actual_low, actual_high, actual_interval],
            },
            index=[
                f"{quantile_low} quantile",
                f"{quantile_high} quantile",
                f"{int((quantile_high - quantile_low) * 100)} % prediction interval",
            ],
        ),
        pd.DataFrame(
            data={"sharpness": [mae(y_preds_high, y_preds_low), mse(y_preds_high, y_preds_low)]},
            index=["MAE", "MSE"],
        ),
    )
