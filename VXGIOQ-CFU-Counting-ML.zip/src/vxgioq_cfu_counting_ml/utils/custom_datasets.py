"""Dataset functions to be registered as Detectron2.DatasetCatalog and MetadataCatalog."""

import logging
import os
from typing import Any, Dict, List

import joblib
import numpy as np
from skimage.measure import block_reduce, find_contours

from vxgioq_cfu_counting_ml.utils.azure import DATASET_DETECTRON2_NAME
from vxgioq_cfu_counting_ml.utils.types import Detectron2DatasetElement

logger = logging.getLogger(__name__)


def _downsample_polygon_edges(polygon: np.ndarray, max_edges: int = 50) -> np.ndarray:
    """
    Reduce the number of edges of a polygon.

    Polygons depicting instances on an image can be made of an arbitrary number of edges. This can,
    in turn, lead to very slow processing times and high RAM usage, be it during
    training of visualization.
    Hence, this function seeks to downsample the number of edges defined in a polygon.

    Parameters
    ----------
    polygon
        An ndarray of shape (n, 2), consisting of n (x, y) coordinates along the contour.
    max_edges
        Half of the maximum number of edges of the polygon. Downsampling is only be applied when the
        number of edges is at least twice the max_edges.

    Returns
    -------
    The possibly downsampled polygon.
    """
    n_edges = len(polygon)
    if n_edges // (max_edges / 2) > 1:
        downsampling_factor = n_edges // max_edges
        logger.debug(f"Downsampling by {downsampling_factor} the polygon with {n_edges} edges...")
        # downsampling
        polygon = block_reduce(
            polygon, block_size=(downsampling_factor, 1), func=np.mean, cval=np.mean(polygon),
        )[
            :-1, :
        ]  # The last element of the downsampling is often completely off so excluded
    return polygon


def mask_2_polygon(mask: np.ndarray, max_edges: int = 51) -> np.ndarray:
    """
    Convert a binary mask to a polygon and optionally downsamples the number of polygon coordinates.

    Parameters
    ----------
    mask
        A 2-D boolean numpy array where the object pixels are equal to True.
    max_edges
        Half of the maximum number of edges of the polygon. Downsampling is only be applied when the
        number of edges is at least twice the max_edges.

    Returns
    -------
    The (possibly downsampled) polygon, i.e. An ndarray of shape (n, 2), consisting of n (height, width) coordinates along the contour in an image coordinates system (i.e. starting on top left).
    """
    contour: np.ndarray = find_contours(
        mask, level=0.0, fully_connected="high", positive_orientation="high"
    )[0]

    contour_downsampled = _downsample_polygon_edges(polygon=contour, max_edges=max_edges)
    return contour_downsampled


def func_dataset(folder: str) -> List[Dict[str, Any]]:
    """
    Load a detectron2 compatible dataset folder into detectron2 datasets.

    The detectron2 datasets format is depicted at: https://detectron2.readthedocs.io/tutorials/datasets.html.
    """
    datasets: List[Detectron2DatasetElement] = joblib.load(
        os.path.join(folder, DATASET_DETECTRON2_NAME)
    )

    return [dataset.dict() for dataset in datasets]
