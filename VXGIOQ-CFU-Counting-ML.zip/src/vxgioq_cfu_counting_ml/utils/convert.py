"""Converting tools module."""

import copy
import logging
import os
import shutil
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Dict, List, Optional, Tuple, Union

import cv2
import fitz
import numpy as np
import pandas as pd
from detectron2.config.config import CfgNode
from detectron2.data.detection_utils import convert_image_to_rgb
from detectron2.engine import DefaultPredictor
from detectron2.utils.visualizer import Visualizer
from tqdm.auto import tqdm

from vxgioq_cfu_counting_ml.utils.conf import delete_folders
from vxgioq_cfu_counting_ml.utils.predictor import CFUPredictor
from vxgioq_cfu_counting_ml.utils.types import (
    Detectron2DatasetElement,
    Detectron2DatasetEnhanced,
    Detectron2DatasetEnhancedElement,
    ModelInputsFormat,
    ModelsKPIs,
)

logger = logging.getLogger(__name__)

METADATA_ELEMENTS = [
    ("Count", int),
    ("Dilution", float),
    ("Sensitivity", int),
    ("Parameters", str),
    ("Date Time", str),
    ("Area (%)", float),
    (
        "Operator name/Validated by",
        str,
    ),  # operator name and validated by can be found interchangeably
    ("Sample N°", int),
    ("CFU/mL", float),
    ("Comment", str),
    ("V (mL)", float),
    ("CFU Prorata", int),
]


def enhance_detectron2_dataset(
    dataset: List[Detectron2DatasetElement], predictor: Optional[CFUPredictor] = None
) -> Detectron2DatasetEnhanced:
    """
    Enhance detectron2 dataset with (original, labeled and predicted) images and predictions instances.

    Predicted images are only computed if a predictor is given.
    """
    dataset = copy.deepcopy(dataset)
    dataset_enhanced: Detectron2DatasetEnhanced = []
    for dataset_element in tqdm(dataset):
        # Load original image (in RGB)
        image_original = cv2.imread(dataset_element.file_name)[:, :, ::-1]

        # compute labeled image (Visualizer takes an RGB and returns an RGB)
        image_labeled = (
            Visualizer(image_original).draw_dataset_dict(dataset_element.dict()).get_image()
        )

        # keep track of computed images
        dataset_element_enhanced: Detectron2DatasetEnhancedElement = {
            **dataset_element.dict(),
            "image_original": image_original,
            "image_labeled": image_labeled,
            "n_cfus_labeled": len(dataset_element.annotations),
        }

        # compute predictions (Predictor takes BGR, Visualizer takes RGB and returns RGB)
        if predictor:
            prediction = predictor.predict_quantiles([image_original[:, :, ::-1]])[
                0
            ]  # format is H, W, C, with C as BGR (documented at https://detectron2.readthedocs.io/tutorials/models.html#model-output-format)
            v = Visualizer(image_original)
            out = v.draw_instance_predictions(prediction.instances)
            image_predicted = out.get_image()
            dataset_element_enhanced["image_predicted"] = image_predicted
            dataset_element_enhanced["n_cfus_predicted"] = prediction.model_prediction.prediction
            dataset_element_enhanced["pi_interval"] = (
                prediction.quantiles_predictions[1].quantile
                - prediction.quantiles_predictions[0].quantile
            )
            dataset_element_enhanced["n_cfus_pi_low"] = prediction.quantiles_predictions[
                0
            ].prediction
            dataset_element_enhanced["n_cfus_pi_high"] = prediction.quantiles_predictions[
                1
            ].prediction

        dataset_enhanced.append(dataset_element_enhanced)

    return dataset_enhanced


def batch_to_dataset_enhanced(
    batch: ModelInputsFormat, cfg: Optional[CfgNode] = None
) -> Detectron2DatasetEnhanced:
    """
    Convert a batch of detectron2 Trainer training/test data to the enhanced datasets format.

    Batches don't contain information about the predictions yet,
    so only original and labeled images are available.
    """
    batch = copy.deepcopy(batch)
    dataset_enhanced: Detectron2DatasetEnhanced = []
    for model_input in batch:
        # Get original image: Read image to RGB (Pytorch tensor is in (C, H, W) format in BGR)
        image_original = model_input["image"].permute(1, 2, 0).cpu().detach().numpy()  # type: ignore
        image_original = convert_image_to_rgb(image_original, cfg.INPUT.FORMAT if cfg else "BGR")

        # compute labeled image
        visualizer = Visualizer(image_original)
        target_fields = model_input["instances"].get_fields()  # type: ignore
        image_labeled = visualizer.overlay_instances(
            labels=None,
            boxes=target_fields.get("gt_boxes", None),
            masks=target_fields.get("gt_masks", None),
            keypoints=target_fields.get("gt_keypoints", None),
        ).get_image()
        dataset_enhanced_element: Detectron2DatasetEnhancedElement = {
            "file_name": "Batch example",
            "n_cfus_labeled": len(model_input["instances"]),  # type: ignore
            "image_original": cv2.imread(model_input["file_name"])[:, :, ::-1],
            "image_labeled": image_labeled,
        }
        dataset_enhanced.append(dataset_enhanced_element)

    return dataset_enhanced


def image_to_dataset_enhanced(
    image_original: np.ndarray, predictor: DefaultPredictor
) -> Detectron2DatasetEnhanced:
    """Convert an original image to an unhanced dataset dict with predicted image."""
    datasetet_enhanced: Detectron2DatasetEnhanced = []

    # compute predictions
    outputs = predictor(
        image_original[:, :, ::-1]
    )  # format is H, W, C, with C as BGR (documented at https://detectron2.readthedocs.io/tutorials/models.html#model-output-format)
    v = Visualizer(image_original)
    out = v.draw_instance_predictions(outputs["instances"].to("cpu"))
    image_predicted = out.get_image()

    dataset_enhanced_element: Detectron2DatasetEnhancedElement = {
        "file_name": "Uploaded image",
        "image_original": image_original,
        "image_predicted": image_predicted,
        "n_cfus_predicted": len(outputs["instances"].to("cpu")),
    }

    datasetet_enhanced.append(dataset_enhanced_element)
    return datasetet_enhanced


def paintbrush_to_gsk_mask(original: str, destination: str) -> None:
    """Convert a GSK image that was edited with paintbrush back to the gsk masks format."""
    # load image
    image_original = cv2.imread(original)

    # convert image
    image_converted = np.ones(image_original.shape, dtype=image_original.dtype) * 255
    image_converted[:, :, 0][image_original[:, :, 0] == 26] = 33
    image_converted[:, :, 1][image_original[:, :, 0] == 26] = 255
    image_converted[:, :, 2][image_original[:, :, 0] == 26] = 0

    # save image
    cv2.imwrite(destination, image_converted)


def _extract_metadata_element(text: str, element_key: str) -> str:
    """Extract a metadata element from the scan 4000 pdf report."""
    return text.split(f"{element_key} :\n")[1].split("\n")[0]


def _extract_metadata_elements(
    text: str, metadata_elements: List[Tuple[str, type]]
) -> Dict[str, Union[str, int, float]]:
    """Extract the metadata elements from the scan 4000 pdf report."""
    metadata = {}
    for element_key, element_type in metadata_elements:
        if element_type is float:
            element_value = element_type(
                _extract_metadata_element(text, element_key).replace(",", ".")
            )
        elif element_type is str:
            if element_key == "Operator name/Validated by":
                for sub_element_key in element_key.split("/"):
                    try:
                        element_value = element_type(
                            _extract_metadata_element(text, sub_element_key)
                        ).split(" -- �")[0]
                    except IndexError:
                        continue
                    break
            else:
                element_value = element_type(_extract_metadata_element(text, element_key)).split(
                    " -- �"
                )[0]
        else:
            element_value = element_type(_extract_metadata_element(text, element_key))

        metadata[element_key] = element_value

    return metadata


def extract_metadata_from_scan4000_report(path_pdf: str) -> pd.DataFrame:
    """Extract the petri dishes metadata from Scan4000 interscience pdf report."""
    doc = fitz.open(path_pdf)
    metadata: Dict[str, List[Union[str, int, float]]] = {}
    for page in doc:
        _metadata = _extract_metadata_elements(
            text=page.getText(), metadata_elements=METADATA_ELEMENTS
        )
        for _meta_key, _meta_value in _metadata.items():
            if metadata.get(_meta_key, None):
                metadata[_meta_key].append(_meta_value)
            else:
                metadata[_meta_key] = [_meta_value]
    return pd.DataFrame(metadata)


def extract_png_from_scan4000_report(
    path_pdf: str, image_type: str = "original"
) -> List[np.ndarray]:
    """
    Extract the original or predicted petri dish PNG images from Scan4000 interscience pdf report.

    Parameters
    ----------
    path_pdf
        The path to the pdf
    image_type
        The image type to extract. One of ["original", "predicted"]
    """
    if image_type not in ["original", "predicted"]:
        raise ValueError(f"image_type: {image_type} not in ['original', 'predicted']")
    modulo = 0 if image_type == "original" else 2  # trick to get the image position

    doc = fitz.open(path_pdf)
    images = []
    for i in range(len(doc)):
        for img in doc.getPageImageList(i):
            xref = img[0]
            if (xref - 1) % 9 == modulo:
                pix = fitz.Pixmap(doc, xref)
                if pix.n >= 5:  # CMYK: convert to RGB first
                    pix = fitz.Pixmap(fitz.csRGB, pix)

                # convert image to numpy (first need to write it unfortunatelly)
                with NamedTemporaryFile() as tmpfile:
                    pix.writePNG(tmpfile.name)
                    image = cv2.imread(tmpfile.name)[:, :, :3][:, :, ::-1]
                    images.append(image)
                pix = None
    return images


def extract_all_from_scan4000_report(
    path_pdf: str, path_extracted_images: str, image_type: str = "original"
) -> pd.DataFrame:
    """Extract the petri dishes metadata and original/predicted PNGs from Scan4000 interscience pdf report."""
    # create extracted images path if needed
    Path(path_extracted_images).mkdir(parents=True, exist_ok=True)

    # extract metadata
    data = extract_metadata_from_scan4000_report(path_pdf)

    # extract images, write them and update metadato with write location
    pdf_name = os.path.basename(path_pdf).split(".")[0]
    paths_images = []
    data["pdf"] = pdf_name
    for image, sample_nb in zip(
        extract_png_from_scan4000_report(path_pdf, image_type), data["Sample N°"].to_list()
    ):
        path_image = os.path.join(
            path_extracted_images, f"report-{pdf_name}__sample-{sample_nb}.png"
        )
        cv2.imwrite(filename=path_image, img=image[:, :, ::-1])
        paths_images.append(path_image)
    data["image"] = paths_images

    return data


def load_scan4000_excel(filename: str) -> pd.DataFrame:
    """Load the excel file with the scan4000 and operators counts on the previous POC."""
    # get the number of sheets
    n_sheets = len(pd.ExcelFile(filename).sheet_names)

    # exctract all sheets and concatenate them
    scan4000 = pd.concat(
        [pd.read_excel(filename, sheet_name=i, header=1, usecols="B:K,M") for i in range(n_sheets)],
        axis=0,
        ignore_index=True,
    )

    # rename pdf names column
    scan4000 = scan4000.rename(columns={scan4000.columns[-1]: "pdf"})

    # fix pdf name encoding error
    scan4000.loc[
        (scan4000["pdf"] == "2019-11-21 _Session_MAS_2"), "pdf"
    ] = "2019-11-21_Session_MAS_2"

    return scan4000


def _json_to_df_model_kpis(models_kpis: ModelsKPIs) -> pd.DataFrame:
    data: Dict[str, List[float]] = {}
    index = []

    for model in models_kpis.models:
        if model.available:
            index.append(model.name)
            for task, metrics in model.kpis.dict().items():
                for metric_name, metric_value in metrics.items():
                    kpi_name = f"{task} {metric_name}"
                    if kpi_name in data.keys():
                        data[kpi_name].append(metric_value)
                    else:
                        data[kpi_name] = [metric_value]

    df = pd.DataFrame(data=data, index=index)
    return df.sort_values(df.columns[0])


def json_to_df_model_kpis(
    models_kpis: ModelsKPIs,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Convert the models kpis from json to dataframe."""
    # convert to df
    df = _json_to_df_model_kpis(models_kpis=models_kpis)

    # make column names more explicit
    main_columns = []
    main_ratios = []
    mae_columns = []
    mae_ratios = []
    mape_columns = []
    mape_ratios = []
    other_columns = []
    for column in df.columns.tolist():
        ratio_name = f"ratio {column.split(' ')[-1]}"
        if column.startswith("main "):
            main_ratios.append(df.loc[:, ratio_name][0])
            main_columns.append(column)
        elif column.startswith("mae "):
            mae_ratios.append(df.loc[:, ratio_name][0])
            mae_columns.append(column)
        elif column.startswith("mape "):
            mape_ratios.append(df.loc[:, ratio_name][0])
            mape_columns.append(column)
        elif column.startswith("bbox") or column.startswith("segm"):
            other_columns.append(column)

    df_main = df.loc[:, main_columns]
    df_mae = df.loc[:, mae_columns]
    df_mape = df.loc[:, mape_columns]
    df_other = df.loc[:, other_columns]

    df_main.columns = [
        column.split("main ")[1] + f" (ratio {int(ratio)}%)"
        for column, ratio in zip(df_main.columns, main_ratios)
    ]
    df_mae.columns = [
        column.split("mae ")[1] + f" (ratio {int(ratio)}%)"
        for column, ratio in zip(df_mae.columns, mae_ratios)
    ]
    df_mape.columns = [
        column.split("mape ")[1] + f" (ratio {int(ratio)}%)"
        for column, ratio in zip(df_mape.columns, mape_ratios)
    ]

    df_main = df_main.sort_values(df_main.columns[0])
    df_mae = df_mae.sort_values(df_mae.columns[0])
    df_mape = df_mape.sort_values(df_mape.columns[0])
    df_other = df_other.sort_values(df_other.columns[0])

    return df_main, df_mae, df_mape, df_other


def extract_challenging_images(
    origin: str, destination: str, ids: Optional[List[int]] = None, overwrite: bool = True
) -> None:
    """Extract the challenging images for the model."""
    # check ids
    if not ids:
        ids = [
            713,
            754,
            759,
            677,
            1333,
            1334,
            1341,
            1264,
            1270,
            1302,
            1309,
            1311,
            901,
            1149,
            823,
            76,
            483,
            101,
            103,
            104,
            105,
            112,
            115,
            210,
            150,
            212,
            237,
            261,
            288,
            320,
            353,
            377,
            397,
            602,
            604,
            608,
            615,
            660,
            1372,
            1373,
            1376,
            1379,
            1380,
            1389,
            1391,
            1444,
            1446,
            1422,
            1425,
            1427,
            1430,
            1453,
        ]

    # fetch files to copy
    files_to_copy = []
    for sub_id in ids:
        files_to_copy.append(os.path.join(origin, f"image_{str(sub_id).zfill(5)}.jpg"))
        files_to_copy.append(os.path.join(origin, f"prediction_{str(sub_id).zfill(5)}.jpg"))

    # decide wether to overwrite
    if not (os.path.exists(destination) and not overwrite):

        delete_folders([destination])
        Path(destination).mkdir(parents=True, exist_ok=True)

        # copy files
        for file_to_copy in files_to_copy:
            shutil.copy2(
                src=file_to_copy, dst=os.path.join(destination, os.path.basename(file_to_copy))
            )
