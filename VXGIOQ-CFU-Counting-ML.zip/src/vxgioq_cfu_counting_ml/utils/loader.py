"""Loading utilties."""

import logging
import os
from typing import List, Optional, Tuple

import cv2
import joblib
import numpy as np
import torch
from detectron2.config import get_cfg
from detectron2.config.config import CfgNode
from detectron2.engine import DefaultPredictor
from PIL import Image
from tqdm.auto import tqdm

from vxgioq_cfu_counting_ml.utils.azure import (
    MODEL_CONFIG_NAME,
    MODEL_WEIGHTS_NAME,
    MODELS_QUANTILES_NAME,
    PATH_MODELS_ON_DISK,
    download_load_models_kpis,
    download_unzip_clean_model,
    download_unzip_clean_predictions,
)
from vxgioq_cfu_counting_ml.utils.types import ModelQuantilesInterval, ModelsKPIs

logger = logging.getLogger(__name__)


def find_backbone(cfg: CfgNode) -> str:
    """Find the backbone used by `cfg`."""
    if cfg.MODEL.RESNETS.STRIDE_IN_1X1 is False:
        backbone = "X101-FPN"
    elif cfg.MODEL.RESNETS.DEPTH == 101:
        backbone = "R101-FPN"
    elif cfg.MODEL.RESNETS.DEPTH == 50:
        backbone = "R50-FPN"
    else:
        raise ValueError("Could not recognize the backbone in use based on the cfg.")

    return backbone


def load_config(
    model_name: str,
    score_thresh_test: Optional[float] = None,
    filter_empty_annotations: Optional[bool] = None,
) -> CfgNode:
    """Load model's config."""
    # load it's config
    cfg = get_cfg()
    cfg.merge_from_file(
        os.path.join(PATH_MODELS_ON_DISK, model_name.split(".zip")[0], MODEL_CONFIG_NAME)
    )
    cfg.MODEL.WEIGHTS = os.path.join(
        PATH_MODELS_ON_DISK, model_name.split(".zip")[0], MODEL_WEIGHTS_NAME
    )

    # get config up to date
    if not torch.cuda.is_available():
        logger.info("CUDA is not available, using CPU.")
        cfg["MODEL"]["DEVICE"] = "cpu"
    else:
        logger.info("CUDA is available, using GPU.")
        cfg["MODEL"]["DEVICE"] = "cuda"
    if score_thresh_test is not None:
        cfg["MODEL"]["ROI_HEADS"]["SCORE_THRESH_TEST"] = score_thresh_test
    if filter_empty_annotations is not None:
        if filter_empty_annotations is True:
            cfg["DATALOADER"]["FILTER_EMPTY_ANNOTATIONS"] = True
        else:
            cfg["DATALOADER"]["FILTER_EMPTY_ANNOTATIONS"] = False

    return cfg


def load_model(
    model_name: str,
    score_thresh_test: Optional[float] = None,
    filter_empty_annotations: Optional[bool] = None,
) -> Tuple[DefaultPredictor, CfgNode]:
    """
    Load a model and set its config appropriately.

    Parameters
    ----------
    model_name
        The model name.
    score_thresh_test
        The score threshold on test data to decide wether to keep predictions or not.
    filter_empty_annotations
        Wether to set the empty annotations filter to True or False. By default, None won't touch the original value of the config's parameter.

    Returns
    -------
    (The model's predictor, It's config)
    """
    # load it's config
    cfg = load_config(
        model_name=model_name,
        score_thresh_test=score_thresh_test,
        filter_empty_annotations=filter_empty_annotations,
    )

    # instantiate a predictor for it
    return DefaultPredictor(cfg), cfg


def load_pi_models(model_name: str) -> ModelQuantilesInterval:
    """Load the pi models."""
    models_pi: ModelQuantilesInterval = joblib.load(
        os.path.join(PATH_MODELS_ON_DISK, model_name.split(".zip")[0], MODELS_QUANTILES_NAME)
    )
    return models_pi


def download_unzip_best_model(task: str = "main", metric: str = "MAE (counts) 1-5") -> str:
    """
    Fetch all available models benchmarks and download the one with best results on chosen KPI (Counts all MAE).

    Returns
    -------
    Best model name
    """
    # download and load models KPIs
    models_kpis = download_load_models_kpis(overwrite=True)

    # get best model name
    best_model_name = get_best_model_name(models_kpis=models_kpis, task=task, metric=metric)

    # download that model if need be
    download_unzip_clean_model(model_name=best_model_name)

    # print model name (useful for bash scripts to retrieve)
    return best_model_name


def get_best_model_name(
    models_kpis: ModelsKPIs,
    task: str = "main",
    metric: str = "MAE (counts) 1-5",
    available: bool = True,
) -> str:
    """Get the name of the best model according to the chosen task and metric and according to wether that model is still available or not."""
    best_model_kpi = 9999.0
    best_model_name: Optional[str] = None
    for model in models_kpis.models:
        if model.available if available else True:
            current_model_kpi: float = model.kpis.dict()[task][metric]
            if current_model_kpi < best_model_kpi:
                best_model_kpi = current_model_kpi
                best_model_name = model.name

    if best_model_name:
        return best_model_name
    else:
        raise ValueError("No available best model name could be found.")


def get_best_model(
    task: str = "main", metric: str = "MAE (counts) 1-5"
) -> Tuple[DefaultPredictor, CfgNode, str]:
    """Fetch all available models benchmarks and download and load the one with best results on chosen KPI (Counts all MAE)."""
    # download models kpis, get best model name and download that model
    best_model_name = download_unzip_best_model(task=task, metric=metric)

    # load that best model
    best_model, best_cfg = load_model(model_name=best_model_name)
    return best_model, best_cfg, best_model_name


def get_best_model_predictions(task: str = "main", metric: str = "MAE (counts) 1-5") -> str:
    """Fetch all available models benchmarks and download and load the predictions of the one with best results on chosen KPI (Counts all MAE)."""
    # download and load models KPIs
    models_kpis = download_load_models_kpis(overwrite=True)

    # get best model name
    best_model_name = get_best_model_name(models_kpis=models_kpis, task=task, metric=metric)

    download_unzip_clean_predictions(predictions_name=best_model_name, overwrite=False)

    return best_model_name


def load_images(
    paths_images: List[str],
    height: int = 1200,
    width: int = 1200,
    channels: int = 3,
    interpolation: int = cv2.INTER_LINEAR,
) -> Tuple[np.ndarray, np.ndarray]:
    """Load in RGB and resize all n images in a numpy array of shape [n, height, width, channels] and compute images paths."""
    images = []
    images_names = []
    for path_image in tqdm(paths_images):
        try:
            images.append(
                cv2.resize(
                    src=np.array(Image.open(path_image))[:, :, :channels],
                    dsize=(height, width),
                    interpolation=interpolation,
                )
            )
            images_names.append(path_image)
        except IndexError:
            logger.warning(f"Failed to process image: {path_image}.")

    return np.stack(images, axis=0), np.array(images_names)
