"""
Pydantic models for the ML API requests and responses.

isort:skip_file
"""
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, BaseConfig, Field, HttpUrl

from vxgioq_cfu_counting_ml.utils.types import QuantilePrediction

BaseConfig.arbitrary_types_allowed = True

INPUT_URL_EXPLE = (
    "https://us6vxgioqcfudevsac01.blob.core.windows.net/sample/Inputimage/image_010.png"
)
OUTPUT_URL_EXPLE = (
    "https://us6vxgioqcfudevsac01.blob.core.windows.net/sample/Outputimage/image_010.png"
)
SAMPLE_ID = "image_013"


class ShapeAttributes(BaseModel):
    """ShapeAttributes object, depicting an object's shapes in the VIA annotator V2 json format."""

    all_points_x: List[float] = Field(
        ...,
        title="X coordinates of a shape in an cartesian coordinates system with a top left origin.",
    )
    all_points_y: List[float] = Field(
        ...,
        title="Y coordinates of a shape in an cartesian coordinates system with a top left origin.",
    )
    name: str = Field(
        "polygon",
        title="The type of Shape in the VIA json format naming conventions. Only polygon is supported.",
    )
    category_id: Optional[int]= None


class Region(BaseModel):
    """Region object, depicting an object in the VIA annotator V2 json format."""

    shape_attributes: ShapeAttributes
    region_attributes: Dict[str, Any] = Field(
        {},
        title="Region attribute in the VIA json format naming conventions. For the CFU applications, this can be safely let empty.",
    )


class Predictions(BaseModel):
    """Predictions object, based on VIA annotator V2 json format."""

    filename: str = Field(
        ...,
        title="Azure Blob storage url to the petri dish image to predict CFUs on (supported files include but are not limited to: PNG, JPG and BMP).",
    )
    model_name: str = Field(..., title="Name of the model that computed the predictions.")
    size: int = Field(
        ...,
        title="Size attribute in the VIA json format naming conventions. It is unclear what its role is but doesn't impact the VIA display. Hence, we use it to depict the number of pixels of the image.",
    )
    regions: List[Region]
    predictions_cfu_count: int = Field(
        ..., title="The predicted number of CFUs.",
    )
    predictions_cfu_count_quantiles: List[QuantilePrediction] = Field(
        ...,
        title="The list of quantile predicted number of CFUs This can be used to display prediction intervals. For example, the 95% PI would be constructed as [quantile_0.025, quantile_0.975].",
    )
    predictions_scores: List[float] = Field(
        ...,
        title="The predicted CFUs scores (between 0 and 1, but not to be confused with a probability).",
    )
    predictions_bboxes: List[List[float]] = Field(
        ..., title="The predicted bboxes of CFUs.",
    )
    predictions_datetime: datetime = Field(
        ..., title="Date and time at which the model finished predicting the dish."
    )


class ImageOutput(BaseModel):
    """Image with predictions."""

    sample_id: str = Field(
        ..., title="Id of the image in cosmosDB.",
    )
    image_original_url: HttpUrl = Field(
        ...,
        title="Azure Blob storage url to the petri dish image to predict CFUs on. (supported files include but are not limited to: PNG, JPG and BMP).",
    )
    image_predicted_url: HttpUrl = Field(
        ...,
        title="Azure Blob storage url to the location where the original petri dish image with bounding boxes and masks predictions on top as displayed by the user unterface will be saved.",
    )
    predictions: Predictions

    class Config:
        """Example usage of the object."""

        schema_extra = {
            "example": {
                "images": [
                    {
                        "id_cosmosdb": "5faed6fa6ba6680ffebcbf90",
                        "image_original_url": "https://us6vxgioqcfudevsac01.blob.core.windows.net/sample/Inputimage/image_010.png",
                        "image_predicted_url": "https://us6vxgioqcfudevsac01.blob.core.windows.net/sample/Outputimage/image_010.png",
                        "predictions": {
                            "filename": "https://us6vxgioqcfudevsac01.blob.core.windows.net/sample/Inputimage/image_010.png",
                            "model_name": "c2cc9388-7ef8-4ac9-af0a-4eeda21ec99c",
                            "size": 1517824,
                            "regions": [
                                {
                                    "shape_attributes": {
                                        "all_points_x": [
                                            537,
                                            538,
                                            539,
                                            540,
                                            541,
                                            542,
                                            543,
                                            544,
                                            545,
                                            546,
                                            547,
                                            547,
                                            547,
                                            548,
                                            548,
                                            548,
                                            548,
                                            548,
                                            547,
                                            547,
                                            546,
                                            546,
                                            545,
                                            544,
                                            543,
                                            542,
                                            541,
                                            540,
                                            539,
                                            538,
                                            537,
                                            536,
                                            535,
                                            534,
                                            533,
                                            532,
                                            531,
                                            530,
                                            529,
                                            528,
                                            527,
                                            526,
                                            525,
                                            524,
                                            523,
                                            522,
                                            521,
                                            521,
                                            521,
                                            521,
                                            521,
                                            521,
                                            521,
                                            522,
                                            522,
                                            523,
                                            523,
                                            524,
                                            525,
                                            526,
                                            527,
                                            528,
                                            529,
                                            530,
                                            531,
                                            532,
                                            533,
                                            534,
                                            535,
                                            536,
                                            537,
                                        ],
                                        "all_points_y": [
                                            548,
                                            547,
                                            547,
                                            546,
                                            546,
                                            545,
                                            544,
                                            543,
                                            542,
                                            541,
                                            540,
                                            539,
                                            538,
                                            537,
                                            536,
                                            535,
                                            534,
                                            533,
                                            532,
                                            531,
                                            530,
                                            529,
                                            528,
                                            527,
                                            526,
                                            526,
                                            525,
                                            525,
                                            524,
                                            524,
                                            524,
                                            524,
                                            523,
                                            523,
                                            523,
                                            523,
                                            524,
                                            524,
                                            524,
                                            525,
                                            525,
                                            526,
                                            527,
                                            528,
                                            529,
                                            530,
                                            531,
                                            532,
                                            533,
                                            534,
                                            535,
                                            536,
                                            537,
                                            538,
                                            539,
                                            540,
                                            541,
                                            542,
                                            543,
                                            544,
                                            545,
                                            546,
                                            546,
                                            547,
                                            547,
                                            548,
                                            548,
                                            548,
                                            548,
                                            548,
                                            548,
                                        ],
                                        "name": "polygon",
                                    },
                                    "region_attributes": {},
                                },
                                {
                                    "shape_attributes": {
                                        "all_points_x": [
                                            741,
                                            742,
                                            743,
                                            744,
                                            745,
                                            746,
                                            747,
                                            748,
                                            749,
                                            750,
                                            751,
                                            752,
                                            753,
                                            754,
                                            755,
                                            756,
                                            757,
                                            757,
                                            758,
                                            759,
                                            760,
                                            760,
                                            761,
                                            761,
                                            762,
                                            762,
                                            762,
                                            762,
                                            762,
                                            763,
                                            763,
                                            763,
                                            763,
                                            763,
                                            763,
                                            763,
                                            763,
                                            763,
                                            762,
                                            762,
                                            762,
                                            762,
                                            762,
                                            762,
                                            761,
                                            761,
                                            760,
                                            760,
                                            759,
                                            758,
                                            757,
                                            757,
                                            756,
                                            755,
                                            754,
                                            753,
                                            752,
                                            751,
                                            750,
                                            749,
                                            748,
                                            747,
                                            746,
                                            745,
                                            744,
                                            743,
                                            742,
                                            741,
                                            740,
                                            739,
                                            738,
                                            737,
                                            736,
                                            735,
                                            734,
                                            733,
                                            732,
                                            731,
                                            730,
                                            729,
                                            728,
                                            727,
                                            726,
                                            725,
                                            724,
                                            723,
                                            722,
                                            721,
                                            720,
                                            719,
                                            718,
                                            717,
                                            716,
                                            715,
                                            714,
                                            714,
                                            713,
                                            712,
                                            711,
                                            710,
                                            710,
                                            709,
                                            708,
                                            708,
                                            707,
                                            707,
                                            706,
                                            706,
                                            706,
                                            705,
                                            705,
                                            705,
                                            705,
                                            704,
                                            704,
                                            704,
                                            704,
                                            704,
                                            704,
                                            704,
                                            704,
                                            705,
                                            705,
                                            705,
                                            706,
                                            706,
                                            707,
                                            707,
                                            708,
                                            708,
                                            709,
                                            709,
                                            710,
                                            711,
                                            712,
                                            712,
                                            713,
                                            714,
                                            715,
                                            716,
                                            717,
                                            718,
                                            719,
                                            720,
                                            721,
                                            722,
                                            723,
                                            724,
                                            725,
                                            726,
                                            727,
                                            728,
                                            729,
                                            730,
                                            731,
                                            732,
                                            733,
                                            734,
                                            735,
                                            736,
                                            737,
                                            738,
                                            739,
                                            740,
                                        ],
                                        "all_points_y": [
                                            450,
                                            449,
                                            449,
                                            448,
                                            448,
                                            448,
                                            447,
                                            446,
                                            446,
                                            445,
                                            444,
                                            443,
                                            442,
                                            442,
                                            441,
                                            440,
                                            439,
                                            438,
                                            437,
                                            436,
                                            435,
                                            434,
                                            433,
                                            432,
                                            431,
                                            430,
                                            429,
                                            428,
                                            427,
                                            426,
                                            425,
                                            424,
                                            423,
                                            422,
                                            421,
                                            420,
                                            419,
                                            418,
                                            417,
                                            416,
                                            415,
                                            414,
                                            413,
                                            412,
                                            411,
                                            410,
                                            409,
                                            408,
                                            407,
                                            406,
                                            405,
                                            404,
                                            403,
                                            402,
                                            402,
                                            401,
                                            400,
                                            399,
                                            398,
                                            397,
                                            397,
                                            396,
                                            396,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            395,
                                            396,
                                            396,
                                            397,
                                            397,
                                            398,
                                            399,
                                            399,
                                            400,
                                            401,
                                            402,
                                            403,
                                            404,
                                            405,
                                            406,
                                            407,
                                            408,
                                            409,
                                            410,
                                            411,
                                            412,
                                            413,
                                            414,
                                            415,
                                            416,
                                            417,
                                            418,
                                            419,
                                            420,
                                            421,
                                            422,
                                            423,
                                            424,
                                            425,
                                            426,
                                            427,
                                            428,
                                            429,
                                            430,
                                            431,
                                            432,
                                            433,
                                            434,
                                            435,
                                            436,
                                            437,
                                            438,
                                            439,
                                            440,
                                            441,
                                            442,
                                            442,
                                            443,
                                            444,
                                            445,
                                            446,
                                            446,
                                            447,
                                            447,
                                            448,
                                            448,
                                            449,
                                            449,
                                            449,
                                            449,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                            450,
                                        ],
                                        "name": "polygon",
                                    },
                                    "region_attributes": {},
                                },
                            ],
                            "predictions_cfu_count": 2,
                            "predictions_cfu_count_quantiles": [
                                {"quantile": 0.025, "prediction": 1.2},
                                {"quantile": 0.5, "prediction": 2.005},
                                {"quantile": 0.975, "prediction": 2.3},
                            ],
                            "predictions_scores": [0.9964597821235657, 0.9956491589546204],
                            "predictions_bboxes": [
                                [
                                    521.188720703125,
                                    523.9959106445312,
                                    548.6807861328125,
                                    548.1466674804688,
                                ],
                                [
                                    704.53955078125,
                                    395.7314758300781,
                                    762.5558471679688,
                                    450.1232604980469,
                                ],
                            ],
                            "predictions_datetime": "2020-11-16T12:04:12.395933+00:00",
                        },
                    }
                ]
            }
        }


class CFUInput(BaseModel):
    """Coco formated images to compute predictions on."""

    samples_ids: List[str] = Field(
        ..., title="Ids of Azure Cosmos MongoDB CFU dishes sample ids to predict.",
    )

    class Config:
        """Example usage of the object."""

        schema_extra = {"example": {"samples_ids": [SAMPLE_ID]}}


class CFUInputV2(BaseModel):
    """Coco formated images to compute predictions on."""

    image_base64: List[str] = Field(
        ..., title="Ids of Azure Cosmos MongoDB CFU dishes sample ids to predict.",
    )
    sample_id: str
    equipment_cfu_count : int   
    solution_dilution   : str
    solution_volume_ml   : str
    cfu_volume_ratio_counts_per_ml  : str
    cfu_prorata                    : int
    equiment_detection_area_pct    : str
    equipment_sensitivity_threshold : int
    cfu_detection_parameters        :str
    equiment_focus_mode              :str
    mean_cfu_diameter_mm            : str
    min_cfu_diameter_mm             : str
    max_cfu_diameter_mm             : str
    debris_diameter_mm              : str
    operator_comments               : str
    scanned_datetime                : str
    scan_date                       : str
    scanned_by                     : str
    is_validated                   : str

    class Config:
        """Example usage of the object."""

        schema_extra = {"example": {"image_base64": [""],
        "sample_id": "image_001",
        "equipment_cfu_count": 1,  
        "solution_dilution": "32"     ,
        "solution_volume_ml": "44",
        "cfu_volume_ratio_counts_per_ml": "33",
        "cfu_prorata": 3,
        "equiment_detection_area_pct": "32",
        "equipment_sensitivity_threshold": 23,
        "cfu_detection_parameters" : "23",
        "equiment_focus_mode" : "23",
        "mean_cfu_diameter_mm": "567",
        "min_cfu_diameter_mm": "56",
        "max_cfu_diameter_mm": "343",
        "debris_diameter_mm": "33",
        "operator_comments": "45",
        "scanned_datetime": "12.34.56",
        "scan_date": "56",
        "scanned_by": "Analyste",
        "is_validated": "OK"
        }}


class CFUOutput(BaseModel):
    """Coco formated images and predicted annotations."""

    images: List[ImageOutput]


class CFUOutputV2(BaseModel):
    """Coco formated images and predicted annotations."""

    images: List[ImageOutput]
    predicted_base64: str
