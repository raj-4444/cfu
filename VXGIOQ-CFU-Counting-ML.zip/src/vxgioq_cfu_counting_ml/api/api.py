"""
API definition module.

isort:skip_file
"""
import os
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Union
import arrow
from fastapi import BackgroundTasks, FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi import Security, Depends, HTTPException
from fastapi.security.api_key import APIKeyHeader
from starlette.status import HTTP_403_FORBIDDEN

import numpy as np
from timeloop import Timeloop
import tensorflow as tf

from vxgioq_cfu_counting_ml.api.data_models import (
    CFUInput,
    CFUInputV2,
    CFUOutput,
    CFUOutputV2,
    ImageOutput,
    Predictions,
    Region,
    ShapeAttributes,
)
from vxgioq_cfu_counting_ml.utils import conf
from vxgioq_cfu_counting_ml.utils.azure import (
    download_image,
    download_PIL_image,
    get_cosmos_mongo_collection,
    get_cosmos_mongo_collection_phase2,
    PATH_MODELS_ON_DISK,
    get_base64_format,
)
from vxgioq_cfu_counting_ml.utils.custom_datasets import mask_2_polygon
from vxgioq_cfu_counting_ml.utils.predictor import (
    get_best_cfu_model, 
    get_best_classification_model, 
    predict_colony,
    get_retrained_segmentation_model,
    get_classification_score,
    write_prediction_JSON,
)

logger = logging.getLogger(__name__)

PERIODIC_MODELS_UPDATES = 600  # periodic model updates, in seconds
PREDICTOR = get_best_cfu_model()
get_best_classification_model("Inception_model.zip")
CLASSIFICATION_MODEL = tf.keras.models.load_model(f"{PATH_MODELS_ON_DISK}/Inception_model.hdf5")
RETRAINED_CFU_MODEL = get_retrained_segmentation_model("dcf7402a-28ad-43cb-9e8f-aa8efb1ff539.zip")

app = FastAPI(
    title="CFU QC ML API",
    description="Colony Forming Unit Quality Control Machine Learning API.",
    started=arrow.now(),
)

tl = Timeloop()

# to generate run openssl rand -hex 32
API_KEY = "18f0e091c1ddac21ae827fc58ec62d798e4ea9ce566b1d4136281f1e281fe7b9"
API_KEY_NAME = "access_token"

api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

async def get_api_key(
    api_key_header: str = Security(api_key_header),
) -> Any:
    """Set the API authentication header."""
    if api_key_header == API_KEY:
        return api_key_header
    else:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN, detail="Could not validate credentials"
        )

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_headers(request: Request, call_next: Callable[..., Any]) -> Response:
    """
    Add process time and security headers.

    Middleware to add extra headers to report the time required to execute
    an API call and several security headers.
    """
    start_time = time.time()
    response: Response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["X-Frame-Options"] = "sameorigin"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["X-Content-Type-Options"] = "nosniff"
    # Enable if really needed (i.e. if WAST really requires it) and we are aware of all
    # possible origins of callers (e.g. this will block local development of UI)
    # and only when UI get their final url
    # response.headers["Content-Security-Policy"] = "script-src 'self' https://cfu-qc.somwhere.something"
    return response


@app.on_event("startup")
async def startup_event() -> None:
    """Startup event to periodically check if a new better model is available and download and load it if this is the case."""
    logger.info("Start updates scheduler for possible new best model to download and load...")
    background_tasks = BackgroundTasks()
    background_tasks.add_task(tl.start(block=False))
    logger.info("Scheduler started and running in background.")


@tl.job(interval=timedelta(seconds=PERIODIC_MODELS_UPDATES))
def update_best_model() -> None:
    """Wrap the get_best_model utility to update the best model in use on a periodic basis."""
    global PREDICTOR
    logger.info(
        f"Periodic ({PERIODIC_MODELS_UPDATES} sec) check for potentially new and better model to download and load..."
    )
    try:
        PREDICTOR = get_best_cfu_model()
        logger.info("Periodic check done.")
    except Exception as e:
        logger.error(f"Periodic check failed. See trace: {e}.")


@app.get("/index", include_in_schema=False)
async def index() -> Dict[str, Union[str, List[str]]]:
    """Index API Call."""
    return {
        "title": app.title,
        "description": app.description,
        "started": app.extra["started"].isoformat(),
        "git-commit": conf.COMMIT,
        "git-branch": conf.BRANCH,
        "storage_name": conf.STORAGE_NAME,
    }


@app.get("/")
async def hello() -> Dict[str, str]:
    """Welcome index call."""
    return {"message": "Hello World"}


@app.post(
    "/petri_dishes/segmented_instances", response_model=CFUOutput, tags=["predictions"],
)
async def segment_images_instances(cfu_input: CFUInput) -> CFUOutput:
    """
    Predict CFUs on images.

    The endpoint
        - receives the dishes document ids of the azure cosmsos mongo db collection
        - downloads the images corresponding to those documents
        - predicts the cfus on these images
        - updates the cosmosdb documents with the corresponding predictions
        - returns an object listing the predictions and additional information.
    """
    # extract items from cfu dishes cosmos db collection
    dishes_collection = get_cosmos_mongo_collection()
    dishes = list(dishes_collection.find({"sample_id": {"$in": cfu_input.samples_ids}}))

    # check whether all, some or none of the supplied sample ids could be retrived
    if len(dishes) == 0:
        logger.error(
            f"None of the supplied samples_ids: {cfu_input.samples_ids} where found in the DB collection."
        )
        return CFUOutput(images=[])

    if len(dishes) < len(cfu_input.samples_ids):
        unretrieved_samples_ids = list(
            set(cfu_input.samples_ids).difference({dish["sample_id"] for dish in dishes})
        )
        logger.error(
            f"Some of the supplied samples_ids could not be retrieved: {unretrieved_samples_ids}."
        )
    # load images from blob
    logger.info("Load images in RGB...")
    images_inputs = [download_image(dish["image_original_url"]) for dish in dishes]
    heights = [image_input.shape[0] for image_input in images_inputs]
    widths = [image_input.shape[1] for image_input in images_inputs]

    # predict (not useful to batch predict as pytorch model doesn't batch images)
    logger.info("Predict images...")
    predictions = [
        PREDICTOR.predict_quantiles([image_input[:, :, ::-1]])[0] for image_input in images_inputs
    ]
    predictions_datetime = datetime.now(tz=timezone.utc)

    # write output json
    logger.info("Prepare response...")
    max_edges = 101
    response = CFUOutput(
        images=[
            ImageOutput(
                sample_id=dish["sample_id"],
                image_original_url=dish["image_original_url"],
                image_predicted_url=dish["image_predicted_url"],
                predictions=Predictions(
                    filename=dish["image_original_url"],
                    model_name=PREDICTOR.model_name,
                    size=height * width,
                    regions=[
                        Region(
                            shape_attributes=ShapeAttributes(
                                all_points_x=mask_2_polygon(pred_mask, max_edges=max_edges)[
                                    :, 1
                                ].tolist(),
                                all_points_y=(
                                    mask_2_polygon(pred_mask, max_edges=max_edges)[:, 0]
                                ).tolist(),
                                name="polygon",
                            ),
                            region_attributes={},
                        )
                        for pred_mask in prediction.instances.pred_masks.numpy()
                    ],
                    predictions_cfu_count=prediction.model_prediction.prediction,
                    predictions_cfu_count_quantiles=prediction.quantiles_predictions,
                    predictions_scores=prediction.instances.scores.tolist(),
                    predictions_bboxes=prediction.instances.pred_boxes.tensor.tolist(),
                    predictions_datetime=predictions_datetime,
                ),
            )
            for dish, prediction, height, width in zip(dishes, predictions, heights, widths)
        ]
    )

    # prepare cosmosdb object
    predictions_cosmosdb = [{"image": image.predictions.dict()} for image in response.images]

    # write to cosmos db
    logger.info("Write predictions to cosmos db...")
    for prediction_cosmosdb, dish in zip(predictions_cosmosdb, dishes):
        dishes_collection.update_one(
            filter={"sample_id": dish["sample_id"]},
            update={"$set": {"predictions": prediction_cosmosdb}},
        )

    # return json
    return response


@app.post(
    "/petri_dishes/image_classification", response_model=CFUOutput, tags=["predictions"],
)
async def segment_image_classification(cfu_input: CFUInput) -> CFUOutput:
    """
    Predict CFUs on images.

    The endpoint
        - receives the dishes document ids of the azure cosmsos mongo db collection
        - downloads the images corresponding to those documents
        - predicts the cfus on these images
        - updates the cosmosdb documents with the corresponding predictions
        - returns an object listing the predictions and additional information.
        - applies cropping of images on each predicted cfus.
        - applies resizing and padding of cropped images.
        - Fed into the classification model to distinguish the cfus and molds.
    """
    # extract items from cfu dishes cosmos db collection
    dishes_collection = get_cosmos_mongo_collection_phase2()
    dishes = list(dishes_collection.find({"sample_id": {"$in": cfu_input.samples_ids}}))

    # check whether all, some or none of the supplied sample ids could be retrived
    if len(dishes) == 0:
        logger.error(
            f"None of the supplied samples_ids: {cfu_input.samples_ids} where found in the DB collection."
        )
        return CFUOutput(images=[])

    if len(dishes) < len(cfu_input.samples_ids):
        unretrieved_samples_ids = list(
            set(cfu_input.samples_ids).difference({dish["sample_id"] for dish in dishes})
        )
        logger.error(
            f"Some of the supplied samples_ids could not be retrieved: {unretrieved_samples_ids}."
        )
    
    # load images from blob
    logger.info("Load images in RGB...")
    images_inputs = [download_image(dish["image_original_url"]) for dish in dishes]
    heights = [image_input.shape[0] for image_input in images_inputs]
    widths = [image_input.shape[1] for image_input in images_inputs]

    # predict (not useful to batch predict as pytorch model doesn't batch images)
    logger.info("Predict images...")
    predictions = [
        PREDICTOR.predict_quantiles([image_input[:, :, ::-1]])[0] for image_input in images_inputs
    ]
    
    predictions_bboxes=[prediction.instances.pred_boxes.tensor.tolist() for prediction in predictions]

    #predict the cfus and mold separately using classification model
    pil_image = [download_PIL_image(dish["image_original_url"]) for dish in dishes]
    
    predictions_datetime = datetime.now(tz=timezone.utc)
    
    if predictions_bboxes == [[]]:
        retrained_predictions = [
        RETRAINED_CFU_MODEL.predict_quantiles([image_input[:, :, ::-1]])[0] for image_input in images_inputs
        ]
    
        retrained_predictions_bboxes=[prediction.instances.pred_boxes.tensor.tolist() for prediction in retrained_predictions]
        if retrained_predictions_bboxes == [[]]:
            response = CFUOutput(
                images=[
                ImageOutput(
                    sample_id=dish["sample_id"],
                    image_original_url=dish["image_original_url"],
                    image_predicted_url=dish["image_predicted_url"],
                    predictions=Predictions(
                        filename=dish["image_predicted_url"],
                        model_name=RETRAINED_CFU_MODEL.model_name,
                        size=height * width,
                        regions=[],
                        predictions_cfu_count=0,
                        predictions_cfu_count_quantiles=prediction.quantiles_predictions,
                        predictions_scores=prediction.instances.scores.tolist(),
                        predictions_bboxes=prediction.instances.pred_boxes.tensor.tolist(),
                        predictions_datetime=predictions_datetime,
                    ),
                )
                for dish, prediction, height, width in zip(dishes, retrained_predictions, heights, widths)
            ]
        )

        else:
            img_str, scores = get_classification_score(CLASSIFICATION_MODEL, pil_image, retrained_predictions_bboxes)
            response = write_prediction_JSON(dishes, retrained_predictions, heights, widths, scores, RETRAINED_CFU_MODEL.model_name)
    else:
        img_str, scores = get_classification_score(CLASSIFICATION_MODEL, pil_image, predictions_bboxes)
        response = write_prediction_JSON(dishes, predictions, heights, widths, scores, PREDICTOR.model_name)
        
        
    # prepare cosmosdb object
    predictions_cosmosdb = [{"image": image.predictions.dict()} for image in response.images]
    
    # write to cosmos db
    logger.info("Write predictions to cosmos db...")
    for prediction_cosmosdb, dish in zip(predictions_cosmosdb, dishes):
        dishes_collection.update_one(
            filter={"sample_id": dish["sample_id"]},
            update={"$set": {"predictions": prediction_cosmosdb}},
        )

    # return json
    return response


@app.post(
    "/petri_dishes/image_upload_method", response_model=CFUOutputV2, tags=["predictions"],
)
async def segment_image_upload_method(image_input: CFUInputV2, api_key: str = Depends(get_api_key)) -> CFUOutputV2:
    """Predict CFUs on images.""" 
    # check whether all, some or none of the supplied sample ids could be retrived
    if image_input.image_base64[0] == "":
        logger.error(
            f"None of the supplied samples_ids: where found in the input."
        )
        return CFUOutputV2(predicted_base64 = "", images=[])

    bool_val, image, channel_image, original_url, prediction_url  = get_base64_format(image_input.image_base64[0], image_input.sample_id)

    #check if a image is black image and it doesnt contain any petri dishes in it
    if bool_val == False:
        logger.error(
            f"Image doesnt have petri dish in it and its a complete a black image which is invalid."
        )
        return CFUOutputV2(predicted_base64 = "", images=[])
    
    # load images from blob
    logger.info("Load images in RGB...")
    images_inputs = [channel_image]
    heights = [image_input.shape[0] for image_input in images_inputs]
    widths = [image_input.shape[1] for image_input in images_inputs]

    # predict (not useful to batch predict as pytorch model doesn't batch images)
    logger.info("Predict images...")
    predictions = [
        PREDICTOR.predict_quantiles([image_input[:, :, ::-1]])[0] for image_input in images_inputs
    ]
    
    predictions_bboxes=[prediction.instances.pred_boxes.tensor.tolist() for prediction in predictions]

    predictions_datetime = datetime.now(tz=timezone.utc)
    
    if predictions_bboxes == [[]]:
        retrained_predictions = [
        RETRAINED_CFU_MODEL.predict_quantiles([image_input[:, :, ::-1]])[0] for image_input in images_inputs
        ]
    
        retrained_predictions_bboxes=[prediction.instances.pred_boxes.tensor.tolist() for prediction in retrained_predictions]
        if retrained_predictions_bboxes == [[]]:
            response = CFUOutputV2(
                predicted_base64 = image_input.image_base64[0],
                images=[
                    ImageOutput(
                        sample_id=image_input.sample_id,
                        image_original_url=original_url,
                        image_predicted_url=prediction_url,
                        predictions=Predictions(
                            filename=prediction_url,
                            model_name=RETRAINED_CFU_MODEL.model_name,
                            size=height * width,
                            regions=[],
                            predictions_cfu_count=0,
                            predictions_cfu_count_quantiles=prediction.quantiles_predictions,
                            predictions_scores=prediction.instances.scores.tolist(),
                            predictions_bboxes=prediction.instances.pred_boxes.tensor.tolist(),
                            predictions_datetime=predictions_datetime,
                        ),
                    )
                    for prediction, height, width in zip(retrained_predictions, heights, widths)
                ]
            )
        else:
            img_str, scores = get_classification_score(CLASSIFICATION_MODEL, [image], retrained_predictions_bboxes)
            # write output json
            logger.info("Prepare response...")
            max_edges = 101
            response = CFUOutputV2(
                predicted_base64 = img_str,
                images=[ImageOutput(
                        sample_id=image_input.sample_id,
                        image_original_url=original_url,
                        image_predicted_url=prediction_url,
                        predictions=Predictions(
                            filename=prediction_url,
                            model_name=RETRAINED_CFU_MODEL.model_name,
                            size=height * width,
                            regions=[
                                Region(
                                    shape_attributes=ShapeAttributes(
                                        all_points_x=mask_2_polygon(pred_mask, max_edges=max_edges)[
                                            :, 1
                                        ].tolist(),
                                        all_points_y=(
                                            mask_2_polygon(pred_mask, max_edges=max_edges)[:, 0]
                                        ).tolist(),
                                        name="polygon",
                                        category_id=score_val,
                                    ),
                                    region_attributes={},
                                )
                                for pred_mask, score_val in zip(prediction.instances.pred_masks.numpy(), score)
                            ],
                            predictions_cfu_count=prediction.model_prediction.prediction,
                            predictions_cfu_count_quantiles=prediction.quantiles_predictions,
                            predictions_scores=prediction.instances.scores.tolist(),
                            predictions_bboxes=prediction.instances.pred_boxes.tensor.tolist(),
                            predictions_datetime=predictions_datetime,
                        ),
                    )
                    for prediction, height, width, score in zip(retrained_predictions, heights, widths, scores)
                ]
            )
           
    else:
        img_str, scores = get_classification_score(CLASSIFICATION_MODEL, [image], predictions_bboxes)
        # write output json
        logger.info("Prepare response...")
        max_edges = 101
        response = CFUOutputV2(
            predicted_base64 = img_str,
            images=[ImageOutput(
                    sample_id=image_input.sample_id,
                    image_original_url=original_url,
                    image_predicted_url=prediction_url,
                    predictions=Predictions(
                        filename=prediction_url,
                        model_name=PREDICTOR.model_name,
                        size=height * width,
                        regions=[
                            Region(
                                shape_attributes=ShapeAttributes(
                                    all_points_x=mask_2_polygon(pred_mask, max_edges=max_edges)[
                                        :, 1
                                    ].tolist(),
                                    all_points_y=(
                                        mask_2_polygon(pred_mask, max_edges=max_edges)[:, 0]
                                    ).tolist(),
                                    name="polygon",
                                    category_id=score_val,
                                ),
                                region_attributes={},
                            )
                            for pred_mask, score_val in zip(prediction.instances.pred_masks.numpy(), score)
                        ],
                        predictions_cfu_count=prediction.model_prediction.prediction,
                        predictions_cfu_count_quantiles=prediction.quantiles_predictions,
                        predictions_scores=prediction.instances.scores.tolist(),
                        predictions_bboxes=prediction.instances.pred_boxes.tensor.tolist(),
                        predictions_datetime=predictions_datetime,
                    ),
                )
                for prediction, height, width, score in zip(predictions, heights, widths, scores)
            ]
        )

    # prepare cosmosdb object
    predictions_cosmosdb = [{"image": image.predictions.dict()} for image in response.images]
    dishes_collection = get_cosmos_mongo_collection_phase2()

    # write to cosmos db
    logger.info("Write predictions to cosmos db...")
    for prediction_cosmosdb in predictions_cosmosdb:
        pred_dict = {"sample_id": image_input.sample_id,
        "equipment_cfu_count": image_input.equipment_cfu_count,
        "solution_dilution": image_input.solution_dilution,
        "solution_volume_ml": image_input.solution_volume_ml,
        "cfu_volume_ratio_counts_per_ml": image_input.cfu_volume_ratio_counts_per_ml,
        "cfu_prorata": image_input.cfu_prorata,
        "equiment_detection_area_pct": image_input.equiment_detection_area_pct,
        "equipment_sensitivity_threshold": image_input.equipment_sensitivity_threshold,
        "cfu_detection_parameters": image_input.cfu_detection_parameters,
        "equiment_focus_mode": image_input.equiment_focus_mode,
        "mean_cfu_diameter_mm": image_input.mean_cfu_diameter_mm,
        "min_cfu_diameter_mm": image_input.min_cfu_diameter_mm,
        "max_cfu_diameter_mm": image_input.max_cfu_diameter_mm,
        "debris_diameter_mm": image_input.debris_diameter_mm,
        "operator_comments": image_input.operator_comments,
        "scanned_datetime": image_input.scanned_datetime,
        "scan_date": image_input.scan_date,
        "scanned_by": image_input.scanned_by,
        "is_validated": image_input.is_validated,
        "image_height": heights[0],
        "image_width": widths[0],
        "predictions": prediction_cosmosdb}
        dishes_collection.insert_one(pred_dict)
      
    # return json
    return response
