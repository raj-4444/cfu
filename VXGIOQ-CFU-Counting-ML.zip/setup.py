"""Setup module for this Python package."""

import os
import re
import subprocess  # noqa: S404

from setuptools import find_packages, setup


def get_head_sha() -> str:
    """Return the sha key of HEAD."""
    return subprocess.getoutput("git rev-parse HEAD")


# Fill `install_requires` with packages in environment.run.yml.
install_requires = []
with open(os.path.join(os.path.dirname(__file__), "environment.run.yml")) as spec:
    for line in spec:
        match = re.search(r"^\s*-\s+(?P<n>.+)(?P<v>(?:~=|==|!=|<=|>=|<|>|===|@)[^\s\n\r]+)", line)
        if match and match.group("n") not in ("pip", "python"):
            # Support git+ssh://git@.../pkg.git@v1.0.0 packages, see stackoverflow.com/a/54794506.
            prefix = (
                match.group("n").split("/")[-1].replace(".git", "") + " @ "
                if match.group("n").startswith("git+")
                else ""
            )
            install_requires.append(prefix + match.group("n") + match.group("v"))

setup(
    name="vxgioq_cfu_counting_ml",
    version=get_head_sha(),
    description="An API and ML models to count and differentiate between different species of CFUs in petri dishes with various media.",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=install_requires,
    include_package_data=True,
)
