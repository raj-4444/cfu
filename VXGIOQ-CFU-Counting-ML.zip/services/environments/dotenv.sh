#!/usr/bin/env bash

# set -e  # Not used because sourcing forces the execution of the script in the same process, any failing commands executed in that shell after that script will kill the shell

# Usage:
# - Run this as `source dotenv.sh .env` to export variables defined in .env.
# - .env files should be formatted as defined by the docker-compose format [1].
# - Lines starting with '#' are ignored [2].
# [1] https://docs.docker.com/compose/compose-file/#env_file
# [2] https://stackoverflow.com/a/20909045
# shellcheck disable=SC2046  # Otherwise, variables don't get exported correctly
export $(grep -v '^#' "$1" | xargs)
