"""Conftest (test utilities)."""
import os
import shutil
import tempfile
import time
from typing import Iterator, List, Tuple

import pytest
from fastapi.testclient import TestClient

from vxgioq_cfu_counting_ml.api.api import app
from vxgioq_cfu_counting_ml.utils.types import Detectron2DatasetElement


@pytest.fixture(scope="session")
def matches() -> List[Tuple[str, str, bool]]:
    """Generate synthetic matches."""
    return [
        ("labelled_17_L1 - BCKGRD.png", "report-2019-1time2-02_QC_K7_ENFA__sample-20.png", True),
        ("labelled_22_L1 - BCKGRD.png", "report-2019-11-26_BP__sample-45.png", True),
        ("labelled_25_L1 - BCKGRD.png", "report-2019-11-27_MAS_2__sample-142.png", True),
        ("labelled_28_L1 - BCKGRD.png", "report-2019-12-02_Water Monitoring__sample-77.png", True),
        ("unlabelled_Negatif_2_4_90.bmp", "unlabelled_Negatif_1_9_180.bmp", False),
        ("unlabelled_Negatif_2_5_0.bmp", "unlabelled_Negatif_2_9_180.bmp", False),
        ("unlabelled_Negatif_2_5_180.bmp", "unlabelled_Negatif_2_3_180.bmp", False),
        ("unlabelled_Negatif_2_5_270.bmp", "unlabelled_Negatif_2_3_270.bmp", False),
        ("unlabelled_Negative TSA K7_4.bmp", "report-2019-12-12_NEG_TSA_K7__sample-13.png", True),
        ("unlabelled_Negative TSA K7_5.bmp", "report-2019-12-12_NEG_TSA_K7__sample-17.png", True),
    ]


@pytest.fixture(scope="session")
def detectron2_dataset(matches: List[Tuple[str, str, bool]]) -> List[Detectron2DatasetElement]:
    """Generate a synthetic detectron2 dataset."""
    file_names = [match[0] for match in matches]
    return [
        Detectron2DatasetElement(
            file_name=file_name, height=1200, width=1200, image_id=file_name, annotations=[]
        )
        for file_name in file_names
    ]


@pytest.fixture(scope="session")
def files_dir() -> Iterator[str]:
    """Generate synthetic temporary files in a temp folder and return the temp folder name."""
    # create dir
    tmp_dir = tempfile.mkdtemp()

    # fill dir with files
    for i in range(4):
        with open(os.path.join(tmp_dir, f"tmp_file_{i}.png"), mode="w") as f:
            f.write("")
            time.sleep(
                5
            )  # To ensure files get actually written in the good order, even on slow machines such as microsoft hosted agents
    with open(os.path.join(tmp_dir, "tmp_file.lz4"), mode="w") as f:
        f.write("")

    yield tmp_dir

    # teardown cleans created files
    shutil.rmtree(tmp_dir)


@pytest.fixture(scope="session")
def client() -> TestClient:
    """Generate a testing fastapi client."""
    return TestClient(app)
