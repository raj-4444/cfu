"""Module testing the utils/azure.py module."""

import os
import time

from vxgioq_cfu_counting_ml.utils.azure import (
    ACCOUNT_URL,
    CONTAINER,
    MODELS_KPIS_NAME,
    PATH_MODELS_ON_BLOB,
    blob_exists,
    delete_object_from_blob,
    download_load_models_kpis,
    get_blob_service_client,
    get_cosmos_mongo_collection,
    get_file_from_blob,
    list_files_on_blob,
    write_zip_upload_models_kpis,
    zip_upload_file_folder_to_blob,
)
from vxgioq_cfu_counting_ml.utils.types import ModelsKPIs


def test_get_blob_service_client() -> None:
    """Test authenticating and creating BlobServiceClient."""
    get_blob_service_client()


def test_get_file_from_blob() -> None:
    """Test connection to Blob Storage by downloading small test file."""
    get_file_from_blob(f"{ACCOUNT_URL}/{CONTAINER}/tests/input_images/image_2_instances.png")


def test_zip_upload_folder_to_blob_and_delete_object_from_blob(files_dir: str) -> None:
    """Test `zip_upload_file_folder_to_blob()` and `delete_object_from_blob`."""
    # delete pre-existing folder on blob
    blob_name = os.path.join("tests", os.path.basename(files_dir) + ".zip")
    delete_object_from_blob(blob_name)
    url = os.path.join(ACCOUNT_URL, CONTAINER, blob_name)
    assert not blob_exists(url)

    # zipupload tmp folder to blob
    zip_upload_file_folder_to_blob(file_folder=files_dir, url=url, overwrite=True, compress=False)

    # check file exists on blob
    assert blob_exists(url)

    # delete on blob
    delete_object_from_blob(blob_name)
    assert not blob_exists(url)


def test_zip_upload_file_to_blob_and_delete_object_from_blob(files_dir: str) -> None:
    """Test `zip_upload_file_folder_to_blob()` and `delete_object_from_blob`."""
    # delete pre-existing folder on blob
    blob_name = os.path.join("tests", os.path.basename(files_dir) + ".zip")
    delete_object_from_blob(blob_name)
    time.sleep(5)
    url = os.path.join(ACCOUNT_URL, CONTAINER, blob_name)
    assert not blob_exists(url)

    # zipupload tmp file to blob
    filename = os.path.join(files_dir, os.listdir(files_dir)[0])

    zip_upload_file_folder_to_blob(file_folder=filename, url=url, overwrite=True, compress=False)

    # check file exists on blob
    assert blob_exists(url)

    # overwrite file
    zip_upload_file_folder_to_blob(file_folder=filename, url=url, overwrite=True, compress=False)

    # check file exists on blob
    assert blob_exists(url)

    # delete on blob
    delete_object_from_blob(blob_name)
    assert not blob_exists(url)


def test_list_files_on_blob() -> None:
    """Test `list_files_on_blob`."""
    response_expected = {
        "input_images/image_2_instances.png",
        "input_images/image_many_instances.png",
        "output_images/image_2_instances.png",
        "output_images/image_many_instances.png",
    }
    response_actual = set(list_files_on_blob(name_starts_with="tests/", return_urls=False))
    assert response_expected.issubset(response_actual)


def test_download_load_models_kpis_write_zip_upload_models_kpis() -> None:
    """Test `download_load_models_kpis` and `write_zip_upload_models_kpis`."""
    # load models_kpis
    models_kpis = download_load_models_kpis()

    # check loaded models_kpis
    assert isinstance(models_kpis, ModelsKPIs)

    # write them back to blob
    write_zip_upload_models_kpis(models_kpis=models_kpis, overwrite=True)

    # assert blob exists
    blob_exists(url=os.path.join(PATH_MODELS_ON_BLOB, MODELS_KPIS_NAME))


def test_get_cosmos_mongo_collection() -> None:
    """Test `get_cosmos_mongo_collection`."""
    get_cosmos_mongo_collection()
