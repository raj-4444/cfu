"""Test `prediction_intervals` module."""

import pandas as pd
import pytest
from lightgbm import LGBMRegressor
from sklearn.datasets import make_regression

from vxgioq_cfu_counting_ml.utils.prediction_intervals import train_quantile_regressor
from vxgioq_cfu_counting_ml.utils.types import HPSpace


@pytest.mark.parametrize("hp_space_size", [HPSpace.NARROW, HPSpace.WIDE])
def test_train_quantile_regressor(hp_space_size: HPSpace) -> None:
    """Test `train_quantile_regressor`."""
    # prepare an artifical regression problem
    X, y = make_regression(n_samples=100, n_features=10, coef=False)

    # train and HP and keep best regressor
    regressor = train_quantile_regressor(
        X_train=pd.DataFrame(X), y_train=pd.Series(y), hp_space_size=hp_space_size
    )

    # ensure we have a regressor back
    assert isinstance(regressor, LGBMRegressor)
