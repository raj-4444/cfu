"""Test organize_data module."""

import os
from typing import List, Tuple

from vxgioq_cfu_counting_ml.training.organize_data import (
    count_files,
    custom_negative_train_test_split,
    sort_files_by_datetime_name,
)
from vxgioq_cfu_counting_ml.utils.types import Detectron2DatasetElement


def test_custom_negative_train_test_split(
    detectron2_dataset: List[Detectron2DatasetElement], matches: List[Tuple[str, str, bool]]
) -> None:
    """Test `custom_negative_train_test_split`."""
    assert (
        [
            Detectron2DatasetElement(
                file_name="unlabelled_Negatif_2_4_90.bmp",
                height=1200,
                width=1200,
                image_id="unlabelled_Negatif_2_4_90.bmp",
                annotations=[],
            ),
            Detectron2DatasetElement(
                file_name="unlabelled_Negatif_2_5_0.bmp",
                height=1200,
                width=1200,
                image_id="unlabelled_Negatif_2_5_0.bmp",
                annotations=[],
            ),
            Detectron2DatasetElement(
                file_name="unlabelled_Negatif_2_5_180.bmp",
                height=1200,
                width=1200,
                image_id="unlabelled_Negatif_2_5_180.bmp",
                annotations=[],
            ),
            Detectron2DatasetElement(
                file_name="unlabelled_Negatif_2_5_270.bmp",
                height=1200,
                width=1200,
                image_id="unlabelled_Negatif_2_5_270.bmp",
                annotations=[],
            ),
        ],
        [
            Detectron2DatasetElement(
                file_name="unlabelled_Negative TSA K7_4.bmp",
                height=1200,
                width=1200,
                image_id="unlabelled_Negative TSA K7_4.bmp",
                annotations=[],
            ),
            Detectron2DatasetElement(
                file_name="unlabelled_Negative TSA K7_5.bmp",
                height=1200,
                width=1200,
                image_id="unlabelled_Negative TSA K7_5.bmp",
                annotations=[],
            ),
        ],
    ) == custom_negative_train_test_split(dataset=detectron2_dataset, matches=matches)
    assert isinstance(custom_negative_train_test_split(dataset=detectron2_dataset), tuple)


def test_count_files(files_dir: str) -> None:
    """Test `count_files`."""
    assert 4 == count_files(folders=files_dir)
    assert 1 == count_files(folders=[files_dir], excludes=".png")


def test_sort_files_by_datetime_name(files_dir: str) -> None:
    """Test `sort_files_by_datetime_name`."""
    expected_ordered_files_list = [
        os.path.join(files_dir, filename)
        for filename in [
            "tmp_file.lz4",
            "tmp_file_3.png",
            "tmp_file_2.png",
            "tmp_file_1.png",
            "tmp_file_0.png",
        ]
    ]
    assert expected_ordered_files_list == sort_files_by_datetime_name(
        files=[os.path.join(files_dir, filename) for filename in os.listdir(files_dir)],
        ascending=False,
    )
