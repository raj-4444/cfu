"""Test CFUTrainer."""

import os
import tempfile
from typing import List

import cv2
import joblib
import numpy as np
from detectron2.data import DatasetCatalog, MetadataCatalog
from detectron2.engine import DefaultTrainer
from detectron2.evaluation import DatasetEvaluators
from detectron2.modeling.meta_arch.rcnn import GeneralizedRCNN

from vxgioq_cfu_counting_ml.training.trainer import CFUTrainer
from vxgioq_cfu_counting_ml.utils.azure import DATASET_DETECTRON2_NAME
from vxgioq_cfu_counting_ml.utils.conf import (
    prepare_cfu_detectron2_config_from_detectron2_model_zoo,
)
from vxgioq_cfu_counting_ml.utils.custom_datasets import func_dataset
from vxgioq_cfu_counting_ml.utils.types import Backbone, Detectron2DatasetElement, Device


def test_CFUTrainer(detectron2_dataset: List[Detectron2DatasetElement]) -> None:
    """Test `CFUTrainer`."""
    # prepare the cfg
    dataset_name = "dataset_test"
    cfg = prepare_cfu_detectron2_config_from_detectron2_model_zoo(
        backbone=Backbone.R50_FPN, device=Device.CPU, iterations=100
    )
    cfg.DATASETS.TRAIN = (dataset_name,)
    # register the dataset and test the train model
    with tempfile.TemporaryDirectory(prefix=dataset_name) as d:

        # write fake corresponding images in tmp folder
        for dataset_el in detectron2_dataset:
            file_name = os.path.join(d, dataset_el.file_name)
            cv2.imwrite(
                file_name, np.zeros((dataset_el.height, dataset_el.width), dtype=np.uint8),
            )
            dataset_el.file_name = file_name
        # dump fake detectron annatations in tmp folder
        joblib.dump(detectron2_dataset, os.path.join(d, DATASET_DETECTRON2_NAME))

        cfg.OUTPUT_DIR = d
        cfg.DATALOADER.FILTER_EMPTY_ANNOTATIONS = False
        dataset_catalog_name_root = func_dataset.__name__[5:]
        # register dataset
        dataset_catalog_name = f"{dataset_catalog_name_root}_test"
        DatasetCatalog.register(
            dataset_catalog_name, lambda dataset_type="test": func_dataset(folder=d)
        )
        MetadataCatalog.get(dataset_catalog_name).set(thing_classes=["CFU"])
        trainer = CFUTrainer(cfg)

        # test property
        assert isinstance(trainer, CFUTrainer)
        assert isinstance(trainer, DefaultTrainer)
        assert isinstance(trainer.model, GeneralizedRCNN)

        # test build evaluator
        evaluator = trainer.build_evaluator(cfg=cfg, dataset_name=dataset_name)
        assert isinstance(evaluator, DatasetEvaluators)
