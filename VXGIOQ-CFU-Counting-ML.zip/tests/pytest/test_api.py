"""Test the ML API."""

from fastapi.testclient import TestClient


def test_index(client: TestClient) -> None:
    """Test the `index` endpoint of the ML API."""
    response = client.get("/index")
    assert response.status_code == 200
    expected_response = {
        "title": "",
        "description": "",
        "started": "",
        "git-commit": "",
        "git-branch": "",
        "storage_name": "",
    }
    assert all(
        isinstance(key_actual, type(key_expected))
        and isinstance(value_actual, type(value_expected))
        for key_expected, value_expected in expected_response.items()
        for key_actual, value_actual in response.json().items()
        if key_actual == key_expected
    )


def test_hello(client: TestClient) -> None:
    """Test the `hello` endpoint of the ml API."""
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Hello World"}


def test_existing_segment_images_instances(client: TestClient) -> None:
    """Test the `segment_images_instances` endpoint of the ml API with existing image."""
    image_name = "image_012"
    response = client.post("/petri_dishes/segmented_instances", json={"samples_ids": [image_name]})
    assert response.status_code == 200


def test_non_existing_segment_images_instances(client: TestClient) -> None:
    """Test the `segment_images_instances` endpoint of the ml API with non-existing image."""
    image_name = "image_013"
    response = client.post("/petri_dishes/segmented_instances", json={"samples_ids": [image_name]})
    assert response.status_code == 200
    assert len(response.json()["images"]) == 0


def test_non_existing_and_existing_segment_images_instances(client: TestClient) -> None:
    """Test the `segment_images_instances` endpoint of the ml API with non-existing and existing images."""
    image_names = ["image_012", "image_013"]
    response = client.post("/petri_dishes/segmented_instances", json={"samples_ids": image_names})
    assert response.status_code == 200
    assert len(response.json()["images"]) == 1
