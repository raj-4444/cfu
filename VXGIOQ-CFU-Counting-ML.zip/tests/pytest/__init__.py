"""VXGIOQ-CFU-Counting-ML pytest test suite."""
