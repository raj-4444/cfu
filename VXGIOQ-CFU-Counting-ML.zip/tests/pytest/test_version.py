"""Test package version."""

from vxgioq_cfu_counting_ml import __version__


def test_version() -> None:
    """Test that the version string can be loaded."""
    assert isinstance(__version__, str)
